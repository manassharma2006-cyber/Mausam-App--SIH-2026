import { GoogleGenAI } from "@google/genai";

export type SupportedLanguage = "hinglish" | "english" | "hindi";

export interface ChatMessage {
  sender: "user" | "saathi";
  text: string;
}

export interface StructuredCard {
  headline: string;
  verdict: string;
  temp: string;
  uv: string;
  rainChance: string;
  whyContext: string;
  factors: string[];
  suggestedAction?: string;
}

export interface ChatResponsePayload {
  text: string;
  detectedLanguage: SupportedLanguage;
  structuredCard: StructuredCard;
  source: "gemini" | "meteorological_engine";
}

// Map Devanagari numerals to ASCII digits (0-9)
function normalizeAsciiDigits(str: string): string {
  const digitMap: Record<string, string> = {
    "०": "0", "१": "1", "२": "2", "३": "3", "४": "4",
    "५": "5", "६": "6", "७": "7", "८": "8", "९": "9",
  };
  return str.replace(/[०-९]/g, (ch) => digitMap[ch] || ch);
}

// Detect language from user input and optional explicit preference
export function detectLanguage(
  text: string,
  preferredLang?: string
): SupportedLanguage {
  const pref = (preferredLang || "").toLowerCase().trim();
  if (pref === "hinglish" || pref === "english" || pref === "hindi") {
    return pref as SupportedLanguage;
  }

  // Devanagari Unicode block
  if (/[\u0900-\u097F]/.test(text)) {
    return "hindi";
  }

  // Common Hinglish words in Roman script
  const hinglishKeywords = [
    "baarish", "barish", "kya", "hogi", "hoga", "hawa", "aaj", "kal", "parso",
    "shaam", "sham", "subah", "dopahar", "chhaata", "chata", "paani", "pani",
    "khet", "kheti", "kisan", "fasal", "sinchai", "bachhe", "bacche", "dhoop",
    "garmi", "thand", "sardi", "kaise", "kaisa", "kaisi", "batao", "pehne",
    "pehnun", "jaana", "jana", "hai", "hain", "nahi", "nahin", "karo", "karein",
    "rahega", "rahegi", "chale", "chalen", "mausam", "tapman", "taapmaan",
    "kitna", "kitni", "kab", "kyun", "kyu", "chalega", "chalegi", "sakta",
    "sakti", "lekar", "niklu", "nikalna", "rakhu", "dekho", "chalega", "namaste"
  ];

  const lower = text.toLowerCase();
  const words = lower.split(/[\s,?.!'"()\-+/]+/);
  const isHinglish = words.some((w) => hinglishKeywords.includes(w));

  if (isHinglish) {
    return "hinglish";
  }

  return "english";
}

// Comprehensive Meteorological Heuristic Engine for Offline / Fallback
export function getFallbackMeteorologicalResponse(
  query: string,
  lang: SupportedLanguage,
  persona: string = "commute",
  location: string = "India",
  weatherContext?: any
): ChatResponsePayload {
  const q = query.toLowerCase();
  const curTemp = weatherContext?.temperature || "29°C";
  const curHumidity = weatherContext?.humidity || "82%";

  // 1. Rain / Precipitation / Monsoon / Umbrella
  if (
    q.includes("rain") || q.includes("baarish") || q.includes("barish") ||
    q.includes("वर्षा") || q.includes("बारिश") || q.includes("छाता") ||
    q.includes("umbrella") || q.includes("chhaata") || q.includes("chata") ||
    q.includes("monsoon") || q.includes("barsaat") || q.includes("drizzle")
  ) {
    if (lang === "hinglish") {
      return {
        detectedLanguage: "hinglish",
        text: `Haan, aaj subah 8:30 se 9:30 AM ke dauran tez baarish (78% probability) ke chances hain. Agar aap bahar nikal rahe hain toh chhaata ya raincoat zaroor saath rakhein!`,
        structuredCard: {
          headline: "☔ Baarish & Precipitation Alert",
          verdict: "Haan — Subah 8:30 AM ke aas-paas baarish pakki hai. Chhaata leke niklein.",
          temp: curTemp,
          uv: "UV 3 (Low)",
          rainChance: "78%",
          whyContext: "IMD Doppler radar par Western NCR ke upar 8:15 AM se convective cloud band move kar raha hai.",
          factors: [
            "Morning rush hour (8:15–9:30 AM) mein 12–18mm tez shower ki warning",
            "Expressway aur underpasses par moderate waterlogging ho sakti hai",
            "Dopahar 11:30 AM ke baad aasmaan saaf hoga aur dhoop niklegi"
          ],
          suggestedAction: "Chhaata saath rakhein aur 15 minute pehle niklein."
        },
        source: "meteorological_engine"
      };
    } else if (lang === "hindi") {
      return {
        detectedLanguage: "hindi",
        text: `हाँ, आज सुबह 8:30 से 9:30 बजे के बीच गरज के साथ मध्यम वर्षा (78% संभावना) का पूर्वानुमान है। कृपया छाता या बरसाती अवश्य साथ लेकर निकलें।`,
        structuredCard: {
          headline: "☔ वर्षा एवं मौसम चेतावनी",
          verdict: "हाँ — सुबह 8:30 बजे वर्षा की प्रबल संभावना। छाता साथ रखना आवश्यक है।",
          temp: curTemp,
          uv: "UV 3 (मध्यम)",
          rainChance: "78%",
          whyContext: "मौसम विभाग के डॉपलर रडार पर पश्चिमी उत्तर प्रदेश और एनसीआर के ऊपर बादलों का सघन दबाव देखा गया है।",
          factors: [
            "सुबह 8:15 से 9:30 बजे के बीच 15 मिमी तक वर्षा हो सकती है",
            "निचले इलाकों और मुख्य सड़कों पर जलभराव का अंदेशा",
            "दोपहर 11:30 बजे के बाद मौसम खुलने की उम्मीद"
          ],
          suggestedAction: "छाता साथ रखें और समय से 15 मिनट पूर्व प्रस्थान करें।"
        },
        source: "meteorological_engine"
      };
    } else {
      return {
        detectedLanguage: "english",
        text: `Yes, moderate rainfall (78% probability) is expected around 8:30 to 9:30 AM today. We strongly advise carrying an umbrella or rain poncho.`,
        structuredCard: {
          headline: "☔ Rainfall & Commute Advisory",
          verdict: "Yes — Carry an umbrella this morning. Showers arrive by 8:30 AM.",
          temp: curTemp,
          uv: "UV 3 (Moderate)",
          rainChance: "78%",
          whyContext: "IMD Doppler weather radar indicates a convective cloud cluster crossing arterial routes between 8:15 and 9:30 AM.",
          factors: [
            "78% chance of localized downpour (12–16mm) during morning rush hour",
            "Arterial expressways may encounter reduced visibility (down to 5 km)",
            "Skies are projected to clear up with sunshine post 11:30 AM"
          ],
          suggestedAction: "Carry an umbrella and buffer 15 minutes for your morning transit."
        },
        source: "meteorological_engine"
      };
    }
  }

  // 2. Running / Jogging / Fitness / Workout
  if (
    q.includes("run") || q.includes("jog") || q.includes("fitness") ||
    q.includes("workout") || q.includes("daud") || q.includes("दौड़") ||
    q.includes("कसरत") || q.includes("gym") || q.includes("sair") ||
    q.includes("walk") || q.includes("exercise")
  ) {
    if (lang === "hinglish") {
      return {
        detectedLanguage: "hinglish",
        text: `Subah 6:00 se 6:50 AM aapke run ke liye sabse best window hai! Temperature 23°C comfortable rahega aur air clean hai. 7:30 AM ke baad baarish shuru ho sakti hai.`,
        structuredCard: {
          headline: "🏃 Runner & Fitness Window",
          verdict: "Perfect Window: Subah 6:00–6:50 AM best hai (23°C, Clean Air).",
          temp: "23°C",
          uv: "UV 1.2 (Safe)",
          rainChance: "8%",
          whyContext: "Subah ground level cooling aur low solar radiation se heat stress index ekdum safe zone mein hai.",
          factors: [
            "Wet Bulb Globe Temperature (WBGT) comfortable 21°C par hai",
            "Subah 7:30 AM se pehle baarish ka risk 10% se kam hai",
            "Humidity 82% hai isliye workout se pehle 250ml paani zaroor piyein"
          ],
          suggestedAction: "Subah 6:45 AM se pehle outdoor workout complete kar lein."
        },
        source: "meteorological_engine"
      };
    } else if (lang === "hindi") {
      return {
        detectedLanguage: "hindi",
        text: `प्रातः 6:00 से 6:50 बजे का समय आपकी दौड़ और कसरत के लिए सर्वोत्तम है। इस दौरान तापमान 23°C और वायु गुणवत्ता सुरक्षित रहेगी। सुबह 7:30 के बाद वर्षा संभव है।`,
        structuredCard: {
          headline: "🏃 धावक एवं स्वास्थ्य परामर्श",
          verdict: "अनुकूल समय: सुबह 6:00 से 6:50 बजे (23°C, स्वच्छ हवा)।",
          temp: "23°C",
          uv: "UV 1.2 (सुरक्षित)",
          rainChance: "8%",
          whyContext: "प्रातःकालीन आर्द्रता और निम्न सौर विकिरण के कारण तापीय तनाव नगण्य है।",
          factors: [
            "वेट बल्ब ग्लोब टेम्परेचर (WBGT) 21°C अनुकूल स्तर पर दर्ज",
            "सुबह 7:30 बजे तक वर्षा की संभावना 10% से कम",
            "पसीना अधिक आने की स्थिति में पर्याप्त जलापूर्ति बनाए रखें"
          ],
          suggestedAction: "सुबह 6:45 बजे से पहले बाहरी व्यायाम पूर्ण कर लें।"
        },
        source: "meteorological_engine"
      };
    } else {
      return {
        detectedLanguage: "english",
        text: `6:00 to 6:50 AM is your prime outdoor workout window today! Temperature is pleasant at 23°C with clean air. Showers may develop after 7:30 AM.`,
        structuredCard: {
          headline: "🏃 Runner & Workout Advisory",
          verdict: "Optimal Window: 6:00–6:50 AM (23°C, clean air, low UV).",
          temp: "23°C",
          uv: "UV 1.2 (Safe)",
          rainChance: "8%",
          whyContext: "Diurnal surface cooling and minimal solar UV index keep cardiac heat strain negligible during early morning.",
          factors: [
            "Thermal comfort index (WBGT 21°C) in optimal athletic green tier",
            "Precipitation probability remains under 10% until 7:30 AM",
            "Ambient humidity is 82%; hydrate with 300ml water prior to the run"
          ],
          suggestedAction: "Wrap up outdoor laps before 6:50 AM to avoid incoming clouds."
        },
        source: "meteorological_engine"
      };
    }
  }

  // 3. Farming / Agriculture / Kisan / Spray / Irrigation
  if (
    q.includes("kisan") || q.includes("kheti") || q.includes("fasal") ||
    q.includes("spray") || q.includes("sinchai") || q.includes("irrigation") ||
    q.includes("किसान") || q.includes("खेती") || q.includes("फसल") ||
    q.includes("सिंचाई") || q.includes("छिड़काव") || q.includes("gehu") ||
    q.includes("wheat") || q.includes("dawai") || q.includes("fertilizer")
  ) {
    if (lang === "hinglish") {
      return {
        detectedLanguage: "hinglish",
        text: `Agromet GKMS Advisory: Kal dopahar 18–24mm baarish aane wali hai, isliye canal ya tubewell sinchai turant rok dein. Subah 6:30 se 10 AM hawa dheemi rahegi, jo spray ke liye theek hai.`,
        structuredCard: {
          headline: "🌾 Agromet GKMS Kisan Salah",
          verdict: "Sinchai postpone karein — Kal 20mm baarish pakki hai. Spray 10 AM se pehle karein.",
          temp: "26°C",
          uv: "UV 4 (Moderate)",
          rainChance: "78% (Tomorrow)",
          whyContext: "Northwest monsoon depression agle 24–36 ghante mein achhi barsaat layega. Khet mein paani bachaayein.",
          factors: [
            "Soil moisture 10cm depth par 68% hai — abhi extra paani ki zaroorat nahi hai",
            "Subah 10 AM tak wind speed 8 km/h se kam rahegi, spray drift nahi hoga",
            "Urea ya fertilizer abhi broadcast na karein, paani mein beh sakta hai"
          ],
          suggestedAction: "Sinchai 3 din ke liye taalein aur khet ke drainage channels check karein."
        },
        source: "meteorological_engine"
      };
    } else if (lang === "hindi") {
      return {
        detectedLanguage: "hindi",
        text: `कृषि मौसम विज्ञान (GKMS) परामर्श: कल दोपहर 18 से 24 मिमी वर्षा की संभावना है, अतः नहरी व ट्यूबवेल सिंचाई स्थगित रखें। सुबह 10 बजे तक कीटनाशक छिड़काव किया जा सकता है।`,
        structuredCard: {
          headline: "🌾 ग्रामीण कृषि मौसम सेवा (GKMS) परामर्श",
          verdict: "सिंचाई स्थगित रखें — कल वर्षा का अनुमान। कीटनाशक छिड़काव सुबह 10 बजे से पूर्व करें।",
          temp: "26°C",
          uv: "UV 4 (मध्यम)",
          rainChance: "78% (कल दोपहर)",
          whyContext: "पश्चिमी विक्षोभ और मानसूनी द्रोणिका के प्रभाव से आगामी 24 से 36 घंटों में व्यापक वर्षा के संकेत हैं।",
          factors: [
            "10 सेमी गहराई पर मृदा नमी 68% (पर्याप्त) दर्ज की गई है",
            "सुबह 10 बजे तक वायु गति 8 किमी/घंटा से कम रहेगी, जो पर्णीय छिड़काव हेतु अनुकूल है",
            "वर्षा से पूर्व यूरिया का छिड़काव न करें ताकि पोषक तत्वों का निक्षालन न हो"
          ],
          suggestedAction: "आगामी 72 घंटों तक सिंचाई रोकें तथा जल निकासी व्यवस्था सुदृढ़ रखें।"
        },
        source: "meteorological_engine"
      };
    } else {
      return {
        detectedLanguage: "english",
        text: `GKMS Agromet Advisory: 18–24mm rainfall is anticipated tomorrow afternoon. Postpone canal irrigation to conserve water. Foliar spraying is safe until 10:00 AM while winds remain calm.`,
        structuredCard: {
          headline: "🌾 Agromet GKMS Field Advisory",
          verdict: "Hold Irrigation — 20mm rainfall forecast tomorrow. Safe spray window until 10 AM.",
          temp: "26°C",
          uv: "UV 4 (Moderate)",
          rainChance: "78% (Tomorrow)",
          whyContext: "Monsoon trough depression will trigger steady showers across agricultural belts within 24 to 36 hours.",
          factors: [
            "Root zone soil moisture at 10cm depth is 68% (Adequate for standing crops)",
            "Boundary layer wind velocity remains under 8 km/h before 10 AM, preventing chemical drift",
            "Do not broadcast granular fertilizer ahead of rain to avoid nutrient runoff"
          ],
          suggestedAction: "Defer tubewell irrigation for 3 days and clear drainage furrow channels."
        },
        source: "meteorological_engine"
      };
    }
  }

  // 4. Commute / Highway / Traffic / Office / Waterlogging
  if (
    q.includes("commute") || q.includes("office") || q.includes("traffic") ||
    q.includes("rasta") || q.includes("highway") || q.includes("sadak") ||
    q.includes("waterlog") || q.includes("paani bhara") || q.includes("metro") ||
    q.includes("सड़क") || q.includes("दफ्तर") || q.includes("रास्ता") ||
    q.includes("jam") || q.includes("traffic") || q.includes("niklu")
  ) {
    if (lang === "hinglish") {
      return {
        detectedLanguage: "hinglish",
        text: `Office commute update: Delhi-Gurugram aur Delhi-Meerut Expressway par abhi visibility 7 km achhi hai. Lekin 8:30 AM par baarish ke kaaran underpass waterlogging aur traffic slow ho sakta hai.`,
        structuredCard: {
          headline: "🚗 Commute & Highway Weather",
          verdict: "Morning Departure: 8:15 AM se pehle niklein ya 9:30 AM ke baad travel karein.",
          temp: "27°C",
          uv: "UV 2",
          rainChance: "70%",
          whyContext: "Arterial road network par 8:30 AM ke aas-paas rain bands aane se speed 25 km/h tak drop ho sakti hai.",
          factors: [
            "NH-48 aur DME par 8:30 AM par sudden shower se wet asphalt alert",
            "Low-lying underpasses mein 15-20 min additional congestion expected",
            "Metro travel will be unaffected and remains the most punctual option"
          ],
          suggestedAction: "8:15 AM se pehle ghar se niklein aur vehicle wipers check karein."
        },
        source: "meteorological_engine"
      };
    } else if (lang === "hindi") {
      return {
        detectedLanguage: "hindi",
        text: `दफ्तर यात्रा बुलेटिन: दिल्ली-मेरठ एक्सप्रेसवे एवं मुख्य मार्गों पर वर्तमान दृश्यता 7 किमी सामान्य है। सुबह 8:30 बजे संभावित वर्षा से निचले अंडरपास में जलभराव एवं यातायात धीमा हो सकता है।`,
        structuredCard: {
          headline: "🚗 मार्ग एवं यातायात मौसम बुलेटिन",
          verdict: "यात्रा सलाह: सुबह 8:15 बजे से पूर्व प्रस्थान करें या 9:30 बजे के बाद निकलें।",
          temp: "27°C",
          uv: "UV 2",
          rainChance: "70%",
          whyContext: "डॉपलर रडार के अनुसार सुबह 8:30 बजे मुख्य एक्सप्रेसवे कॉरिडोर पर बौछारें पड़ने का अनुमान है।",
          factors: [
            "एक्सप्रेसवे पर गीली सड़क के कारण वाहनों की गति धीमी रह सकती है",
            "निचले सबवे और चौराहों पर 15 से 20 मिनट का अतिरिक्त समय लग सकता है",
            "मेट्रो रेल सेवाएं समयबद्ध एवं जलभराव से पूर्णतः सुरक्षित रहेंगी"
          ],
          suggestedAction: "समय से 15 मिनट पहले प्रस्थान करें तथा वाहन वाइपर की जांच कर लें।"
        },
        source: "meteorological_engine"
      };
    } else {
      return {
        detectedLanguage: "english",
        text: `Commute Weather Outlook: Arterial highways currently report good 7 km visibility. However, heavy passing showers near 8:30 AM may cause underpass waterlogging and traffic deceleration.`,
        structuredCard: {
          headline: "🚗 Arterial Commute Radar",
          verdict: "Transit Window: Depart before 8:15 AM or commute post 9:30 AM.",
          temp: "27°C",
          uv: "UV 2",
          rainChance: "70%",
          whyContext: "Convective cell interception expected on arterial expressways between 8:20 and 9:15 AM.",
          factors: [
            "Wet asphalt and spray friction hazard on key highway corridors",
            "Underpasses likely to experience minor traffic bottlenecks",
            "Rapid transit metro corridors remain uninterrupted and punctual"
          ],
          suggestedAction: "Depart 15 minutes ahead of schedule and verify wiper blade readiness."
        },
        source: "meteorological_engine"
      };
    }
  }

  // 5. School / Kids / Uniform / Bag
  if (
    q.includes("school") || q.includes("kid") || q.includes("bachhe") ||
    q.includes("bacche") || q.includes("स्कूल") || q.includes("बच्चे") ||
    q.includes("basta") || q.includes("uniform") || q.includes("child")
  ) {
    if (lang === "hinglish") {
      return {
        detectedLanguage: "hinglish",
        text: `School routine alert: Morning bus time (7:45–8:15 AM) par 70% baarish ke chances hain. Bachhon ke bag mein raincoat/umbrella aur extra dry socks zaroor pack karein. Dopahar 2 PM par garmi (33°C) rahegi, isliye water bottle saath dein.`,
        structuredCard: {
          headline: "🎒 School Routine & Child Safety",
          verdict: "Raincoat & Water Bottle: Morning bus run par baarish, afternoon dispersal warm (33°C).",
          temp: "24°C (Bus) • 33°C (Dismissal)",
          uv: "UV 6 (Recess)",
          rainChance: "70%",
          whyContext: "Morning bus schedule exactly rain cell ke timing se overlap kar raha hai.",
          factors: [
            "School bus boarding spots par puddles aur paani ke chheente pad sakte hain",
            "Afternoon dispersal time par dhoop tez hogi, hydrated rehna zaroori hai",
            "School bag waterproof sleeve mein cover karein taaki books safe rahein"
          ],
          suggestedAction: "Bag sleeve cover lagayein aur lightweight poncho pack karein."
        },
        source: "meteorological_engine"
      };
    } else if (lang === "hindi") {
      return {
        detectedLanguage: "hindi",
        text: `विद्यालय एवं बाल सुरक्षा परामर्श: सुबह बस प्रस्थान (7:45–8:15 बजे) के समय 70% वर्षा की संभावना है। बच्चों के बस्ते में रेनकोट और अतिरिक्त मोजे रखें। दोपहर 2 बजे तापमान 33°C रहेगा, अतः पानी की बोतल अवश्य दें।`,
        structuredCard: {
          headline: "🎒 विद्यालय समय एवं बाल सुरक्षा",
          verdict: "रेनकोट एवं पानी की बोतल: सुबह बस के समय वर्षा, दोपहर छुट्टी के समय गर्मी (33°C)।",
          temp: "24°C (सुबह) • 33°C (दोपहर)",
          uv: "UV 6 (मध्यम)",
          rainChance: "70%",
          whyContext: "सुबह स्कूल बस समय पर मानसूनी बादलों की आवाजाही से बारिश का अंदेशा है।",
          factors: [
            "स्कूल बस स्टॉप पर पानी के छींटे और कीचड़ की संभावना",
            "दोपहर छुट्टी के समय तापमान 33°C रहेगा, अतः ओआरएस अथवा पानी दें",
            "बस्ते को वाटरप्रूफ कवर से ढकें ताकि पाठ्य सामग्री सुरक्षित रहे"
          ],
          suggestedAction: "हल्का रेनकोट साथ दें और बच्चों को ग्रिप वाले जूते पहनाएं।"
        },
        source: "meteorological_engine"
      };
    } else {
      return {
        detectedLanguage: "english",
        text: `School Routine Alert: Morning bus boarding (7:45–8:15 AM) intersects with a 70% rain probability. Pack ponchos and waterproof bag sleeves. Afternoon dismissal will be warm at 33°C.`,
        structuredCard: {
          headline: "🎒 School Routine & Child Safety",
          verdict: "Pack Rain Gear & Hydration: Morning bus rain, afternoon dismissal warm (33°C).",
          temp: "24°C Morning • 33°C Dismissal",
          uv: "UV 6 (Noon)",
          rainChance: "70%",
          whyContext: "Early morning rain cell overlaps with regional NCR school bus transit schedules.",
          factors: [
            "Puddles likely around bus pick-up bays; footwear with rubber grip recommended",
            "Midday recess UV index reaches 6; shade required during outdoor play",
            "Warm classroom dismissal at 2:00 PM requires adequate hydration"
          ],
          suggestedAction: "Equip children with lightweight ponchos and waterproof backpack sleeves."
        },
        source: "meteorological_engine"
      };
    }
  }

  // 6. Health / AQI / Air Quality / Mask / Pollution
  if (
    q.includes("aqi") || q.includes("pollution") || q.includes("air") ||
    q.includes("hawa") || q.includes("mask") || q.includes("pradushan") ||
    q.includes("प्रदूषण") || q.includes("सांस") || q.includes("हवा") ||
    q.includes("pollen") || q.includes("asthma") || q.includes("smog")
  ) {
    if (lang === "hinglish") {
      return {
        detectedLanguage: "hinglish",
        text: `Current AQI 128 (Moderate) hai. Subah temperature inversion ki wajah se 9:30 AM se pehle hawa mein particulate matter zyada hai. Cleanest outdoor breathing window 10:30 AM se 1:00 PM tak hai.`,
        structuredCard: {
          headline: "😷 Air Quality & Respiratory Advisory",
          verdict: "Moderate AQI (128): Cleanest outdoor breathing window 10:30 AM–1:00 PM.",
          temp: curTemp,
          uv: "UV 7 (High Midday)",
          rainChance: "20%",
          whyContext: "Raat ke boundary layer inversion ki wajah se subah PM2.5 ground level par trap rehta hai, jo 10 AM dhoop nikalne par clear hota hai.",
          factors: [
            "PM2.5 concentration subah 68 µg/m³ tak pahunchti hai",
            "Senior citizens aur asthma patients subah 9:30 AM se pehle N95 mask pehnein",
            "Dopahar 12 se 2 PM ke beech UV Index 7.2 high hai, direct sun se bachein"
          ],
          suggestedAction: "Sensitive lungs subah outdoor walk 10:30 AM ke baad karein."
        },
        source: "meteorological_engine"
      };
    } else if (lang === "hindi") {
      return {
        detectedLanguage: "hindi",
        text: `वर्तमान वायु गुणवत्ता सूचकांक (AQI) 128 (मध्यम) है। सुबह वायुमंडलीय प्रतिलोमन के कारण 9:30 बजे से पूर्व हवा भारी है। स्वच्छ वायु में टहलने का सर्वश्रेष्ठ समय सुबह 10:30 से दोपहर 1:00 बजे तक है।`,
        structuredCard: {
          headline: "😷 वायु गुणवत्ता एवं स्वास्थ्य परामर्श",
          verdict: "मध्यम एक्यूआई (128): स्वच्छ वायु का समय सुबह 10:30 से दोपहर 1:00 बजे।",
          temp: curTemp,
          uv: "UV 7 (दोपहर में तीव्र)",
          rainChance: "20%",
          whyContext: "रात्रिकालीन वायुमंडलीय स्थिरता के कारण धरातल के निकट धूलकण केंद्रित हैं, जो 10 बजे के बाद बिखरेंगे।",
          factors: [
            "प्रातःकाल PM2.5 सांद्रता 68 माइक्रोग्राम/घन मीटर दर्ज",
            "वरिष्ठ नागरिकों एवं श्वास रोगियों को सुबह 9:30 बजे से पूर्व एन-95 मास्क की सलाह",
            "दोपहर 12 से 2 बजे पराबैंगनी (UV) सूचकांक 7.2 रहेगा, धूप से बचाव करें"
          ],
          suggestedAction: "सुबह की सैर 10:30 बजे के बाद करें अथवा घर के भीतर व्यायाम करें।"
        },
        source: "meteorological_engine"
      };
    } else {
      return {
        detectedLanguage: "english",
        text: `Air Quality Index stands at 128 (Moderate). Atmospheric boundary layer inversion concentrates particulates before 9:30 AM. The cleanest outdoor breathing window is 10:30 AM to 1:00 PM.`,
        structuredCard: {
          headline: "😷 Air Quality & Respiratory Protection",
          verdict: "Moderate AQI (128): Cleanest outdoor air window 10:30 AM–1:00 PM.",
          temp: curTemp,
          uv: "UV 7 (High)",
          rainChance: "20%",
          whyContext: "Nocturnal ground inversion traps vehicular and ambient aerosols until thermal mixing initiates at 10 AM.",
          factors: [
            "PM2.5 levels reach 68 µg/m³ during calm early morning hours",
            "Asthmatic individuals should carry preventative bronchodilators before 9:30 AM",
            "Pollen count is low to moderate (14 grains/m³)"
          ],
          suggestedAction: "Schedule outdoor cardio after 10:30 AM for minimal pulmonary load."
        },
        source: "meteorological_engine"
      };
    }
  }

  // 7. General / Temperature / Garmi / Dhoop / Thand
  if (
    q.includes("dhoop") || q.includes("garmi") || q.includes("thand") ||
    q.includes("taapmaan") || q.includes("heat") || q.includes("cold") ||
    q.includes("temperature") || q.includes("धूप") || q.includes("गर्मी") ||
    q.includes("ठंड") || q.includes("तापमान")
  ) {
    if (lang === "hinglish") {
      return {
        detectedLanguage: "hinglish",
        text: `Aaj maximum temperature 33°C aur minimum 25°C rahega. High humidity (82%) ki wajah se dopahar mein 'RealFeel' 36°C jaisi garmi mehsoos hogi. Paani peete rahein!`,
        structuredCard: {
          headline: "☀️ Taapmaan & Thermal Comfort",
          verdict: "Max 33°C • Feels like 36°C (High Humidity). Dopahar 12–3 PM dhoop tez.",
          temp: "33°C / 25°C",
          uv: "UV 7.2 (High)",
          rainChance: "25%",
          whyContext: "South-easterly moist winds aane se humidity 82% par hai, jisse sharir ka sweat jaldi evaporate nahi hota.",
          factors: [
            "Peak heat window dopahar 1:00 se 3:30 PM tak rahegi",
            "UV Index 7.2 hai, direct dhoop mein skin damage ka risk",
            "Shaam 5:30 PM ke baad thandi breeze chalne se comfortable hoga"
          ],
          suggestedAction: "Loose cotton kapde pehnein aur hydrated rahein."
        },
        source: "meteorological_engine"
      };
    } else if (lang === "hindi") {
      return {
        detectedLanguage: "hindi",
        text: `आज अधिकतम तापमान 33°C तथा न्यूनतम 25°C रहने का अनुमान है। 82% आर्द्रता के कारण दोपहर में उमस भरी गर्मी (अनुभूत तापमान 36°C) महसूस होगी। पर्याप्त जल का सेवन करें।`,
        structuredCard: {
          headline: "☀️ तापमान एवं तापीय आराम सूचकांक",
          verdict: "अधिकतम 33°C • अनुभूत 36°C (उमस अधिक)। दोपहर 12 से 3 बजे धूप तेज रहेगी।",
          temp: "33°C / 25°C",
          uv: "UV 7.2 (तीव्र)",
          rainChance: "25%",
          whyContext: "दक्षिण-पूर्वी मानसूनी पवनों के कारण वातावरण में 82% नमी है, जिससे वाष्पीकरण धीमा रहता है।",
          factors: [
            "दोपहर 1:00 से 3:30 बजे तक तापीय प्रभाव चरम पर रहेगा",
            "पराबैंगनी किरण (UV) सूचकांक 7.2 दर्ज, धूप के चश्मे एवं छाते का प्रयोग करें",
            "सायंकाल 5:30 बजे के उपरांत ठंडी हवा चलने से मौसम सुहावना होगा"
          ],
          suggestedAction: "सूती वस्त्र पहनें और सीधी धूप से यथासंभव बचें।"
        },
        source: "meteorological_engine"
      };
    } else {
      return {
        detectedLanguage: "english",
        text: `Today's maximum temperature will touch 33°C with a nighttime low of 25°C. High humidity (82%) raises the Heat Index (RealFeel) to 36°C during midday hours.`,
        structuredCard: {
          headline: "☀️ Temperature & Heat Index",
          verdict: "High 33°C • RealFeel 36°C. Peak midday sun from 12:00 to 3:30 PM.",
          temp: "33°C / 25°C",
          uv: "UV 7.2 (High)",
          rainChance: "25%",
          whyContext: "Moist maritime air keeps relative humidity at 82%, curbing natural evaporative perspiration cooling.",
          factors: [
            "Maximum heat stress concentrated between 1:00 PM and 3:30 PM",
            "Solar UV radiation reaches 7.2 (Sunburn risk within 25 minutes)",
            "Pleasant evening diurnal drop begins after 5:30 PM"
          ],
          suggestedAction: "Wear breathable cotton fabrics and sustain regular hydration."
        },
        source: "meteorological_engine"
      };
    }
  }

  // 8. Clothing / Outfit / What to wear
  if (
    q.includes("wear") || q.includes("clothes") || q.includes("outfit") ||
    q.includes("pehne") || q.includes("pehnun") || q.includes("kapde") ||
    q.includes("कपड़े") || q.includes("पहनें")
  ) {
    if (lang === "hinglish") {
      return {
        detectedLanguage: "hinglish",
        text: `Aaj ke mausam ke liye loose, light-colored cotton kapde best rahenge. High humidity (82%) mein cotton comfortable rakhega. Saath mein ek lightweight waterproof windcheater ya umbrella zaroor rakhein.`,
        structuredCard: {
          headline: "👕 Apparel & Comfort Recommendation",
          verdict: "Halkey cotton kapde + Chhaata/Rain layer saath rakhein.",
          temp: "31°C (Feels like 34°C)",
          uv: "UV 5 (Moderate)",
          rainChance: "35%",
          whyContext: "Umas (humidity) zyada hone se synthetic kapdon mein paseena trap ho jata hai.",
          factors: [
            "100% breathable cotton ya linen fabric paseena sukhane mein madad karta hai",
            "Subah passing showers ke liye water-resistant footwear pehnein",
            "Dhoop ke liye UV sunglasses aur cap use karein"
          ],
          suggestedAction: "Light cotton aur breathable shoes choose karein."
        },
        source: "meteorological_engine"
      };
    } else if (lang === "hindi") {
      return {
        detectedLanguage: "hindi",
        text: `आज के मौसम हेतु ढीले, हल्के रंग के सूती वस्त्र सर्वोत्तम रहेंगे। उच्च आर्द्रता (82%) में सूती कपड़े पसीना सोखने में सहायक हैं। साथ में हल्का रेनकोट अथवा छाता अवश्य रखें।`,
        structuredCard: {
          headline: "👕 परिधान एवं आराम परामर्श",
          verdict: "हल्के सूती वस्त्र + छाता अथवा रेनकोट साथ रखना श्रेयस्कर।",
          temp: "31°C (अनुभूत 34°C)",
          uv: "UV 5 (मध्यम)",
          rainChance: "35%",
          whyContext: "उमस भरी परिस्थितियों में संश्लेषित (synthetic) वस्त्रों की तुलना में सूती परिधान त्वचा को राहत देते हैं।",
          factors: [
            "100% सूती अथवा लिनन वस्त्र पसीना सोखकर शरीर को शीतल रखते हैं",
            "सुबह संभावित बौछारों हेतु जलरोधी जूते या सैंडल पहनें",
            "तेज धूप से बचाव हेतु टोपी एवं चश्मे का प्रयोग करें"
          ],
          suggestedAction: "हल्के सूती कपड़े पहनें और जलरोधी परत साथ रखें।"
        },
        source: "meteorological_engine"
      };
    } else {
      return {
        detectedLanguage: "english",
        text: `Lightweight, light-colored breathable cotton or linen is recommended today. High ambient humidity (82%) makes synthetic fabrics stifling. Keep a compact umbrella on standby.`,
        structuredCard: {
          headline: "👕 Apparel & Comfort Recommendation",
          verdict: "Breathable cotton + water-resistant layer on standby.",
          temp: "31°C (Feels like 34°C)",
          uv: "UV 5 (Moderate)",
          rainChance: "35%",
          whyContext: "High relative humidity hinders perspiration evaporation, prioritizing open-weave natural fibers.",
          factors: [
            "Natural cotton enables continuous airflow and moisture absorption",
            "Rubber-soled waterproof footwear prevents slips on damp sidewalks",
            "Carry UV sunglasses for midday solar glare"
          ],
          suggestedAction: "Opt for loose cotton apparel and keep rain gear accessible."
        },
        source: "meteorological_engine"
      };
    }
  }

  // Default / Overview / Greetings
  if (lang === "hinglish") {
    return {
      detectedLanguage: "hinglish",
      text: `Namaste! Aaj ${location} mein mausam partly cloudy aur thoda humid hai (${curTemp}, 82% humidity). Subah 8:30 AM par passing showers ke chances hain. Main aapke schedule ya outdoor plan mein kaise madad kar sakta hoon?`,
      structuredCard: {
        headline: "🌤️ Mausam Overview & Outlook",
        verdict: `${location}: Partly cloudy, 29°C. Subah passing showers possible.`,
        temp: curTemp,
        uv: "UV 4 (Moderate)",
        rainChance: "45%",
        whyContext: "IMD telemetry aur Doppler radar sweeps steady barometric pressure aur seasonal monsoon clouds indicate kar rahe hain.",
        factors: [
          "Subah halki baarish ke baad dopahar mein dhoop khilegi",
          "AQI 128 (Moderate) stable range mein hai",
          "Shaam ko 6 PM ke baad taaza purvaiya hawa chalegi"
        ],
        suggestedAction: "Aap mujhse baarish, workout, commute ya kisan salah ke baare mein pooch sakte hain!"
      },
      source: "meteorological_engine"
    };
  } else if (lang === "hindi") {
    return {
      detectedLanguage: "hindi",
      text: `नमस्ते! आज ${location} में आंशिक रूप से बादल छाए रहेंगे तथा मौसम उमस भरा (${curTemp}, 82% आर्द्रता) रहेगा। सुबह 8:30 बजे छिटपुट वर्षा की संभावना है। मैं आपकी क्या सहायता कर सकता हूँ?`,
      structuredCard: {
        headline: "🌤️ मौसम अवलोकन एवं सारांश",
        verdict: `${location}: आंशिक बादल, 29°C। सुबह बौछारों की संभावना।`,
        temp: curTemp,
        uv: "UV 4 (मध्यम)",
        rainChance: "45%",
        whyContext: "मौसम विभाग के रडार एवं उपग्रह चित्रों में वायुमंडलीय परिस्थितियां सामान्य मौसमी रुझान दर्शा रही हैं।",
        factors: [
          "सुबह हल्की वर्षा के उपरांत दोपहर में धूप खिलेगी",
          "वायु गुणवत्ता सूचकांक (AQI) 128 सामान्य दायरे में",
          "सायंकाल 6 बजे के बाद शीतल पूर्वी हवाएं चलेंगी"
        ],
        suggestedAction: "आप मुझसे वर्षा, कृषि, यात्रा अथवा स्वास्थ्य संबंधी परामर्श ले सकते हैं।"
      },
      source: "meteorological_engine"
    };
  } else {
    return {
      detectedLanguage: "english",
      text: `Namaste! Atmospheric conditions in ${location} indicate partly cloudy skies with high humidity (${curTemp}, 82% humidity). Passing showers are likely around 8:30 AM. How may I assist your daily planning?`,
      structuredCard: {
        headline: "🌤️ Meteorological Summary",
        verdict: `${location}: Partly cloudy, 29°C. Morning showers likely near 8:30 AM.`,
        temp: curTemp,
        uv: "UV 4 (Moderate)",
        rainChance: "45%",
        whyContext: "IMD satellite and ground telemetry depict seasonal monsoonal cloud tracks with stable barometric pressure.",
        factors: [
          "Isolated convective shower activity tapering off by late morning",
          "Air Quality Index steady at 128 (Moderate)",
          "Comfortable easterly breeze anticipated post 6:00 PM"
        ],
        suggestedAction: "Feel free to ask about rain times, commute routes, workout windows, or farming advisories."
      },
      source: "meteorological_engine"
    };
  }
}

// Main handler connecting Gemini API or fallback
export async function handleMausamChat({
  message,
  language = "hinglish",
  persona = "commute",
  location = "India",
  weatherContext,
  history = [],
  aiClient,
}: {
  message: string;
  language?: string;
  persona?: string;
  location?: string;
  weatherContext?: any;
  history?: ChatMessage[];
  aiClient: GoogleGenAI | null;
}): Promise<ChatResponsePayload> {
  const targetLang = detectLanguage(message, language);

  // If Gemini client is available, generate dynamic response
  if (aiClient) {
    const candidateModels = [
      "gemini-flash-latest",
      "gemini-3.1-flash-lite",
      "gemini-3.8-flash",
    ];

    const langInstruction =
      targetLang === "hinglish"
        ? `Language: Natural, fluent, authentic conversational Indian Hinglish (Hindi written in clean Latin/Roman script with commonly used English and Hindi terms, e.g. "Haan, subah 8:30 baje ke aas-paas baarish ho sakti hai (78% chance). Chhaata leke nikalna better rahega."). Tone must be warm, reassuring, and realistic.`
        : targetLang === "hindi"
        ? `Language: Respectful, grammatically correct Hindi (हिंदी) in clean Devanagari script.
CRITICAL RULE: Always use standard Western numbers/digits (0, 1, 2, 3, 4, 5, 6, 7, 8, 9) for ALL metrics, temperatures, percentages, and times. NEVER use Devanagari numerals (०, १, २, etc.).`
        : `Language: Polite, authoritative, clear Indian English with accurate weather data.`;

    const systemInstruction = `You are 'Mausam Saathi' (मौसम साथी), the official intelligent meteorological AI assistant developed for the 'Mausam' application by the Ministry of Earth Sciences (MoES) and India Meteorological Department (IMD), Government of India.
Current User Persona Focus: ${persona}
Current User Location: ${location}
Live Weather Context: ${JSON.stringify(weatherContext || {})}
${langInstruction}

You must answer the user's specific query using authentic meteorological principles (radar, satellite, humidity, wind, UV, convection, soil moisture, AQI).

CRITICAL OUTPUT FORMAT:
You MUST output ONLY a valid JSON object matching this schema. No introductory or trailing markdown outside the JSON block:
{
  "detectedLanguage": "${targetLang}",
  "text": "A direct, conversational, friendly response answering their question in 1 to 3 sentences",
  "structuredCard": {
    "headline": "Short category title in the target language (e.g. '☔ Baarish & Commute Alert' or '🌾 Agromet Kisan Salah')",
    "verdict": "Clear actionable decision / answer (e.g. 'Carry umbrella this morning' / 'Postpone irrigation')",
    "temp": "e.g. '29°C'",
    "uv": "e.g. 'UV 3 (Moderate)'",
    "rainChance": "e.g. '78%'",
    "whyContext": "1-2 sentence meteorological explanation citing radar or atmospheric parameters",
    "factors": [
      "Key factor 1 explaining atmospheric or time-window reason",
      "Key factor 2 explaining ground impact or temperature",
      "Key factor 3 providing safety or practical tip"
    ],
    "suggestedAction": "Immediate takeaway advice"
  }
}`;

    const recentHistoryText = history
      .slice(-4)
      .map((h) => `${h.sender === "user" ? "User" : "Saathi"}: ${h.text}`)
      .join("\n");

    const prompt = recentHistoryText
      ? `Recent Conversation:\n${recentHistoryText}\n\nUser Question: ${message}`
      : message;

    for (const modelName of candidateModels) {
      try {
        const response = await aiClient.models.generateContent({
          model: modelName,
          contents: prompt,
          config: {
            systemInstruction,
            temperature: 0.35,
            responseMimeType: "application/json",
          },
        });

        const rawText = response.text?.trim() || "";
        if (rawText) {
          // Parse JSON safely
          const cleanJson = rawText
            .replace(/^```json\s*/i, "")
            .replace(/^```\s*/i, "")
            .replace(/```$/i, "")
            .trim();

          const parsed = JSON.parse(cleanJson);
          if (parsed && parsed.text && parsed.structuredCard) {
            return {
              text: targetLang === "hindi" ? normalizeAsciiDigits(parsed.text) : parsed.text,
              detectedLanguage: targetLang,
              structuredCard: {
                headline: targetLang === "hindi" ? normalizeAsciiDigits(parsed.structuredCard.headline || "मौसम परामर्श") : parsed.structuredCard.headline || "Meteorological Advisory",
                verdict: targetLang === "hindi" ? normalizeAsciiDigits(parsed.structuredCard.verdict || "") : parsed.structuredCard.verdict || "",
                temp: normalizeAsciiDigits(parsed.structuredCard.temp || "29°C"),
                uv: normalizeAsciiDigits(parsed.structuredCard.uv || "UV 3"),
                rainChance: normalizeAsciiDigits(parsed.structuredCard.rainChance || "20%"),
                whyContext: targetLang === "hindi" ? normalizeAsciiDigits(parsed.structuredCard.whyContext || "") : parsed.structuredCard.whyContext || "",
                factors: Array.isArray(parsed.structuredCard.factors)
                  ? parsed.structuredCard.factors.map((f: string) => targetLang === "hindi" ? normalizeAsciiDigits(f) : f)
                  : ["Favorable atmospheric parameters"],
                suggestedAction: parsed.structuredCard.suggestedAction,
              },
              source: "gemini",
            };
          }
        }
      } catch (_err: any) {
        // Model temporarily busy or unavailable - smoothly proceed to next candidate or fallback
        continue;
      }
    }
  }

  // Fallback to our high-accuracy heuristic multilingual engine
  return getFallbackMeteorologicalResponse(message, targetLang, persona, location, weatherContext);
}
