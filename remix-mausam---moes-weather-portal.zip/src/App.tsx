import React, { useState, useEffect } from 'react';
import Splash from './screens/Splash';
import Login from './screens/Login';
import ProfileSetup from './screens/ProfileSetup';
import InterestOnboarding from './screens/InterestOnboarding';
import RoutineSetup from './screens/RoutineSetup';
import NotifPrefs from './screens/NotifPrefs';
import Home from './screens/Home';
import MyDay from './screens/MyDay';
import BestWindow from './screens/BestWindow';
import Saathi from './screens/Saathi';
import TripPlanner from './screens/TripPlanner';
import Forecast from './screens/Forecast';
import AirQuality from './screens/AirQuality';
import Commute from './screens/Commute';
import NotifCenter from './screens/NotifCenter';
import Saved from './screens/Saved';
import ProfileSettings from './screens/ProfileSettings';
import KrishiMausam from './screens/KrishiMausam';
import WeatherNews from './screens/WeatherNews';
import { WeatherProvider } from './context/WeatherContext';

export type ScreenName =
  | 'splash' | 'login' | 'profile-setup' | 'interests' | 'routine' | 'notif-prefs'
  | 'home' | 'my-day' | 'best-window' | 'saathi' | 'trip-planner' | 'forecast'
  | 'air-quality' | 'commute' | 'notif-center' | 'saved' | 'profile-settings'
  | 'krishi-mausam' | 'weather-news';

export type Navigate = (screen: ScreenName) => void;

const ONBOARDING: ScreenName[] = ['splash', 'login', 'profile-setup', 'interests', 'routine', 'notif-prefs'];

type TabKey = 'home' | 'forecast' | 'saathi' | 'saved' | 'profile';

const TAB_TO_SCREEN: Record<TabKey, ScreenName> = {
  home: 'home', forecast: 'forecast', saathi: 'saathi', saved: 'saved', profile: 'profile-settings',
};

const SCREEN_TO_TAB: Partial<Record<ScreenName, TabKey>> = {
  home: 'home', forecast: 'forecast', saathi: 'saathi', saved: 'saved',
  'profile-settings': 'profile', 'my-day': 'home', 'best-window': 'home',
  'air-quality': 'home', commute: 'home', 'notif-center': 'home', 'trip-planner': 'saathi',
  'krishi-mausam': 'home', 'weather-news': 'home',
};

/* ─── Constants ──────────────────────────────────────── */
const STATUS_H = 50; // px — matches iOS safe-area-inset-top with Dynamic Island

// Top background color for each screen, used to fill the strip behind the status bar.
const SCREEN_TOP_BG: Partial<Record<ScreenName, string>> = {
  splash:             '#0A2B6E',
  home:               '#F4F7FB',
  forecast:           '#F4F7FB',
  saathi:             '#FFFFFF',
  'trip-planner':     '#FFFFFF',
  'notif-center':     '#FFFFFF',
  saved:              '#FFFFFF',
  'profile-settings': '#F4F7FB',
  'krishi-mausam':    '#064E3B',
  'weather-news':     '#0F2952',
};
const LIGHT_BG = '#F4F7FB';

// Screens whose status bar icons should be white (dark header background)
const DARK_STATUS_SCREENS: ScreenName[] = [
  'splash',
];

/* ─── Status Bar ─────────────────────────────────────── */
function StatusBar({ dark }: { dark: boolean }) {
  const [time, setTime] = useState(() => {
    const d = new Date();
    return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
  });
  useEffect(() => {
    const id = setInterval(() => {
      const d = new Date();
      setTime(d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0'));
    }, 30000);
    return () => clearInterval(id);
  }, []);

  const ic = dark ? 'white' : '#111827';
  const icO = dark ? 'rgba(255,255,255,0.6)' : 'rgba(17,24,39,0.45)';

  return (
    <div
      className="absolute top-0 left-0 right-0 flex items-center justify-between px-5"
      style={{ height: STATUS_H, zIndex: 100, pointerEvents: 'none' }}
    >
      {/* Time */}
      <span className="text-sm font-bold" style={{ color: ic, letterSpacing: '-0.3px' }}>{time}</span>

      {/* Dynamic Island pill — subtle indicator */}
      <div className="rounded-full" style={{ width: 34, height: 12, background: 'black', opacity: dark ? 0.5 : 0.18 }}/>

      {/* System icons */}
      <div className="flex items-center gap-1.5">
        {/* Signal bars */}
        <svg viewBox="0 0 17 12" className="w-4 h-3" fill="none">
          <rect x="0" y="8" width="3" height="4" rx="0.5" fill={ic}/>
          <rect x="4.5" y="5.5" width="3" height="6.5" rx="0.5" fill={ic}/>
          <rect x="9" y="3" width="3" height="9" rx="0.5" fill={ic}/>
          <rect x="13.5" y="0" width="3" height="12" rx="0.5" fill={ic}/>
        </svg>

        {/* Wi-Fi */}
        <svg viewBox="0 0 16 12" className="w-4 h-3" fill="none">
          <path d="M8 9.5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5z" fill={ic}/>
          <path d="M4.2 7.1A5.3 5.3 0 0 1 8 5.5c1.45 0 2.76.58 3.72 1.52" stroke={ic} strokeWidth="1.4" strokeLinecap="round"/>
          <path d="M1.4 4.5A9 9 0 0 1 8 2c2.56 0 4.87 1.06 6.5 2.76" stroke={ic} strokeWidth="1.4" strokeLinecap="round" opacity="0.6"/>
        </svg>

        {/* Battery */}
        <div className="flex items-center gap-0.5">
          <div className="rounded-sm flex items-center"
            style={{ width: 25, height: 12, border: `1.5px solid ${ic}`, padding: '1.5px', position: 'relative' }}>
            <div className="rounded-sm" style={{ width: '80%', height: '100%', background: ic }}/>
          </div>
          <div className="rounded-sm" style={{ width: 2, height: 6, background: icO }}/>
        </div>
      </div>
    </div>
  );
}

/* ─── Bottom Navigation ─────────────────────────────── */
function BottomNav({ active, onTab }: { active: TabKey; onTab: (t: TabKey) => void }) {
  const tabs: { key: TabKey; label: string; path: string }[] = [
    {
      key: 'home', label: 'Home',
      path: 'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
    },
    {
      key: 'forecast', label: 'Forecast',
      path: 'M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-1 16.95h2V19.5h-2v2.95zm-7.45-3.91l1.41 1.41 1.79-1.8-1.41-1.41-1.79 1.8z',
    },
    {
      key: 'saathi', label: 'Saathi',
      path: 'M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z',
    },
    {
      key: 'saved', label: 'Saved',
      path: 'M17 3H7c-1.1 0-1.99.9-1.99 2L5 21l7-3 7 3V5c0-1.1-.9-2-2-2z',
    },
    {
      key: 'profile', label: 'Profile',
      path: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z',
    },
  ];

  return (
    <div className="absolute bottom-0 left-0 right-0 flex items-end"
      style={{ background: 'white', borderTop: '1px solid var(--m-border)', paddingBottom: 20, height: 78 }}>
      {tabs.map(t => {
        const isActive = t.key === active;
        const isSaathi = t.key === 'saathi';

        if (isSaathi) {
          return (
            <button key={t.key} onClick={() => onTab(t.key)}
              className="flex-1 flex flex-col items-center" style={{ paddingTop: 0 }}>
              <div
                className="w-13 h-13 rounded-2xl flex items-center justify-center transition-all cursor-pointer hover:scale-105 active:scale-95"
                style={{
                  width: 52, height: 52,
                  marginTop: -20,
                  background: 'linear-gradient(145deg, #1A4FA0, #2563EB)',
                  boxShadow: '0 4px 16px rgba(26,79,160,0.4)',
                  border: '3px solid white',
                }}>
                <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
                  <path d={t.path}/>
                </svg>
              </div>
              <span className="text-[10px] font-bold mt-1" style={{ color: 'var(--m-blue)' }}>{t.label}</span>
            </button>
          );
        }

        return (
          <button key={t.key} onClick={() => onTab(t.key)}
            className="flex-1 flex flex-col items-center gap-0.5 pt-3 cursor-pointer">
            <div className="relative">
              <svg viewBox="0 0 24 24" className="w-5 h-5 transition-colors"
                style={{ fill: isActive ? 'var(--m-blue)' : '#9CA3AF' }}>
                <path d={t.path}/>
              </svg>
            </div>
            <span className="text-[10px] font-bold transition-colors"
              style={{ color: isActive ? 'var(--m-blue)' : '#9CA3AF' }}>
              {t.label}
            </span>
            {isActive && (
              <div className="w-5 h-0.5 rounded-full" style={{ background: 'var(--m-blue)', marginTop: 2 }}/>
            )}
          </button>
        );
      })}
    </div>
  );
}

/* ─── Main App View ──────────────────────────────────── */
function MainAppContent() {
  const [screen, setScreen] = useState<ScreenName>('splash');
  const [activeTab, setActiveTab] = useState<TabKey>('home');
  const [interests, setInterests] = useState<string[]>(['commute', 'agriculture', 'storm-alerts']);

  const navigate: Navigate = (s: ScreenName) => {
    setScreen(s);
    const tab = SCREEN_TO_TAB[s];
    if (tab) setActiveTab(tab);
  };

  const handleInterestsComplete = (ids: string[]) => {
    setInterests(ids.length > 0 ? ids : ['everyday']);
    navigate('routine');
  };

  const handleTab = (t: TabKey) => {
    setActiveTab(t);
    setScreen(TAB_TO_SCREEN[t]);
  };

  const isOnboarding = ONBOARDING.includes(screen);
  const isDarkStatus = DARK_STATUS_SCREENS.includes(screen);
  const wrapBg = SCREEN_TOP_BG[screen] ?? LIGHT_BG;

  const renderScreen = () => {
    switch (screen) {
      case 'splash': return <Splash navigate={navigate}/>;
      case 'login': return <Login navigate={navigate}/>;
      case 'profile-setup': return <ProfileSetup navigate={navigate}/>;
      case 'interests': return <InterestOnboarding navigate={navigate} onComplete={handleInterestsComplete}/>;
      case 'routine': return <RoutineSetup navigate={navigate}/>;
      case 'notif-prefs': return <NotifPrefs navigate={navigate}/>;
      case 'home': return <Home navigate={navigate} interests={interests}/>;
      case 'my-day': return <MyDay navigate={navigate}/>;
      case 'best-window': return <BestWindow navigate={navigate}/>;
      case 'saathi': return <Saathi navigate={navigate} interests={interests}/>;
      case 'trip-planner': return <TripPlanner navigate={navigate}/>;
      case 'forecast': return <Forecast navigate={navigate}/>;
      case 'air-quality': return <AirQuality navigate={navigate}/>;
      case 'commute': return <Commute navigate={navigate}/>;
      case 'notif-center': return <NotifCenter navigate={navigate}/>;
      case 'saved': return <Saved navigate={navigate}/>;
      case 'profile-settings': return <ProfileSettings navigate={navigate}/>;
      case 'krishi-mausam': return <KrishiMausam navigate={navigate}/>;
      case 'weather-news': return <WeatherNews navigate={navigate}/>;
      default: return <Home navigate={navigate} interests={interests}/>;
    }
  };

  return (
    <div className="app-phone-container">
      <div className="relative flex flex-col hide-scroll w-full h-full overflow-hidden">
        {/* Status bar — transparent overlay; sits above everything at z-100. */}
        <StatusBar dark={isDarkStatus}/>

        {/* Screen content */}
        <div className="flex-1 overflow-y-auto hide-scroll relative" style={{ paddingBottom: isOnboarding ? 0 : 78 }}>
          <div style={{ paddingTop: STATUS_H, background: wrapBg, minHeight: '100%' }}>
            {renderScreen()}
          </div>
        </div>

        {/* Bottom nav */}
        {!isOnboarding && <BottomNav active={activeTab} onTab={handleTab}/>}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <WeatherProvider>
      <MainAppContent />
    </WeatherProvider>
  );
}
