import React, { useState } from 'react';
import { Sparkles, Volume2, VolumeX, CheckCircle2, Bot, ShieldCheck } from 'lucide-react';
import { AppLanguage, PersonaType } from '../types';

interface AiWeatherAdvisoryProps {
  advisory: {
    badgeEn: string;
    badgeHi: string;
    headlineEn: string;
    headlineHi: string;
    contentEn: string;
    contentHi: string;
    actionItemsEn: string[];
    actionItemsHi: string[];
    timestamp: string;
  };
  activePersona: PersonaType;
  language: AppLanguage;
}

export const AiWeatherAdvisory: React.FC<AiWeatherAdvisoryProps> = ({
  advisory,
  activePersona,
  language,
}) => {
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Border & badge theme styling based on active persona
  const themeColors =
    activePersona === 'farmer'
      ? {
          cardBg: 'bg-linear-to-br from-amber-50/90 via-emerald-50/40 to-white',
          border: 'border-amber-300',
          badge: 'bg-amber-600 text-white',
          iconBg: 'bg-amber-100 text-amber-800',
          actionBullet: 'text-emerald-700',
        }
      : activePersona === 'commuter'
      ? {
          cardBg: 'bg-linear-to-br from-blue-50/90 via-indigo-50/40 to-white',
          border: 'border-blue-300',
          badge: 'bg-blue-600 text-white',
          iconBg: 'bg-blue-100 text-blue-800',
          actionBullet: 'text-blue-700',
        }
      : {
          cardBg: 'bg-linear-to-br from-cyan-50/90 via-slate-50/50 to-white',
          border: 'border-cyan-300',
          badge: 'bg-cyan-800 text-white',
          iconBg: 'bg-cyan-100 text-cyan-900',
          actionBullet: 'text-cyan-800',
        };

  const handleSpeakAloud = () => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToSpeak = `${language === 'hi' ? advisory.headlineHi : advisory.headlineEn}. ${
      language === 'hi' ? advisory.contentHi : advisory.contentEn
    }`;

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.rate = 0.95;

    // Try to find native voice
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(
      (v) =>
        (language === 'hi' && v.lang.includes('hi')) ||
        (language === 'en' && (v.lang === 'en-IN' || v.lang.includes('en')))
    );
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  return (
    <div
      id="ai-weather-advisory-card"
      className={`mx-3 mt-3 p-3.5 rounded-2xl border-2 ${themeColors.border} ${themeColors.cardBg} shadow-xs`}
    >
      {/* Header bar */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-1.5">
          <div className={`w-7 h-7 rounded-lg ${themeColors.iconBg} flex items-center justify-center shadow-xs`}>
            <Sparkles className="w-4 h-4 text-amber-600 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded uppercase ${themeColors.badge}`}>
                {language === 'hi' ? advisory.badgeHi : advisory.badgeEn}
              </span>
              <span className="text-[9px] text-slate-500 font-mono">
                AI Mausam
              </span>
            </div>
            <h3 className="text-xs font-black text-slate-900 leading-snug mt-0.5">
              {language === 'hi' ? advisory.headlineHi : advisory.headlineEn}
            </h3>
          </div>
        </div>

        {/* Read aloud button */}
        <button
          onClick={handleSpeakAloud}
          className={`p-1.5 rounded-lg border transition-all flex items-center gap-1 text-[10px] font-bold shrink-0 ${
            isSpeaking
              ? 'bg-amber-600 text-white border-amber-600 animate-pulse'
              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
          }`}
          title={language === 'hi' ? 'सलाह को आवाज में सुनें' : 'Read advisory aloud'}
        >
          {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          <span>{isSpeaking ? (language === 'hi' ? 'रोकें' : 'Stop') : (language === 'hi' ? 'सुनें' : 'Audio')}</span>
        </button>
      </div>

      {/* Main advisory paragraph */}
      <p className="text-[11px] font-medium leading-relaxed text-slate-800 bg-white/75 p-2.5 rounded-xl border border-slate-200/80 mt-1.5">
        {language === 'hi' ? advisory.contentHi : advisory.contentEn}
      </p>

      {/* Action items */}
      <div className="mt-2 space-y-1">
        <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider block">
          {language === 'hi' ? 'अनुशंसित त्वरित कदम:' : 'Actionable Guidelines:'}
        </span>
        {(language === 'hi' ? advisory.actionItemsHi : advisory.actionItemsEn).map((item, i) => (
          <div key={i} className="flex items-start gap-1.5 text-[11px] text-slate-800">
            <CheckCircle2 className={`w-3.5 h-3.5 ${themeColors.actionBullet} shrink-0 mt-0.5`} />
            <span className="leading-snug">{item}</span>
          </div>
        ))}
      </div>

      {/* Footer telemetry source */}
      <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[9px] text-slate-500">
        <span className="flex items-center gap-1">
          <ShieldCheck className="w-3 h-3 text-emerald-600" />
          {advisory.timestamp}
        </span>
        <span className="font-mono">MoES HPC Mihir Grid</span>
      </div>
    </div>
  );
};
