import React, { useState } from 'react';
import { AlertTriangle, ChevronDown, ChevronUp, Radio, Volume2, ShieldAlert, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppLanguage, PersonaType } from '../types';

interface ContextualAlertBannerProps {
  activePersona: PersonaType;
  language: AppLanguage;
  alertData?: {
    level: 'Orange' | 'Red' | 'Yellow';
    levelHi: 'ऑरेंज' | 'रेड' | 'येलो';
    titleEn: string;
    titleHi: string;
    timeframeEn: string;
    timeframeHi: string;
    detailsEn: string;
    detailsHi: string;
  };
}

export const ContextualAlertBanner: React.FC<ContextualAlertBannerProps> = ({
  activePersona,
  language,
  alertData,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isPlayingChime, setIsPlayingChime] = useState(false);

  // Strictly respect requirement: stays at top ONLY when Commuter/Traveler mode is active
  if (activePersona === 'farmer' || !alertData || isDismissed) {
    return null;
  }

  const isRed = alertData.level === 'Red';
  const colorClasses = isRed
    ? {
        bg: 'bg-red-500/10 border-red-500',
        badge: 'bg-red-600 text-white',
        text: 'text-red-900',
        accent: 'text-red-600',
        subText: 'text-red-700',
        button: 'bg-red-600 hover:bg-red-700 text-white',
      }
    : {
        bg: 'bg-amber-500/10 border-amber-500',
        badge: 'bg-amber-500 text-slate-950',
        text: 'text-amber-950',
        accent: 'text-amber-600',
        subText: 'text-amber-800',
        button: 'bg-amber-600 hover:bg-amber-700 text-white',
      };

  const playAlertSiren = () => {
    try {
      setIsPlayingChime(true);
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      
      const now = audioCtx.currentTime;
      const osc1 = audioCtx.createOscillator();
      const osc2 = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(isRed ? 880 : 660, now);
      osc1.frequency.exponentialRampToValueAtTime(isRed ? 440 : 520, now + 0.35);

      osc2.type = 'sawtooth';
      osc2.frequency.setValueAtTime(isRed ? 440 : 330, now);

      gainNode.gain.setValueAtTime(0.2, now);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.6);

      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.6);
      osc2.stop(now + 0.6);

      setTimeout(() => setIsPlayingChime(false), 700);
    } catch {
      setIsPlayingChime(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className={`mx-3 mt-2.5 rounded-xl border-2 p-3 ${colorClasses.bg} shadow-md overflow-hidden transition-all`}
    >
      <div className="flex items-start gap-2.5">
        {/* Pulsing Beacon Icon */}
        <div className="relative shrink-0 mt-0.5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-white shadow-xs">
            <AlertTriangle className={`w-5 h-5 ${colorClasses.accent} animate-bounce`} />
          </div>
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-600" />
          </span>
        </div>

        {/* Alert Header & Primary Message */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap mb-1">
            <span className={`text-[10px] uppercase font-black px-1.5 py-0.5 rounded tracking-wide ${colorClasses.badge}`}>
              {language === 'hi' ? `${alertData.levelHi} अलर्ट` : `${alertData.level} Alert`}
            </span>
            <span className="text-[10px] font-bold text-slate-600 flex items-center gap-1">
              <Radio className="w-3 h-3 text-red-500 animate-pulse" />
              {language === 'hi' ? 'आईएमडी तत्काल चेतावनी' : 'IMD Urgent Broadcast'}
            </span>
          </div>

          <h2 className={`text-xs font-bold leading-snug ${colorClasses.text}`}>
            {language === 'hi' ? alertData.titleHi : alertData.titleEn}
          </h2>

          <p className={`text-[11px] font-medium mt-0.5 ${colorClasses.subText}`}>
            {language === 'hi' ? alertData.timeframeHi : alertData.timeframeEn}
          </p>

          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-2 pt-2 border-t border-slate-300/60 text-xs text-slate-800 space-y-2"
              >
                <p className="text-[11px] leading-relaxed bg-white/70 p-2 rounded-lg border border-slate-200">
                  {language === 'hi' ? alertData.detailsHi : alertData.detailsEn}
                </p>

                <div className="flex items-center justify-between gap-2 text-[10px] text-slate-600">
                  <span className="font-semibold">
                    {language === 'hi' ? 'आपदा प्रबंधन हेल्पलाइन: 1077' : 'Disaster Helpline: 1077'}
                  </span>
                  <button
                    onClick={playAlertSiren}
                    className="flex items-center gap-1 px-2 py-1 rounded bg-white border border-slate-300 font-medium hover:bg-slate-50 transition-colors"
                  >
                    <Volume2 className="w-3 h-3 text-slate-700" />
                    <span>{isPlayingChime ? (language === 'hi' ? 'ध्वनि सक्रिय...' : 'Playing...') : (language === 'hi' ? 'साइरन सुनें' : 'Test Siren')}</span>
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Action buttons: Expand & Dismiss */}
        <div className="flex flex-col gap-1 shrink-0">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded-md bg-white/80 hover:bg-white text-slate-700 transition-colors shadow-2xs"
            title="Expand Details"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setIsDismissed(true)}
            className="p-1 rounded-md bg-white/80 hover:bg-white text-slate-400 hover:text-slate-600 transition-colors shadow-2xs"
            title="Dismiss Alert"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};
