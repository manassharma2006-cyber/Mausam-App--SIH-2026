import React from 'react';
import { MapPin, Bell, Volume2, Settings, ShieldAlert, Sparkles, Search } from 'lucide-react';
import { AppLanguage, PersonaType, LocationInfo, HumidityAlert } from '../types';
import { translations } from '../data/translations';

interface HeaderProps {
  language: AppLanguage;
  onLanguageChange: (lang: AppLanguage) => void;
  activePersona: PersonaType;
  location: LocationInfo;
  onOpenSettings: () => void;
  onOpenTalkBack: () => void;
  onOpenHumidityAlert?: () => void;
  humidityAlert?: HumidityAlert;
  hasUnreadHumidityAlert?: boolean;
  onLocationClick?: () => void;
  onOpenLocation?: () => void;
  onOpenSearch?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageChange,
  activePersona,
  location,
  onOpenSettings,
  onOpenTalkBack,
  onOpenHumidityAlert,
  humidityAlert,
  hasUnreadHumidityAlert = false,
  onLocationClick,
  onOpenLocation,
  onOpenSearch,
}) => {
  const handleLocationTrigger = onOpenSearch || onLocationClick || onOpenLocation;
  const t = translations[language];

  // Theme accent borders based on active persona
  const personaAccent =
    activePersona === 'farmer'
      ? 'border-amber-500 bg-amber-50/70 text-amber-900'
      : activePersona === 'commuter'
      ? 'border-blue-500 bg-blue-50/70 text-blue-900'
      : 'border-cyan-500 bg-cyan-50/70 text-cyan-950';

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md shadow-xs border-b border-slate-200">
      {/* Authentic Indian Government Tricolor Header Bar */}
      <div className="h-1.5 w-full flex">
        <div className="flex-1 bg-[#FF9933]" />
        <div className="flex-1 bg-white relative flex items-center justify-center">
          <div className="w-1.5 h-1.5 rounded-full border border-blue-800" />
        </div>
        <div className="flex-1 bg-[#138808]" />
      </div>

      <div className="px-3.5 py-2.5">
        {/* National Emblem & Department Identification */}
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            {/* National Emblem SVG Icon */}
            <div className="w-8 h-8 rounded-full bg-slate-50 border border-slate-300 flex items-center justify-center shadow-xs text-blue-900 shrink-0">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current text-blue-900" aria-label="MoES IMD Emblem">
                <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.2" />
                {/* 24 spokes representation */}
                {[...Array(12)].map((_, i) => (
                  <line
                    key={i}
                    x1="12"
                    y1="3.5"
                    x2="12"
                    y2="20.5"
                    stroke="currentColor"
                    strokeWidth="0.75"
                    transform={`rotate(${i * 15} 12 12)`}
                  />
                ))}
                <circle cx="12" cy="12" r="2.5" fill="currentColor" />
              </svg>
            </div>

            <div className="leading-tight">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-bold tracking-wider uppercase text-slate-600 font-emblem">
                  {t.govtIndia}
                </span>
                <span className="text-[9px] px-1 py-0.2 rounded bg-amber-100 text-amber-900 font-semibold">
                  SIH26076
                </span>
              </div>
              <h1 className="text-xs font-bold text-slate-900 flex items-center gap-1">
                <span className="text-amber-700 font-extrabold">{t.appName}</span>
                <span className="text-slate-400">|</span>
                <span className="text-[11px] text-slate-700 font-medium truncate max-w-[170px] sm:max-w-[210px]">
                  {language === 'hi' ? 'पृथ्वी विज्ञान मंत्रालय' : 'Ministry of Earth Sciences'}
                </span>
              </h1>
            </div>
          </div>

          {/* Quick Language Switcher Pill + Settings */}
          <div className="flex items-center gap-1.5">
            {/* Search Location Button */}
            <button
              id="search-header-btn"
              onClick={handleLocationTrigger}
              className="p-1.5 rounded-full bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 transition-colors shadow-2xs flex items-center justify-center"
              title={language === 'hi' ? 'स्थान खोजें' : 'Search Location'}
            >
              <Search className="w-4 h-4 text-emerald-700" />
            </button>

            {/* Direct Language Switch Button */}
            <button
              id="lang-toggle-btn"
              onClick={() => onLanguageChange(language === 'en' ? 'hi' : 'en')}
              className="flex items-center gap-1 px-2 py-1 rounded-full border border-slate-300 bg-slate-50 hover:bg-slate-100 text-[11px] font-semibold text-slate-800 transition-colors shadow-2xs"
              title="Toggle Language / भाषा बदलें"
            >
              <span className={language === 'en' ? 'text-amber-700 font-bold' : 'text-slate-500'}>EN</span>
              <span className="text-slate-300">/</span>
              <span className={language === 'hi' ? 'text-green-700 font-bold' : 'text-slate-500'}>हि</span>
            </button>

            {/* Talk Back / Mausam Vani trigger */}
            <button
              id="talk-back-header-btn"
              onClick={onOpenTalkBack}
              className="p-1.5 rounded-full bg-linear-to-r from-amber-500 to-orange-500 text-white shadow-xs hover:from-amber-600 hover:to-orange-600 transition-all active:scale-95 flex items-center justify-center relative"
              title={t.talkBackBtn}
            >
              <Volume2 className="w-4 h-4" />
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-white animate-pulse" />
            </button>

            {/* Humidity Alert Bell Indicator */}
            <button
              id="humidity-alert-bell"
              onClick={onOpenHumidityAlert}
              className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors relative"
              title={t.humidityAlertTitle}
            >
              <Bell className="w-4 h-4" />
              {hasUnreadHumidityAlert && (
                <span className="absolute -top-0.5 -right-0.5 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-600 ring-1 ring-white" />
                </span>
              )}
            </button>

            {/* Settings Gear */}
            <button
              id="settings-gear-btn"
              onClick={onOpenSettings}
              className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
              title={t.settingsTitle}
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Location & Station Status Strip */}
        <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100">
          <button
            id="header-location-strip-btn"
            onClick={handleLocationTrigger}
            className="flex items-center gap-1.5 text-left group hover:opacity-90 transition-opacity flex-1 min-w-0"
          >
            <div className="w-5 h-5 rounded-md bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <MapPin className="w-3 h-3" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-xs font-bold text-slate-900 group-hover:text-emerald-700 transition-colors truncate">
                  {language === 'hi' ? location.nameHi : location.nameEn}
                </span>
                <span className="text-[10px] text-slate-500 shrink-0">
                  ({language === 'hi' ? location.stateHi : location.stateEn})
                </span>
                <span className="text-[9px] px-1 py-0.2 rounded bg-slate-100 text-slate-600 font-semibold group-hover:bg-emerald-100 group-hover:text-emerald-800 shrink-0 flex items-center gap-0.5 ml-0.5">
                  <Search className="w-2.5 h-2.5 text-emerald-600" />
                  <span>{language === 'hi' ? 'स्थान खोजें' : 'Search'}</span>
                </span>
              </div>
              <div className="text-[9px] text-slate-500 font-mono flex items-center gap-1 truncate">
                <span>{location.stationId}</span>
                <span>•</span>
                <span>{location.elevation}</span>
              </div>
            </div>
          </button>

          {/* Persona Mode Indicator Badge */}
          <div className={`px-2 py-0.5 rounded-full border text-[10px] font-bold shrink-0 ${personaAccent}`}>
            {activePersona === 'farmer' && (language === 'hi' ? '🌾 कृषक मोड' : '🌾 Agri-Mode')}
            {activePersona === 'commuter' && (language === 'hi' ? '🚆 शहर मोड' : '🚆 City-Mode')}
            {activePersona === 'traveler' && (language === 'hi' ? '⚓ तटीय मोड' : '⚓ Marine-Mode')}
          </div>
        </div>
      </div>
    </header>
  );
};
