import React, { useState } from 'react';
import { Droplets, AlertCircle, ArrowUpRight, CheckCircle2, Sliders, BellRing, Sparkles, X } from 'lucide-react';
import { HumidityAlert, AppLanguage, PersonaType } from '../types';
import { translations } from '../data/translations';

interface HumidityAlertSystemProps {
  alert: HumidityAlert;
  language: AppLanguage;
  activePersona: PersonaType;
  onSimulateSurge: () => void;
  isOpenModal?: boolean;
  onCloseModal?: () => void;
}

export const HumidityAlertSystem: React.FC<HumidityAlertSystemProps> = ({
  alert,
  language,
  activePersona,
  onSimulateSurge,
  isOpenModal,
  onCloseModal,
}) => {
  const [alertThreshold, setAlertThreshold] = useState<number>(15);
  const [dismissed, setDismissed] = useState<boolean>(false);
  const t = translations[language];

  // Specific impact based on active persona
  const getPersonaImpact = () => {
    switch (activePersona) {
      case 'farmer':
        return {
          title: language === 'hi' ? 'कृषि व फसल प्रभाव (Agro Impact)' : 'Agricultural Crop Impact',
          desc: language === 'hi' ? alert.farmerImpactHi : alert.farmerImpactEn,
          action: language === 'hi' ? 'पत्तियों पर नमी सूखने तक फफूंदनाशी छिड़काव रोकें' : 'Withhold foliar spray; inspect for paddy blast',
          badgeColor: 'bg-emerald-100 text-emerald-900 border-emerald-300',
        };
      case 'commuter':
        return {
          title: language === 'hi' ? 'शहरी यात्री प्रभाव (Commuter Impact)' : 'Urban Commuter Heat Index',
          desc: language === 'hi' ? alert.commuterImpactHi : alert.commuterImpactEn,
          action: language === 'hi' ? 'पर्याप्त पानी पिएं; एसी से निकलते समय चश्मे की धुंध से सावधान रहें' : 'Carry electrolyte hydration; beware of glasses fogging',
          badgeColor: 'bg-blue-100 text-blue-900 border-blue-300',
        };
      case 'traveler':
      default:
        return {
          title: language === 'hi' ? 'तटीय व नाविक प्रभाव (Marine Impact)' : 'Maritime Navigation & Fog Impact',
          desc: language === 'hi' ? alert.travelerImpactHi : alert.travelerImpactEn,
          action: language === 'hi' ? 'तटीय कोहरे में रडार व फॉग हॉर्न का निरंतर उपयोग करें' : 'Engage navigational fog horn & reduced speed',
          badgeColor: 'bg-cyan-100 text-cyan-900 border-cyan-300',
        };
    }
  };

  const impact = getPersonaImpact();

  if (dismissed && !isOpenModal) {
    return (
      <div className="mx-3 mt-2.5 p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 text-slate-600">
          <Droplets className="w-3.5 h-3.5 text-blue-500" />
          <span>{language === 'hi' ? 'आर्द्रता मॉनिटर सक्रिय (88%)' : 'Humidity Monitor Active (88% RH)'}</span>
        </div>
        <button
          onClick={() => setDismissed(false)}
          className="text-[10px] font-bold text-amber-700 hover:underline"
        >
          {language === 'hi' ? 'चेतावनी देखें' : 'View Alert'}
        </button>
      </div>
    );
  }

  const content = (
    <div className="space-y-3">
      {/* Alert Banner Main */}
      <div className="p-3 rounded-xl bg-linear-to-r from-amber-50 to-orange-50 border-2 border-amber-300 shadow-xs">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-start gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
              <Droplets className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-amber-200 text-amber-900 uppercase">
                  {language === 'hi' ? 'आर्द्रता परिवर्तन चेतावनी' : 'Humidity Shift Alert'}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {alert.timestamp}
                </span>
              </div>
              <h4 className="text-xs font-bold text-slate-900 mt-0.5 leading-snug">
                {language === 'hi' ? alert.titleHi : alert.titleEn}
              </h4>
            </div>
          </div>

          {!isOpenModal && (
            <button
              onClick={() => setDismissed(true)}
              className="p-1 rounded text-slate-400 hover:text-slate-600"
              title="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Telemetry Metric Cards */}
        <div className="grid grid-cols-3 gap-2 mt-2.5 pt-2 border-t border-amber-200/60 text-center">
          <div className="p-1.5 rounded-lg bg-white/80 border border-amber-200 shadow-2xs">
            <span className="text-[9px] text-slate-500 block">
              {language === 'hi' ? 'पिछली आर्द्रता' : 'Baseline RH'}
            </span>
            <span className="text-xs font-bold text-slate-700">
              {alert.previousHumidity}%
            </span>
          </div>

          <div className="p-1.5 rounded-lg bg-white/80 border border-amber-200 shadow-2xs">
            <span className="text-[9px] text-slate-500 block">
              {language === 'hi' ? 'वर्तमान आर्द्रता' : 'Current RH'}
            </span>
            <span className="text-xs font-extrabold text-amber-700">
              {alert.currentHumidity}%
            </span>
          </div>

          <div className="p-1.5 rounded-lg bg-white/80 border border-amber-200 shadow-2xs">
            <span className="text-[9px] text-slate-500 block">
              {language === 'hi' ? 'ओसांक (Dew Pt)' : 'Dew Point'}
            </span>
            <span className="text-xs font-bold text-blue-700">
              {alert.dewPoint}°C
            </span>
          </div>
        </div>

        {/* Persona Tailored Action Alert */}
        <div className={`mt-2.5 p-2 rounded-lg border ${impact.badgeColor}`}>
          <div className="text-[10px] font-bold uppercase tracking-wide">
            {impact.title}
          </div>
          <p className="text-[11px] font-medium leading-tight mt-0.5 text-slate-800">
            {impact.desc}
          </p>
          <div className="mt-1.5 text-[10px] font-bold text-slate-900 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
            <span>{impact.action}</span>
          </div>
        </div>
      </div>

      {/* Simulator and Threshold Controls */}
      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-1.5 font-bold text-slate-800">
            <Sliders className="w-3.5 h-3.5 text-slate-500" />
            <span>{language === 'hi' ? 'चेतावनी सीमा (Alert Threshold)' : 'Sensitivity Threshold'}</span>
          </div>
          <span className="font-mono font-bold text-amber-700">
            ±{alertThreshold}% in 3h
          </span>
        </div>

        <input
          type="range"
          min="5"
          max="30"
          value={alertThreshold}
          onChange={(e) => setAlertThreshold(Number(e.target.value))}
          className="w-full accent-amber-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
        />

        <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200 text-[10px]">
          <span className="text-slate-500">
            {language === 'hi' ? 'परीक्षण हेतु सिमुलेशन:' : 'Simulate sudden weather front:'}
          </span>
          <button
            id="simulate-humidity-surge-btn"
            onClick={onSimulateSurge}
            className="flex items-center gap-1 px-2 py-1 rounded bg-amber-600 hover:bg-amber-700 text-white font-bold transition-all shadow-xs"
          >
            <Sparkles className="w-3 h-3 text-amber-200" />
            <span>{language === 'hi' ? 'आर्द्रता उछाल टेस्ट करें' : 'Trigger Spike Test'}</span>
          </button>
        </div>
      </div>
    </div>
  );

  // If in dedicated modal mode
  if (isOpenModal) {
    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 animate-fade-in">
        <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
          <div className="p-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-amber-500 text-white flex items-center justify-center">
                <BellRing className="w-3.5 h-3.5" />
              </div>
              <h3 className="text-xs font-bold text-slate-900">
                {t.humidityAlertTitle}
              </h3>
            </div>
            {onCloseModal && (
              <button
                onClick={onCloseModal}
                className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="p-3.5 max-h-[80vh] overflow-y-auto">
            {content}
          </div>

          <div className="p-2.5 border-t border-slate-100 bg-slate-50 flex justify-end">
            <button
              onClick={onCloseModal}
              className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold hover:bg-slate-800"
            >
              {t.close}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-3 mt-3">
      {content}
    </div>
  );
};
