import React, { useState } from 'react';
import { CloudRain, Info, Droplets, Calendar } from 'lucide-react';
import { DayForecast, AppLanguage } from '../types';
import { translations } from '../data/translations';

interface InteractiveRainfallChartProps {
  forecast: DayForecast[];
  language: AppLanguage;
}

export const InteractiveRainfallChart: React.FC<InteractiveRainfallChartProps> = ({
  forecast,
  language,
}) => {
  const [activeDayIdx, setActiveDayIdx] = useState<number>(0);
  const t = translations[language];

  const activeDay = forecast[activeDayIdx] || forecast[0];
  const maxRainMm = Math.max(...forecast.map((f) => f.rainfallMm), 25);

  return (
    <div className="mx-3 mt-3 p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
            <CloudRain className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900 leading-tight">
              {t.sevenDayTrend}
            </h3>
            <p className="text-[10px] text-slate-500">
              {language === 'hi' ? 'दैनिक वर्षापात (मिमी) एवं संभावना (%)' : 'Daily precipitation depth (mm) & chance (%)'}
            </p>
          </div>
        </div>

        {/* Legend pill */}
        <div className="flex items-center gap-2 text-[9px] font-semibold text-slate-600 bg-slate-50 px-2 py-1 rounded-md border border-slate-200">
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-xs bg-emerald-600" />
            <span>{t.rainfallMm}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-blue-500" />
            <span>% Rain</span>
          </div>
        </div>
      </div>

      {/* Interactive Chart Container */}
      <div className="relative pt-3 pb-1">
        <div className="grid grid-cols-7 gap-1.5 items-end h-32 px-1 border-b border-slate-200">
          {forecast.map((day, idx) => {
            const isSelected = idx === activeDayIdx;
            const barHeightPercent = Math.max(12, Math.round((day.rainfallMm / maxRainMm) * 85));

            return (
              <button
                key={day.date}
                onClick={() => setActiveDayIdx(idx)}
                className="group relative flex flex-col items-center h-full justify-end focus:outline-none"
              >
                {/* Probability bubble above bar */}
                <span
                  className={`text-[9px] font-extrabold mb-1 px-1 rounded-full transition-all ${
                    day.rainProb > 60
                      ? 'bg-blue-600 text-white'
                      : day.rainProb > 30
                      ? 'bg-blue-100 text-blue-800'
                      : 'text-slate-400'
                  }`}
                >
                  {day.rainProb}%
                </span>

                {/* Animated Rainfall Bar */}
                <div
                  className={`w-full max-w-[26px] rounded-t-md transition-all duration-300 relative ${
                    isSelected
                      ? 'bg-gradient-to-t from-emerald-700 via-emerald-600 to-teal-400 shadow-md ring-2 ring-emerald-500 ring-offset-1'
                      : 'bg-emerald-500/80 hover:bg-emerald-600'
                  }`}
                  style={{ height: `${barHeightPercent}%` }}
                >
                  {day.rainfallMm > 0 && (
                    <span className="absolute bottom-1 inset-x-0 text-[8px] font-mono font-bold text-white text-center leading-none">
                      {day.rainfallMm}
                    </span>
                  )}
                </div>

                {/* Day label underneath */}
                <div className="mt-1.5 text-center">
                  <span className={`text-[10px] font-bold block ${isSelected ? 'text-emerald-800' : 'text-slate-600'}`}>
                    {language === 'hi' ? day.dayHi : day.dayEn}
                  </span>
                  <span className="text-[8px] text-slate-400 block -mt-0.5">
                    {day.date.split(' ')[0]}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Day Actionable Summary Banner */}
      <div className="mt-2.5 p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-200 flex items-center justify-between text-xs">
        <div>
          <div className="flex items-center gap-1.5 font-bold text-emerald-950">
            <Calendar className="w-3.5 h-3.5 text-emerald-700" />
            <span>
              {language === 'hi' ? activeDay.dayHi : activeDay.dayEn} ({activeDay.date}):{' '}
              {language === 'hi' ? activeDay.conditionHi : activeDay.conditionEn}
            </span>
          </div>
          <div className="text-[11px] text-emerald-800 mt-0.5">
            {language === 'hi' ? 'अनुमानित वर्षा:' : 'Forecasted Rain:'}{' '}
            <span className="font-extrabold">{activeDay.rainfallMm} mm</span> |{' '}
            {language === 'hi' ? 'तापमान:' : 'Temp Range:'}{' '}
            <span className="font-semibold">{activeDay.tempMin}°C - {activeDay.tempMax}°C</span>
          </div>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-emerald-200 text-emerald-900">
            {activeDay.rainProb >= 70
              ? (language === 'hi' ? 'भारी वर्षा संभावना' : 'High Rain Risk')
              : activeDay.rainProb >= 40
              ? (language === 'hi' ? 'मध्यम वर्षा' : 'Moderate Showers')
              : (language === 'hi' ? 'अनुकूल शुष्क' : 'Favorable Dry')}
          </span>
        </div>
      </div>
    </div>
  );
};
