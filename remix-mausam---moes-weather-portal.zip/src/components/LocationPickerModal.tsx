import React, { useState } from 'react';
import { useWeather } from '../context/WeatherContext';
import { majorIndianCities } from '../data/indianLocations';
import type { LocationInfo } from '../types';
import {
  Search,
  MapPin,
  X,
  LocateFixed,
  Check,
  Building2,
  Sparkles,
  ChevronRight,
  Thermometer,
} from 'lucide-react';

interface LocationPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function LocationPickerModal({
  isOpen,
  onClose,
}: LocationPickerModalProps) {
  const { weatherData, switchLocation, tempUnit, setTempUnit } = useWeather();
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  // Suggested locations requested by user
  const suggestions = [
    {
      nameEn: 'Vasundhara, Ghaziabad',
      stateEn: 'Uttar Pradesh',
      districtEn: 'Ghaziabad',
      stationId: 'GZB-01',
      temp: '29°C',
      tag: 'Home routine',
    },
    {
      nameEn: 'Cyber City, Gurugram',
      stateEn: 'Haryana',
      districtEn: 'Gurugram',
      stationId: 'GGM-02',
      temp: '30°C',
      tag: 'Work destination',
    },
    {
      nameEn: 'Connaught Place, Delhi',
      stateEn: 'Delhi NCR',
      districtEn: 'Central Delhi',
      stationId: 'DL-01',
      temp: '30°C',
      tag: 'Capital center',
    },
    {
      nameEn: 'Noida Sector 62',
      stateEn: 'Uttar Pradesh',
      districtEn: 'Gautam Buddha Nagar',
      stationId: 'NOI-03',
      temp: '29°C',
      tag: 'Tech hub',
    },
    {
      nameEn: 'Jaipur, Rajasthan',
      stateEn: 'Rajasthan',
      districtEn: 'Jaipur',
      stationId: 'JPR-01',
      temp: '32°C',
      tag: 'Saved trip',
    },
  ];

  const handleSelect = (loc: (typeof suggestions)[0]) => {
    switchLocation({
      nameEn: loc.nameEn,
      nameHi: loc.nameEn,
      stateEn: loc.stateEn,
      stateHi: loc.stateEn,
      districtEn: loc.districtEn,
      districtHi: loc.districtEn,
      stationId: loc.stationId,
      coordinates: { lat: 28.6692, lon: 77.4538 },
      elevation: 216,
      stationType: 'AWS',
    });
    onClose();
  };

  const filtered = query.trim()
    ? majorIndianCities
        .filter(
          (c) =>
            c.nameEn.toLowerCase().includes(query.toLowerCase()) ||
            c.stateEn.toLowerCase().includes(query.toLowerCase())
        )
        .slice(0, 8)
    : [];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-white rounded-t-[32px] sm:rounded-3xl p-5 shadow-2xl border border-slate-100 flex flex-col max-h-[85vh] z-10 animate-in slide-in-from-bottom-6 duration-250">
        {/* Handle */}
        <div className="w-12 h-1 bg-slate-200 rounded-full mx-auto mb-3" />

        {/* Modal Top Bar */}
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-base font-black text-slate-900">
              Select Observatory Location
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              Real-time telemetry across IMD India stations
            </p>
          </div>

          {/* Close Button */}
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Temperature Unit Toggle (°C / °F) */}
        <div className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-50 border border-slate-200 mb-3">
          <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
            <Thermometer className="w-3.5 h-3.5 text-[#1A4FA0]" />
            <span>Temperature Unit</span>
          </span>

          <div className="flex gap-1 p-0.5 bg-slate-200/80 rounded-xl">
            <button
              onClick={() => setTempUnit('celsius')}
              className={`px-3 py-1 rounded-lg text-xs font-black transition-all ${
                tempUnit === 'celsius'
                  ? 'bg-[#1A4FA0] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              °C
            </button>
            <button
              onClick={() => setTempUnit('fahrenheit')}
              className={`px-3 py-1 rounded-lg text-xs font-black transition-all ${
                tempUnit === 'fahrenheit'
                  ? 'bg-[#1A4FA0] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              °F
            </button>
          </div>
        </div>

        {/* Search Bar Input */}
        <div className="relative mb-3.5">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search city, sector or station..."
            className="w-full h-11 pl-9 pr-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] focus:bg-white"
            autoFocus
          />
        </div>

        {/* Scrollable list of locations */}
        <div className="overflow-y-auto hide-scroll flex-1 space-y-2 pb-2">
          {/* If user typed a query, show filtered search results */}
          {query.trim() ? (
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-1 block">
                Matching Cities ({filtered.length})
              </span>
              {filtered.map((city) => (
                <div
                  key={city.stationId}
                  onClick={() => {
                    switchLocation(city);
                    onClose();
                  }}
                  className="p-3 rounded-2xl hover:bg-slate-50 border border-slate-100 flex items-center justify-between cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <MapPin className="w-4 h-4 text-[#1A4FA0]" />
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        {city.nameEn}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {city.stateEn} • AWS #{city.stationId}
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              ))}
            </div>
          ) : (
            /* Otherwise show suggested quick locations */
            <div className="space-y-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-1 block">
                Suggested Locations
              </span>

              {suggestions.map((loc) => {
                const isCurrent =
                  weatherData.location.nameEn.includes(loc.nameEn.split(',')[0]) ||
                  loc.nameEn.includes(weatherData.location.nameEn);

                return (
                  <div
                    key={loc.stationId}
                    onClick={() => handleSelect(loc)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                      isCurrent
                        ? 'bg-blue-50/70 border-blue-200 shadow-2xs'
                        : 'bg-white border-slate-200/90 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                          isCurrent
                            ? 'bg-[#1A4FA0] text-white'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        <MapPin className="w-4 h-4" />
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-slate-900">
                            {loc.nameEn}
                          </span>
                          {isCurrent && (
                            <span className="px-1.5 py-0.5 rounded-md bg-blue-200 text-[#0A2A65] text-[9px] font-black uppercase">
                              Active
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] font-medium text-slate-500">
                          {loc.tag} • {loc.stateEn}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-black text-slate-900 block">
                        {loc.temp}
                      </span>
                      {isCurrent ? (
                        <Check className="w-3.5 h-3.5 text-[#1A4FA0] ml-auto mt-0.5" />
                      ) : (
                        <span className="text-[10px] text-[#1A4FA0] font-bold">
                          Select
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
