import React, { useState, useMemo, useEffect } from 'react';
import {
  Search,
  MapPin,
  X,
  Compass,
  Check,
  Volume2,
  Share2,
  Activity,
  Radio,
  Wind,
  Droplets,
  Thermometer,
  Gauge,
  Eye,
  Sun,
  ShieldCheck,
  ChevronRight,
  ArrowLeft,
  Sparkles,
  Layers,
  Mountain,
  Waves,
  Building2,
  Wheat,
} from 'lucide-react';
import { LocationInfo, AppLanguage, PersonaType, PersonaWeatherData } from '../types';
import { translations } from '../data/translations';
import {
  curatedIndianStations,
  searchIndianLocations,
  StationDirectoryItem,
  generateDynamicLocation,
} from '../data/indianLocations';
import { fetchLiveWeatherByQuery } from '../services/liveWeatherService';

interface LocationSearchAndDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLocation: LocationInfo;
  onSelectLocation: (
    loc: LocationInfo,
    matchingPersona?: PersonaType,
    customWeatherData?: PersonaWeatherData
  ) => void;
  language: AppLanguage;
  tempUnit: 'celsius' | 'fahrenheit';
  initialStation?: StationDirectoryItem | null;
}

export const LocationSearchAndDetailsModal: React.FC<LocationSearchAndDetailsModalProps> = ({
  isOpen,
  onClose,
  currentLocation,
  onSelectLocation,
  language,
  tempUnit,
  initialStation = null,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'agri' | 'metro' | 'coastal' | 'hills'>('all');
  const [selectedStation, setSelectedStation] = useState<StationDirectoryItem | null>(initialStation);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [copiedToast, setCopiedToast] = useState(false);

  const t = translations[language];

  // Helper to convert C to F if needed
  const formatTemp = (celsius: number) => {
    if (tempUnit === 'fahrenheit') {
      return `${Math.round((celsius * 9) / 5 + 32)}°F`;
    }
    return `${Math.round(celsius)}°C`;
  };

  // When modal opens, sync initial station or select current location's station
  useEffect(() => {
    if (isOpen) {
      if (initialStation) {
        setSelectedStation(initialStation);
      } else {
        const found = curatedIndianStations.find(
          (s) => s.info.stationId === currentLocation.stationId
        );
        if (found) {
          setSelectedStation(found);
        }
      }
    } else {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsSpeaking(false);
    }
  }, [isOpen, initialStation, currentLocation.stationId]);

  // Filtered station search results
  const searchResults = useMemo(() => {
    return searchIndianLocations(searchQuery, activeCategory);
  }, [searchQuery, activeCategory]);

  if (!isOpen) return null;

  // Speak station telemetry using Web Speech API
  const handleSpeakStationReport = (station: StationDirectoryItem) => {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();

    if (isSpeaking) {
      setIsSpeaking(false);
      return;
    }

    const info = station.info;
    const w = station.weatherData;

    let text = '';
    if (language === 'hi') {
      text = `भारत मौसम विज्ञान विभाग, ${info.nameHi} वेधशाला बुलेटिन। वर्तमान तापमान ${w.currentTemp} डिग्री सेल्सियस, महसूस होता है ${w.feelsLike} डिग्री। सापेक्ष आर्द्रता ${w.humidity} प्रतिशत, हवा की गति ${w.windSpeedKmh} किलोमीटर प्रति घंटा। वायु गुणवत्ता सूचकांक ${w.aqi.value}, श्रेणी ${w.aqi.categoryHi}। परामर्श: ${w.aiAdvisory.headlineHi}`;
    } else {
      text = `India Meteorological Department, ${info.nameEn} Observatory Bulletin. Station ID: ${info.stationId}, Elevation: ${info.elevation}. Current temperature is ${w.currentTemp} degrees Celsius, feels like ${w.feelsLike} degrees. Relative humidity is ${w.humidity} percent with winds at ${w.windSpeedKmh} kilometers per hour from ${w.windDir}. Air quality index is ${w.aqi.value}, rated ${w.aqi.categoryEn}. Regional advisory: ${w.aiAdvisory.headlineEn}.`;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.rate = 0.95;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  // Copy telemetry report to clipboard
  const handleCopyTelemetry = (station: StationDirectoryItem) => {
    const info = station.info;
    const w = station.weatherData;

    const report = `[IMD MoES Official Meteorological Telemetry]
Station: ${info.nameEn} (${info.nameHi}) [${info.stationId}]
Type: ${info.stationType || 'IMD AWS'}
Coordinates: ${info.coordinates} | Elevation: ${info.elevation}
State: ${info.stateEn} | District: ${info.districtEn || 'N/A'} | PIN: ${info.pinCode || 'N/A'}
Temperature: ${w.currentTemp}°C (Feels like: ${w.feelsLike}°C)
Humidity: ${w.humidity}% | Dew Point: ${w.dewPoint}°C
Atmospheric Pressure: ${w.pressureHpa} hPa | Wind: ${w.windSpeedKmh} km/h ${w.windDir}
AQI: ${w.aqi.value} (${w.aqi.categoryEn})
Agro-Climatic Zone: ${info.agroZone || info.coastalZone || 'Alluvial Plains'}
Status: Active INSAT-3DR Telemetry Synchronized
Source: Ministry of Earth Sciences, Govt. of India`;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(report);
      setCopiedToast(true);
      setTimeout(() => setCopiedToast(false), 2200);
    }
  };

  // Select location and apply to whole app
  const handleApplyLocation = async (station: StationDirectoryItem) => {
    try {
      const live = await fetchLiveWeatherByQuery(station.info.nameEn, station.persona, language);
      onSelectLocation(live.location, station.persona, live);
    } catch {
      onSelectLocation(station.info, station.persona, station.weatherData);
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    onClose();
  };

  const quickPopular = [
    { name: 'Ghaziabad', query: 'Ghaziabad' },
    { name: 'Noida', query: 'Noida' },
    { name: 'New Delhi', query: 'Delhi' },
    { name: 'Jaipur', query: 'Jaipur' },
    { name: 'Bengaluru', query: 'Bengaluru' },
    { name: 'Mumbai', query: 'Mumbai' },
    { name: 'Lucknow', query: 'Lucknow' },
    { name: 'Shimla', query: 'Shimla' },
    { name: 'Kochi', query: 'Kochi' },
    { name: 'Srinagar', query: 'Srinagar' },
    { name: 'Leh', query: 'Leh' },
    { name: 'Cherrapunji', query: 'Cherrapunji' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-3 animate-fade-in">
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Authentic Indian Government Tricolor Top Accent */}
        <div className="h-1.5 w-full flex">
          <div className="flex-1 bg-[#FF9933]" />
          <div className="flex-1 bg-white relative flex items-center justify-center border-y border-slate-200">
            <div className="w-1.5 h-1.5 rounded-full border border-blue-900" />
          </div>
          <div className="flex-1 bg-[#138808]" />
        </div>

        {/* Modal Header */}
        <div className="p-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            {selectedStation ? (
              <button
                onClick={() => setSelectedStation(null)}
                className="p-1 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 transition-colors"
                title={t.backToSearch}
              >
                <ArrowLeft className="w-4 h-4 text-slate-700" />
              </button>
            ) : (
              <div className="w-8 h-8 rounded-xl bg-emerald-700 text-white flex items-center justify-center shadow-xs">
                <Compass className="w-4 h-4" />
              </div>
            )}

            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">
                  {t.govtIndia}
                </span>
                <span className="text-[9px] px-1 py-0.2 rounded bg-emerald-100 text-emerald-900 font-bold">
                  IMD-AWS-GRID
                </span>
              </div>
              <h3 className="text-xs font-black text-slate-900 leading-tight">
                {selectedStation ? t.stationDetailsTitle : t.searchLocationTitle}
              </h3>
            </div>
          </div>

          <button
            onClick={() => {
              if ('speechSynthesis' in window) window.speechSynthesis.cancel();
              onClose();
            }}
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* MAIN BODY: Either Search View OR In-Depth Station Details View */}
        {!selectedStation ? (
          /* ========================================================
             1. SEARCH & BROWSE STATIONS VIEW
             ======================================================== */
          <div className="flex-1 overflow-y-auto p-3.5 space-y-3">
            {/* Search Input Bar */}
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                id="station-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-full pl-9.5 pr-8 py-2.5 bg-slate-50 border-2 border-slate-200 rounded-2xl text-xs font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Category Filter Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-[11px]">
              <button
                onClick={() => setActiveCategory('all')}
                className={`px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all ${
                  activeCategory === 'all'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {t.filterAll}
              </button>
              <button
                onClick={() => setActiveCategory('agri')}
                className={`px-2.5 py-1 rounded-xl font-bold whitespace-nowrap flex items-center gap-1 transition-all ${
                  activeCategory === 'agri'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
                }`}
              >
                <Wheat className="w-3 h-3" />
                <span>{t.filterAgri}</span>
              </button>
              <button
                onClick={() => setActiveCategory('metro')}
                className={`px-2.5 py-1 rounded-xl font-bold whitespace-nowrap flex items-center gap-1 transition-all ${
                  activeCategory === 'metro'
                    ? 'bg-blue-700 text-white shadow-xs'
                    : 'bg-blue-50 text-blue-800 hover:bg-blue-100 border border-blue-200'
                }`}
              >
                <Building2 className="w-3 h-3" />
                <span>{t.filterMetro}</span>
              </button>
              <button
                onClick={() => setActiveCategory('coastal')}
                className={`px-2.5 py-1 rounded-xl font-bold whitespace-nowrap flex items-center gap-1 transition-all ${
                  activeCategory === 'coastal'
                    ? 'bg-cyan-700 text-white shadow-xs'
                    : 'bg-cyan-50 text-cyan-800 hover:bg-cyan-100 border border-cyan-200'
                }`}
              >
                <Waves className="w-3 h-3" />
                <span>{t.filterCoastal}</span>
              </button>
              <button
                onClick={() => setActiveCategory('hills')}
                className={`px-2.5 py-1 rounded-xl font-bold whitespace-nowrap flex items-center gap-1 transition-all ${
                  activeCategory === 'hills'
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'bg-teal-50 text-teal-800 hover:bg-teal-100 border border-teal-200'
                }`}
              >
                <Mountain className="w-3 h-3" />
                <span>{t.filterHills}</span>
              </button>
            </div>

            {/* Popular Quick Search Chips */}
            <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-200/80">
              <div className="text-[10px] font-bold text-slate-500 mb-1.5 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-orange-600" />
                <span>{t.quickSearches}</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {quickPopular.map((chip) => (
                  <button
                    key={chip.name}
                    onClick={() => setSearchQuery(chip.query)}
                    className="px-2 py-0.8 rounded-lg bg-white border border-slate-200 text-slate-700 text-[10px] font-semibold hover:border-emerald-500 hover:text-emerald-800 transition-colors shadow-2xs"
                  >
                    {chip.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Search Results Count & Notice */}
            <div className="flex items-center justify-between text-[11px] text-slate-500 px-1">
              <span>
                {language === 'hi'
                  ? `${searchResults.length} वेधशालाएं उपलब्ध`
                  : `${searchResults.length} stations found`}
              </span>
              <span className="text-[10px] font-mono text-emerald-700 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                {t.telemetryLive}
              </span>
            </div>

            {/* Station List Cards */}
            <div className="space-y-2">
              {searchResults.map((item) => {
                const isCurrent = item.info.stationId === currentLocation.stationId;

                return (
                  <div
                    key={item.info.stationId}
                    className={`p-3 rounded-2xl border transition-all ${
                      isCurrent
                        ? 'bg-emerald-50/80 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'bg-white hover:bg-slate-50/80 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        {/* Station Name & State */}
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-extrabold text-xs text-slate-900 leading-tight">
                            {language === 'hi' ? item.info.nameHi : item.info.nameEn}
                          </h4>
                          <span className="text-[10px] font-semibold text-slate-500">
                            {language === 'hi' ? item.info.stateHi : item.info.stateEn}
                          </span>
                          {isCurrent && (
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-700 text-white flex items-center gap-0.5">
                              <Check className="w-2.5 h-2.5" />
                              {t.activeStationBadge}
                            </span>
                          )}
                        </div>

                        {/* Station ID, Type, & Elevation */}
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5 flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-slate-700 bg-slate-100 px-1 py-0.2 rounded">
                            {item.info.stationId}
                          </span>
                          <span>•</span>
                          <span>{item.info.elevation}</span>
                          {item.info.pinCode && (
                            <>
                              <span>•</span>
                              <span>PIN: {item.info.pinCode}</span>
                            </>
                          )}
                        </div>

                        {/* Weather snapshot strip */}
                        <div className="flex items-center gap-3 mt-2 text-[11px] font-medium text-slate-700">
                          <div className="flex items-center gap-1 font-extrabold text-slate-900">
                            <Thermometer className="w-3.5 h-3.5 text-orange-600" />
                            <span>{formatTemp(item.weatherData.currentTemp)}</span>
                          </div>
                          <div className="flex items-center gap-1 text-slate-600">
                            <Droplets className="w-3.5 h-3.5 text-blue-500" />
                            <span>{item.weatherData.humidity}%</span>
                          </div>
                          <div className="flex items-center gap-1 text-slate-600">
                            <Wind className="w-3.5 h-3.5 text-teal-600" />
                            <span>{item.weatherData.windSpeedKmh} km/h</span>
                          </div>
                          <div className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 font-semibold text-slate-700">
                            AQI {item.weatherData.aqi.value}
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex flex-col gap-1.5 shrink-0">
                        <button
                          onClick={() => setSelectedStation(item)}
                          className="px-2.5 py-1.5 rounded-xl bg-slate-900 text-white font-bold text-[10px] hover:bg-slate-800 transition-colors flex items-center gap-1 shadow-xs"
                        >
                          <span>{language === 'hi' ? 'विवरण' : 'Details'}</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleApplyLocation(item)}
                          className="px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-900 hover:bg-emerald-200 border border-emerald-300 font-bold text-[10px] transition-colors"
                        >
                          {isCurrent
                            ? language === 'hi'
                              ? 'सक्रिय है'
                              : 'Active'
                            : language === 'hi'
                            ? 'सक्रिय करें'
                            : 'Set Active'}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* ========================================================
             2. IN-DEPTH STATION DETAILS & TELEMETRY INSPECTION VIEW
             ======================================================== */
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
            {/* Top Identity Card */}
            <div className="p-3.5 rounded-2xl bg-linear-to-br from-emerald-50 via-white to-orange-50 border border-slate-200 shadow-xs space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-800 text-white">
                      {selectedStation.badgeEn}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500 font-bold">
                      {selectedStation.info.stationId}
                    </span>
                  </div>
                  <h3 className="text-base font-black text-slate-900 mt-1">
                    {language === 'hi'
                      ? selectedStation.info.nameHi
                      : selectedStation.info.nameEn}
                  </h3>
                  <div className="text-xs text-slate-600 font-medium">
                    {selectedStation.info.districtEn && `${selectedStation.info.districtEn}, `}
                    {language === 'hi'
                      ? selectedStation.info.stateHi
                      : selectedStation.info.stateEn}
                    {selectedStation.info.pinCode && ` • PIN ${selectedStation.info.pinCode}`}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-2xl font-black text-slate-900 font-serif">
                    {formatTemp(selectedStation.weatherData.currentTemp)}
                  </div>
                  <div className="text-[10px] text-slate-500 font-semibold">
                    {t.feelsLikeLabel} {formatTemp(selectedStation.weatherData.feelsLike)}
                  </div>
                </div>
              </div>

              {/* Station Type & Telemetry status banner */}
              <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-[10px]">
                <span className="font-bold text-slate-700">
                  {selectedStation.info.stationType || 'IMD Synoptic Automatic Weather Station'}
                </span>
                <span className="flex items-center gap-1 text-emerald-800 font-bold font-mono">
                  <Radio className="w-3 h-3 text-emerald-600 animate-pulse" />
                  {selectedStation.info.telemetryStatus || 'INSAT-3DR Telemetry Active'}
                </span>
              </div>
            </div>

            {/* Geographical & Climatological Coordinates */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center gap-1.5 font-extrabold text-slate-900 text-[11px]">
                <Compass className="w-3.5 h-3.5 text-blue-600" />
                <span>{t.geographicClimatic}</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div className="p-2 rounded-xl bg-white border border-slate-200">
                  <span className="text-slate-400 block font-semibold">{t.stationCoordinates}</span>
                  <span className="font-mono font-bold text-slate-800 mt-0.5 block">
                    {selectedStation.info.coordinates}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-white border border-slate-200">
                  <span className="text-slate-400 block font-semibold">{t.stationElevation}</span>
                  <span className="font-mono font-bold text-slate-800 mt-0.5 block">
                    {selectedStation.info.elevation}
                  </span>
                </div>
              </div>

              {selectedStation.info.agroZone && (
                <div className="p-2 rounded-xl bg-white border border-slate-200 text-[10px]">
                  <span className="text-slate-400 block font-semibold">{t.agroZone}</span>
                  <span className="font-bold text-slate-800 mt-0.5 block">
                    {selectedStation.info.agroZone}
                  </span>
                </div>
              )}

              {selectedStation.info.climateZone && (
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div className="p-2 rounded-xl bg-white border border-slate-200">
                    <span className="text-slate-400 block font-semibold">{t.climateZoneLabel}</span>
                    <span className="font-bold text-slate-800 mt-0.5 block">
                      {selectedStation.info.climateZone}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-slate-200">
                    <span className="text-slate-400 block font-semibold">{t.terrainLabel}</span>
                    <span className="font-bold text-slate-800 mt-0.5 block truncate">
                      {selectedStation.info.terrain || 'Alluvial Basin'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Live Meteorological Telemetry Grid */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-extrabold text-slate-900 text-[11px]">
                  <Activity className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{t.liveTelemetryGrid}</span>
                </div>
                <span className="text-[9px] font-mono text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded font-bold">
                  24-Hr Live Sync
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                {/* Humidity */}
                <div className="p-2 rounded-xl bg-white border border-slate-200">
                  <span className="text-slate-400 block font-semibold">{t.humidityLabel}</span>
                  <span className="font-bold text-sm text-blue-600 font-mono mt-0.5 block">
                    {selectedStation.weatherData.humidity}%
                  </span>
                  <span className="text-[9px] text-slate-500 block">
                    {t.dewPointLabel} {selectedStation.weatherData.dewPoint}°C
                  </span>
                </div>

                {/* Pressure */}
                <div className="p-2 rounded-xl bg-white border border-slate-200">
                  <span className="text-slate-400 block font-semibold">{t.pressureLabel}</span>
                  <span className="font-bold text-sm text-slate-800 font-mono mt-0.5 block">
                    {selectedStation.weatherData.pressureHpa}
                  </span>
                  <span className="text-[9px] text-slate-500 block">hPa (Normal)</span>
                </div>

                {/* Wind */}
                <div className="p-2 rounded-xl bg-white border border-slate-200">
                  <span className="text-slate-400 block font-semibold">{t.windLabel}</span>
                  <span className="font-bold text-sm text-teal-700 font-mono mt-0.5 block">
                    {selectedStation.weatherData.windSpeedKmh}
                  </span>
                  <span className="text-[9px] text-slate-500 block truncate">
                    {selectedStation.weatherData.windDir.split(' ')[0]}
                  </span>
                </div>
              </div>

              {/* Air Quality Bar */}
              <div className="p-2 rounded-xl bg-white border border-slate-200 flex items-center justify-between text-[10px]">
                <div>
                  <span className="font-bold text-slate-800 block">
                    National Air Quality Index (AQI): {selectedStation.weatherData.aqi.value}
                  </span>
                  <span className="text-slate-500 text-[9px]">
                    PM2.5: {selectedStation.weatherData.aqi.pm25} µg/m³ • PM10:{' '}
                    {selectedStation.weatherData.aqi.pm10} µg/m³
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded-full font-bold bg-amber-100 text-amber-900 border border-amber-300">
                  {language === 'hi'
                    ? selectedStation.weatherData.aqi.categoryHi
                    : selectedStation.weatherData.aqi.categoryEn}
                </span>
              </div>
            </div>

            {/* Regional Agromet & Safety Bulletin */}
            <div className="p-3.5 rounded-2xl bg-orange-50/70 border border-orange-200 space-y-1.5">
              <div className="flex items-center gap-1.5 font-bold text-orange-950 text-[11px]">
                <ShieldCheck className="w-3.5 h-3.5 text-orange-600" />
                <span>{t.agroAdvisoryHeading}</span>
              </div>
              <h5 className="font-black text-slate-900 text-xs leading-snug">
                {language === 'hi'
                  ? selectedStation.weatherData.aiAdvisory.headlineHi
                  : selectedStation.weatherData.aiAdvisory.headlineEn}
              </h5>
              <p className="text-[10px] text-slate-600 leading-relaxed">
                {language === 'hi'
                  ? selectedStation.weatherData.aiAdvisory.contentHi
                  : selectedStation.weatherData.aiAdvisory.contentEn}
              </p>
            </div>

            {/* Audio Voice Readout & Share Buttons */}
            <div className="flex items-center gap-2">
              <button
                id="station-listen-audio-btn"
                onClick={() => handleSpeakStationReport(selectedStation)}
                className={`flex-1 py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-xs ${
                  isSpeaking
                    ? 'bg-amber-600 text-white border-amber-700 animate-pulse'
                    : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-200'
                }`}
              >
                <Volume2 className="w-4 h-4 text-amber-600" />
                <span>
                  {isSpeaking
                    ? language === 'hi'
                      ? 'वाणी प्रसारण जारी...'
                      : 'Broadcasting Audio...'
                    : t.listenBulletinBtn}
                </span>
              </button>

              <button
                id="station-share-telemetry-btn"
                onClick={() => handleCopyTelemetry(selectedStation)}
                className="py-2 px-3 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs"
                title={t.shareTelemetryBtn}
              >
                <Share2 className="w-4 h-4 text-blue-600" />
                <span>{t.shareTelemetryBtn}</span>
              </button>
            </div>

            {copiedToast && (
              <div className="text-[10px] text-emerald-800 bg-emerald-50 border border-emerald-300 p-2 rounded-xl font-bold flex items-center gap-1.5 animate-fade-in">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>
                  {language === 'hi'
                    ? 'वेधशाला मौसम डेटा क्लिपबोर्ड पर कॉपी किया गया।'
                    : 'IMD Station Meteorological Telemetry copied to clipboard.'}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Modal Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-2">
          {selectedStation ? (
            <>
              <button
                onClick={() => setSelectedStation(null)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-slate-700 text-xs font-bold hover:bg-slate-100"
              >
                {t.backToSearch}
              </button>

              <button
                id="station-set-active-btn"
                onClick={() => handleApplyLocation(selectedStation)}
                className="flex-1 py-1.5 px-4 rounded-xl bg-emerald-700 text-white font-black text-xs hover:bg-emerald-800 transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Check className="w-3.5 h-3.5" />
                <span>{t.setAsActiveBtn}</span>
              </button>
            </>
          ) : (
            <>
              <div className="text-[10px] text-slate-500 font-semibold">
                {language === 'hi' ? 'आईएमडी राष्ट्रीय वेधशाला ग्रिड' : 'MoES IMD National Telemetry Grid'}
              </div>
              <button
                onClick={onClose}
                className="px-4 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-colors shadow-xs"
              >
                {t.close}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
