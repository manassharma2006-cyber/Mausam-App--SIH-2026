import React, { useState, useEffect, useRef } from 'react';
import { Search, MapPin, Crosshair, X, Loader2, RefreshCw, Radio, Check } from 'lucide-react';
import type { AppLanguage, PersonaType, PersonaWeatherData } from '../types';
import { curatedIndianStations } from '../data/indianLocations';
import { fetchLiveWeatherByQuery, fetchLiveWeatherByCoords } from '../services/liveWeatherService';

interface MainLocationSearchBarProps {
  language: AppLanguage;
  activePersona: PersonaType;
  currentWeatherData: PersonaWeatherData;
  onWeatherUpdate: (weather: PersonaWeatherData) => void;
  onShowToast: (title: string, msg: string) => void;
}

export const MainLocationSearchBar: React.FC<MainLocationSearchBarProps> = ({
  language,
  activePersona,
  currentWeatherData,
  onWeatherUpdate,
  onShowToast,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isGpsLoading, setIsGpsLoading] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [recentLocations, setRecentLocations] = useState<string[]>([
    'New Delhi',
    'Jaipur',
    'Mumbai',
    'Bengaluru',
    'Shimla',
  ]);

  const searchContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(event.target as Node)
      ) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter matching stations from curated list
  const filteredSuggestions = searchTerm.trim()
    ? curatedIndianStations
        .filter((st) => {
          const q = searchTerm.toLowerCase();
          return (
            st.info.nameEn.toLowerCase().includes(q) ||
            st.info.nameHi.includes(q) ||
            st.info.stateEn.toLowerCase().includes(q) ||
            st.info.stateHi.includes(q) ||
            (st.info.pinCode && st.info.pinCode.includes(q)) ||
            (st.tags && st.tags.some((t) => t.toLowerCase().includes(q)))
          );
        })
        .slice(0, 5)
    : [];

  // Handle Search Submission
  const handleExecuteSearch = async (queryToSearch?: string) => {
    const targetQuery = (queryToSearch ?? searchTerm).trim();
    if (!targetQuery) return;

    setIsLoading(true);
    setIsDropdownOpen(false);

    try {
      const liveData = await fetchLiveWeatherByQuery(targetQuery, activePersona, language);
      onWeatherUpdate(liveData);

      // Save to recent searches
      setRecentLocations((prev) => {
        const filtered = prev.filter((item) => item.toLowerCase() !== targetQuery.toLowerCase());
        return [targetQuery, ...filtered].slice(0, 5);
      });

      setSearchTerm('');
      inputRef.current?.blur();

      const providerLabel = liveData.providerName || 'Live Telemetry';
      onShowToast(
        language === 'hi' ? 'सटीक मौसम लोड हुआ' : 'Accurate Weather Synced',
        language === 'hi'
          ? `${liveData.location.nameHi || targetQuery} का वास्तविक मौसम (${providerLabel}) से प्राप्त हुआ।`
          : `Live meteorological report for ${liveData.location.nameEn || targetQuery} synced from ${providerLabel}.`
      );
    } catch (err: any) {
      console.error('Search error:', err);
      onShowToast(
        language === 'hi' ? 'खोज विफल' : 'Search Failed',
        language === 'hi'
          ? `स्थान '${targetQuery}' का मौसम प्राप्त नहीं हो सका। कृपया वर्तनी जांचें।`
          : `Could not retrieve live weather for '${targetQuery}'. Please check spelling.`
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Handle GPS Current Location
  const handleGpsCurrentLocation = () => {
    if (!navigator.geolocation) {
      onShowToast(
        language === 'hi' ? 'जीपीएस अनुपलब्ध' : 'GPS Unavailable',
        language === 'hi'
          ? 'आपके ब्राउज़र में स्थान सेवा समर्थित नहीं है।'
          : 'Geolocation is not supported by your browser.'
      );
      return;
    }

    setIsGpsLoading(true);
    setIsDropdownOpen(false);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;

          const liveData = await fetchLiveWeatherByCoords(
            lat,
            lng,
            'My Current Location',
            'Live GPS',
            activePersona,
            language
          );

          onWeatherUpdate(liveData);
          onShowToast(
            language === 'hi' ? 'जीपीएस मौसम लोड हुआ' : 'GPS Location Synced',
            language === 'hi'
              ? `वर्तमान अक्षांश ${lat.toFixed(2)}°, देशांतर ${lng.toFixed(2)}° का सटीक मौसम प्राप्त हुआ।`
              : `Exact weather report synced for coordinates ${lat.toFixed(2)}°, ${lng.toFixed(2)}°.`
          );
        } catch (err: any) {
          console.error('GPS Weather fetch error:', err);
          onShowToast(
            language === 'hi' ? 'त्रुटि' : 'Error',
            language === 'hi'
              ? 'वर्तमान स्थान का मौसम लोड करने में समस्या हुई।'
              : 'Failed to fetch weather for your exact GPS coordinates.'
          );
        } finally {
          setIsGpsLoading(false);
        }
      },
      (error) => {
        setIsGpsLoading(false);
        console.warn('Geolocation error:', error);
        onShowToast(
          language === 'hi' ? 'स्थान अनुमति चाहिए' : 'Location Permission Needed',
          language === 'hi'
            ? 'सटीक स्थानीय मौसम के लिए कृपया ब्राउज़र में स्थान अनुमति दें।'
            : 'Please grant location permission to fetch exact local weather.'
        );
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  // Quick refresh of current weather
  const handleRefreshCurrentWeather = async () => {
    setIsLoading(true);
    try {
      const q = currentWeatherData.location.nameEn || 'Delhi';
      const refreshed = await fetchLiveWeatherByQuery(q, activePersona, language);
      onWeatherUpdate(refreshed);
      onShowToast(
        language === 'hi' ? 'मौसम ताज़ा किया गया' : 'Weather Refreshed',
        language === 'hi'
          ? `${currentWeatherData.location.nameHi} का ताजा मौसम अपडेट हो गया है।`
          : `Refreshed real-time weather readings for ${currentWeatherData.location.nameEn}.`
      );
    } catch (err) {
      console.error('Refresh error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const isLiveActive = currentWeatherData.isLive ?? true;
  const currentProvider = currentWeatherData.providerName || 'Live High-Precision IMD/WMO Grid';

  return (
    <div ref={searchContainerRef} className="mx-3 mt-2.5 relative z-30">
      {/* Search Input Bar Container */}
      <div className="relative flex items-center bg-white rounded-xl shadow-xs border border-slate-200/80 focus-within:border-emerald-600 focus-within:ring-2 focus-within:ring-emerald-500/20 transition-all">
        {/* Search Icon / Indicator */}
        <div className="pl-3 pr-1 text-slate-600 flex items-center shrink-0">
          {isLoading ? (
            <Loader2 className="w-4 h-4 text-emerald-600 animate-spin" />
          ) : (
            <Search className="w-4 h-4 text-emerald-600" />
          )}
        </div>

        {/* Input Field */}
        <input
          ref={inputRef}
          id="main-location-search-input"
          type="text"
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            if (!isDropdownOpen) setIsDropdownOpen(true);
          }}
          onFocus={() => setIsDropdownOpen(true)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              handleExecuteSearch();
            } else if (e.key === 'Escape') {
              setIsDropdownOpen(false);
            }
          }}
          placeholder={
            language === 'hi'
              ? 'स्थान, शहर या पिन कोड दर्ज करें (उदा. Delhi, Jaipur)...'
              : 'Enter city, district or PIN (e.g. Delhi, Jaipur, 110001)...'
          }
          className="w-full py-2.5 px-2 text-xs text-slate-800 placeholder:text-slate-600 bg-transparent outline-none font-medium"
          disabled={isLoading || isGpsLoading}
          autoComplete="off"
        />

        {/* Clear Button */}
        {searchTerm && (
          <button
            type="button"
            onClick={() => {
              setSearchTerm('');
              inputRef.current?.focus();
            }}
            className="p-1.5 text-slate-600 hover:text-slate-600 rounded-full transition-colors shrink-0"
            title={language === 'hi' ? 'साफ करें' : 'Clear'}
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}

        {/* GPS Current Location Button */}
        <button
          type="button"
          id="gps-location-btn"
          onClick={handleGpsCurrentLocation}
          disabled={isGpsLoading || isLoading}
          className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors shrink-0 flex items-center justify-center border-l border-slate-100"
          title={language === 'hi' ? 'मेरा वर्तमान स्थान (GPS)' : 'Use My Current Location (GPS)'}
        >
          {isGpsLoading ? (
            <Loader2 className="w-4 h-4 text-emerald-600 animate-spin" />
          ) : (
            <Crosshair className="w-4 h-4 text-emerald-600" />
          )}
        </button>

        {/* Search Submit Button */}
        <button
          type="button"
          id="main-location-search-submit"
          onClick={() => handleExecuteSearch()}
          disabled={isLoading || isGpsLoading || !searchTerm.trim()}
          className="mr-1 my-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white text-[11px] font-bold rounded-lg shadow-xs transition-all shrink-0 flex items-center gap-1 cursor-pointer disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <Loader2 className="w-3 h-3 animate-spin" />
          ) : (
            <span>{language === 'hi' ? 'खोजें' : 'Search'}</span>
          )}
        </button>
      </div>

      {/* Auto-Suggestions / Recent Search Dropdown */}
      {isDropdownOpen && (
        <div className="absolute top-full left-0 right-0 mt-1.5 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden z-40 animate-in fade-in zoom-in-95 duration-100">
          {/* Query Match Suggestions */}
          {searchTerm.trim() ? (
            <div className="p-1">
              <div className="px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-600 flex items-center justify-between">
                <span>{language === 'hi' ? 'मिलते-जुलते स्थान' : 'Matching Locations'}</span>
                <span className="text-emerald-700">{language === 'hi' ? 'सटीक खोज' : 'Exact Search'}</span>
              </div>

              {/* Direct query search option */}
              <button
                type="button"
                onClick={() => handleExecuteSearch(searchTerm)}
                className="w-full px-2.5 py-2 text-left text-xs font-semibold text-emerald-800 hover:bg-emerald-50/80 rounded-lg flex items-center justify-between transition-colors group"
              >
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 shrink-0">
                    <Search className="w-3 h-3" />
                  </div>
                  <span>
                    {language === 'hi' ? `"${searchTerm}" का सटीक मौसम खोजें` : `Search live weather for "${searchTerm}"`}
                  </span>
                </div>
                <span className="text-[10px] text-emerald-600 font-normal group-hover:underline">
                  {language === 'hi' ? 'लाइव API कॉल' : 'Live API Query'}
                </span>
              </button>

              {/* Matching IMD Stations */}
              {filteredSuggestions.map((st) => (
                <button
                  key={st.info.stationId}
                  type="button"
                  onClick={() => handleExecuteSearch(st.info.nameEn)}
                  className="w-full px-2.5 py-1.5 text-left text-xs text-slate-700 hover:bg-slate-50 rounded-lg flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <MapPin className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                    <div className="truncate">
                      <span className="font-bold text-slate-800">
                        {language === 'hi' ? st.info.nameHi : st.info.nameEn}
                      </span>
                      <span className="text-[11px] text-slate-500 ml-1">
                        ({language === 'hi' ? st.info.stateHi : st.info.stateEn})
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 shrink-0 font-medium">
                    {st.info.pinCode || st.info.stationId}
                  </span>
                </button>
              ))}
            </div>
          ) : (
            /* Default / Popular Searches */
            <div className="p-2">
              <div className="flex items-center justify-between px-1.5 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-600">
                <span>{language === 'hi' ? 'लोकप्रिय शहर' : 'Popular Indian Cities'}</span>
                <span className="text-slate-600">{language === 'hi' ? 'त्वरित चयन' : 'Quick Pick'}</span>
              </div>

              <div className="flex flex-wrap gap-1.5 mt-1">
                {recentLocations.map((loc) => (
                  <button
                    key={loc}
                    type="button"
                    onClick={() => handleExecuteSearch(loc)}
                    className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-300 text-slate-700 rounded-lg border border-slate-200/80 transition-colors flex items-center gap-1"
                  >
                    <MapPin className="w-2.5 h-2.5 text-slate-600" />
                    <span>{loc}</span>
                  </button>
                ))}
              </div>

              {/* GPS button helper inside dropdown */}
              <div className="mt-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleGpsCurrentLocation}
                  disabled={isGpsLoading}
                  className="w-full py-1.5 px-2 text-xs font-semibold text-emerald-800 bg-emerald-50/70 hover:bg-emerald-100/70 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Crosshair className="w-3.5 h-3.5 text-emerald-600" />
                  <span>
                    {language === 'hi' ? 'वर्तमान स्थान का लाइव मौसम लें (GPS)' : 'Use GPS for Current Location'}
                  </span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Live Weather Source & Precision Indicator Strip */}
      <div className="mt-1.5 px-1 flex items-center justify-between text-[10px] text-slate-500">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="relative flex h-2 w-2 shrink-0">
            <span
              className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                isLiveActive ? 'bg-emerald-400' : 'bg-amber-400'
              }`}
            />
            <span
              className={`relative inline-flex rounded-full h-2 w-2 ${
                isLiveActive ? 'bg-emerald-600' : 'bg-amber-500'
              }`}
            />
          </span>

          <span className="font-semibold text-slate-700 truncate">
            {currentProvider}
          </span>

          {currentWeatherData.location?.coordinates && (
            <span className="hidden sm:inline text-slate-600 truncate">
              • {currentWeatherData.location.coordinates}
            </span>
          )}
        </div>

        <button
          type="button"
          onClick={handleRefreshCurrentWeather}
          disabled={isLoading}
          className="flex items-center gap-1 text-emerald-700 hover:text-emerald-800 font-bold shrink-0 hover:underline cursor-pointer"
          title={language === 'hi' ? 'लाइव मौसम अपडेट करें' : 'Refresh live weather'}
        >
          <RefreshCw className={`w-2.5 h-2.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>{language === 'hi' ? 'ताज़ा करें' : 'Refresh'}</span>
        </button>
      </div>
    </div>
  );
};
