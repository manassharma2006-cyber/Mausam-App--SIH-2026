import React from 'react';

export default function MausamBrandMark({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const dims = {
    sm: { box: 'w-10 h-10', icon: 'w-6 h-6', radius: 'rounded-xl', text: 'text-xs' },
    md: { box: 'w-16 h-16', icon: 'w-10 h-10', radius: 'rounded-2xl', text: 'text-sm' },
    lg: { box: 'w-24 h-24', icon: 'w-16 h-16', radius: 'rounded-3xl', text: 'text-base' },
  }[size];

  return (
    <div className="relative flex items-center justify-center">
      {/* Subtle outer atmospheric aura glow */}
      <div
        className={`absolute -inset-2 ${dims.radius} opacity-60 blur-xl pointer-events-none`}
        style={{
          background: 'radial-gradient(circle, rgba(56, 189, 248, 0.45) 0%, rgba(251, 191, 36, 0.3) 70%, transparent 100%)',
        }}
      />

      {/* Main Brand Mark Container */}
      <div
        className={`${dims.box} ${dims.radius} relative p-0.5 flex items-center justify-center shadow-lg border border-white/40 overflow-hidden`}
        style={{
          background: 'linear-gradient(145deg, #FFFFFF 0%, #E0F2FE 40%, #BAE6FD 100%)',
        }}
      >
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={dims.icon}
        >
          <defs>
            <linearGradient id="sunGrad" x1="16" y1="12" x2="36" y2="32" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FDE047" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>
            <linearGradient id="cloudFront" x1="18" y1="28" x2="48" y2="52" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#E0F2FE" />
            </linearGradient>
            <linearGradient id="cloudBack" x1="28" y1="20" x2="52" y2="44" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#7DD3FC" />
              <stop offset="100%" stopColor="#0284C7" />
            </linearGradient>
            <linearGradient id="layerArc" x1="12" y1="48" x2="52" y2="48" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.8" />
              <stop offset="50%" stopColor="#0284C7" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#0369A1" />
            </linearGradient>
            <filter id="softShadow" x="-10%" y="-10%" width="120%" height="130%">
              <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#0A2A65" floodOpacity="0.18" />
            </filter>
          </defs>

          {/* Golden Sun Orb */}
          <circle cx="26" cy="24" r="13" fill="url(#sunGrad)" filter="url(#softShadow)" />

          {/* Atmosphere ring layers */}
          <circle cx="26" cy="24" r="17" stroke="#FEF08A" strokeWidth="1.5" strokeOpacity="0.6" strokeDasharray="3 3" />

          {/* Back atmospheric cloud layer */}
          <path
            d="M32 30a10 10 0 0 1 18 3 7 7 0 0 1-2 13.7H30a9 9 0 0 1 2-16.7z"
            fill="url(#cloudBack)"
            opacity="0.85"
          />

          {/* Crisp Front Weather Cloud */}
          <path
            d="M20 48h26a8 8 0 0 0 1.2-15.9 11 11 0 0 0-21-3.2A8 8 0 0 0 20 48z"
            fill="url(#cloudFront)"
            filter="url(#softShadow)"
          />

          {/* Dynamic weather layer curves */}
          <path
            d="M16 52c6 1.8 14 1.8 20 0s10-1 12 0"
            stroke="url(#layerArc)"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <circle cx="49" cy="18" r="1.8" fill="#38BDF8" />
          <circle cx="15" cy="34" r="1.4" fill="#FBBF24" />
        </svg>
      </div>
    </div>
  );
}
