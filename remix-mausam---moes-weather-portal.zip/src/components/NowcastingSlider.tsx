import React, { useState } from 'react';
import {
  Cloud,
  CloudSun,
  CloudRain,
  CloudDrizzle,
  CloudLightning,
  Sun,
  Wind,
  Droplets,
  Clock,
  Waves,
} from 'lucide-react';
import { HourlyForecast, AppLanguage, PersonaType } from '../types';
import { translations } from '../data/translations';

interface NowcastingSliderProps {
  nowcasting: HourlyForecast[];
  language: AppLanguage;
  activePersona: PersonaType;
}

export const NowcastingSlider: React.FC<NowcastingSliderProps> = ({
  nowcasting,
  language,
  activePersona,
}) => {
  const [selectedHourIndex, setSelectedHourIndex] = useState(0);
  const t = translations[language];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'CloudSun':
        return CloudSun;
      case 'Cloud':
        return Cloud;
      case 'CloudRain':
        return CloudRain;
      case 'CloudDrizzle':
        return CloudDrizzle;
      case 'CloudLightning':
        return CloudLightning;
      case 'Wind':
        return Wind;
      case 'Waves':
        return Waves;
      case 'Sun':
      default:
        return Sun;
    }
  };

  const selectedHour = nowcasting[selectedHourIndex] || nowcasting[0];

  const accentRing =
    activePersona === 'farmer'
      ? 'border-amber-500 bg-amber-50'
      : activePersona === 'commuter'
      ? 'border-blue-500 bg-blue-50'
      : 'border-cyan-500 bg-cyan-50';

  return (
    <div className="mx-3 mt-3 p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
      {/* Title & Section Header */}
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
            <Clock className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900 leading-none">
              {t.nowcastingTitle}
            </h3>
            <p className="text-[10px] text-slate-500 mt-0.5">
              {t.nowcastingSubtitle}
            </p>
          </div>
        </div>

        <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
          IMD Doppler 3D
        </span>
      </div>

      {/* Horizontal Scrolling Slider */}
      <div className="flex gap-2 overflow-x-auto pb-2 pt-1 no-scrollbar -mx-1 px-1 snap-x">
        {nowcasting.map((hour, idx) => {
          const IconComponent = getIcon(hour.icon);
          const isSelected = idx === selectedHourIndex;

          return (
            <button
              key={hour.time}
              onClick={() => setSelectedHourIndex(idx)}
              className={`flex-none w-[74px] p-2.5 rounded-xl border text-center transition-all snap-start flex flex-col items-center justify-between ${
                isSelected
                  ? `${accentRing} border-2 shadow-xs scale-102`
                  : 'bg-slate-50/70 hover:bg-slate-100 border-slate-200'
              }`}
            >
              <span className={`text-[11px] font-bold ${isSelected ? 'text-slate-900' : 'text-slate-600'}`}>
                {hour.time}
              </span>

              <div className="my-1.5 relative">
                <IconComponent
                  className={`w-6 h-6 ${
                    hour.rainProb > 60
                      ? 'text-blue-600'
                      : hour.rainProb > 30
                      ? 'text-amber-500'
                      : 'text-amber-400'
                  }`}
                />
                {hour.rainProb >= 50 && (
                  <span className="absolute -top-1 -right-2 text-[8px] font-extrabold px-1 py-0.2 bg-blue-600 text-white rounded-full">
                    {hour.rainProb}%
                  </span>
                )}
              </div>

              <div className="text-sm font-black text-slate-900">
                {hour.temp}°
              </div>

              {/* Rain Probability indicator bar */}
              <div className="w-full mt-1.5 flex items-center justify-center gap-1 text-[9px] font-semibold text-blue-700">
                <Droplets className="w-2.5 h-2.5" />
                <span>{hour.rainProb}%</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Selected Hour Detailed Deep Dive Banner */}
      <div className="mt-2.5 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs bg-slate-50/80 rounded-xl p-2.5">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-bold text-slate-800">
            {selectedHour.time}: {language === 'hi' ? selectedHour.conditionHi : selectedHour.conditionEn}
          </span>
        </div>

        <div className="flex items-center gap-3 text-[11px] text-slate-600">
          <div className="flex items-center gap-1">
            <Wind className="w-3 h-3 text-slate-400" />
            <span className="font-semibold">{selectedHour.windSpeed} km/h</span>
          </div>
          <div className="flex items-center gap-1">
            <Droplets className="w-3 h-3 text-blue-500" />
            <span className="font-semibold">{selectedHour.humidity}% RH</span>
          </div>
        </div>
      </div>
    </div>
  );
};
