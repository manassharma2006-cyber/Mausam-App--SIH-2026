import React from 'react';
import { motion } from 'motion/react';
import { Wheat, Briefcase, Compass } from 'lucide-react';
import { PersonaType, AppLanguage } from '../types';
import { translations } from '../data/translations';

interface PersonaSelectorProps {
  activePersona: PersonaType;
  onSelectPersona: (persona: PersonaType) => void;
  language: AppLanguage;
}

export const PersonaSelector: React.FC<PersonaSelectorProps> = ({
  activePersona,
  onSelectPersona,
  language,
}) => {
  const t = translations[language];

  const personas = [
    {
      id: 'farmer' as PersonaType,
      labelEn: 'Farmer',
      labelHi: 'कृषक',
      subEn: 'Agri-Mode',
      subHi: 'किसान',
      icon: Wheat,
      activeColor: 'bg-gradient-to-r from-amber-600 to-emerald-700 text-white shadow-md shadow-amber-900/20',
      tagEn: 'Monsoon & Soil',
      tagHi: 'मानसून व मिट्टी',
    },
    {
      id: 'commuter' as PersonaType,
      labelEn: 'Commuter',
      labelHi: 'दैनिक यात्री',
      subEn: 'City-Mode',
      subHi: 'शहर',
      icon: Briefcase,
      activeColor: 'bg-gradient-to-r from-blue-600 to-indigo-700 text-white shadow-md shadow-blue-900/20',
      tagEn: 'Nowcast & Traffic',
      tagHi: 'नौकास्ट व ट्रैफिक',
    },
    {
      id: 'traveler' as PersonaType,
      labelEn: 'Fisherman',
      labelHi: 'नाविक / यात्री',
      subEn: 'Marine-Mode',
      subHi: 'तटीय',
      icon: Compass,
      activeColor: 'bg-gradient-to-r from-cyan-700 to-slate-900 text-white shadow-md shadow-slate-900/25',
      tagEn: 'Swell & Warnings',
      tagHi: 'लहरें व चेतावनी',
    },
  ];

  return (
    <div className="px-3 pt-3 pb-2 bg-slate-50/80 border-b border-slate-200">
      {/* Evaluator Directive Bar */}
      <div className="flex items-center justify-between gap-2 mb-1.5 px-1">
        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
          {t.switchMode} / SIH26076 Engine
        </span>
        <span className="text-[9px] text-slate-400 font-medium">
          {language === 'hi' ? 'लेआउट व प्राथमिकता तुरंत बदलेगी' : 'Instant Layout & Priority Mutation'}
        </span>
      </div>

      {/* Segmented Persona Controls */}
      <div
        id="persona-selector-container"
        className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-slate-200/80 border border-slate-300 shadow-inner"
      >
        {personas.map((p) => {
          const Icon = p.icon;
          const isActive = activePersona === p.id;

          return (
            <button
              key={p.id}
              id={`persona-tab-${p.id}`}
              onClick={() => onSelectPersona(p.id)}
              className={`relative flex flex-col items-center justify-center py-2 px-1 rounded-lg transition-all text-center focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 ${
                isActive
                  ? `${p.activeColor} scale-[1.01]`
                  : 'text-slate-700 hover:text-slate-900 hover:bg-white/60'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="activePersonaPill"
                  className="absolute inset-0 rounded-lg -z-10"
                  transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                />
              )}

              <div className="flex items-center gap-1 mb-0.5">
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-200' : 'text-slate-500'}`} />
                <span className="text-xs font-bold leading-none tracking-tight">
                  {language === 'hi' ? p.labelHi : p.labelEn}
                </span>
              </div>

              <span
                className={`text-[9px] font-medium leading-none ${
                  isActive ? 'text-slate-100 opacity-90' : 'text-slate-500'
                }`}
              >
                {language === 'hi' ? p.tagHi : p.tagEn}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
