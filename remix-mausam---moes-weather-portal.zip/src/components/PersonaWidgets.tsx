import React, { useState } from 'react';
import {
  Sprout,
  Waves,
  Wind,
  Navigation,
  Compass,
  AlertOctagon,
  Car,
  ShieldCheck,
  ExternalLink,
  Layers,
  ThermometerSun,
  Activity,
  Droplet,
  Radio,
  Clock,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import {
  SoilMoistureData,
  AgrometAdvisory,
  TrafficRainImpact,
  MarineData,
  AppLanguage,
} from '../types';
import { translations } from '../data/translations';

// --- FARMER WIDGETS ---

interface SoilMoistureWidgetProps {
  soilMoisture: SoilMoistureData;
  language: AppLanguage;
}

export const SoilMoistureWidget: React.FC<SoilMoistureWidgetProps> = ({
  soilMoisture,
  language,
}) => {
  const t = translations[language];

  return (
    <div className="mx-3 mt-3 p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
            <Sprout className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900 leading-tight">
              {t.soilMoistureTitle}
            </h3>
            <p className="text-[10px] text-slate-500">
              {t.soilMoistureSubtitle}
            </p>
          </div>
        </div>

        <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
          FC: {soilMoisture.fieldCapacityPercent}%
        </span>
      </div>

      {/* 3 Depth Levels */}
      <div className="space-y-2">
        {/* 10cm */}
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
          <div className="flex items-center justify-between text-[11px] mb-1">
            <span className="font-bold text-slate-800">{t.depth10}</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-emerald-700 font-semibold">
                {language === 'hi' ? soilMoisture.depth10cm.statusHi : soilMoisture.depth10cm.statusEn}
              </span>
              <span className="font-mono font-extrabold text-slate-900">
                {soilMoisture.depth10cm.value}%
              </span>
            </div>
          </div>
          <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
            <div
              className="h-full bg-emerald-600 rounded-full transition-all duration-500"
              style={{ width: `${soilMoisture.depth10cm.value}%` }}
            />
          </div>
        </div>

        {/* 30cm */}
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
          <div className="flex items-center justify-between text-[11px] mb-1">
            <span className="font-bold text-slate-800">{t.depth30}</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-emerald-600 font-semibold">
                {language === 'hi' ? soilMoisture.depth30cm.statusHi : soilMoisture.depth30cm.statusEn}
              </span>
              <span className="font-mono font-extrabold text-slate-900">
                {soilMoisture.depth30cm.value}%
              </span>
            </div>
          </div>
          <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
            <div
              className="h-full bg-emerald-500 rounded-full transition-all duration-500"
              style={{ width: `${soilMoisture.depth30cm.value}%` }}
            />
          </div>
        </div>

        {/* 60cm */}
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
          <div className="flex items-center justify-between text-[11px] mb-1">
            <span className="font-bold text-slate-800">{t.depth60}</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-amber-700 font-semibold">
                {language === 'hi' ? soilMoisture.depth60cm.statusHi : soilMoisture.depth60cm.statusEn}
              </span>
              <span className="font-mono font-extrabold text-slate-900">
                {soilMoisture.depth60cm.value}%
              </span>
            </div>
          </div>
          <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
            <div
              className="h-full bg-amber-500 rounded-full transition-all duration-500"
              style={{ width: `${soilMoisture.depth60cm.value}%` }}
            />
          </div>
        </div>
      </div>

      <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-600">
        <span>
          {t.evapoTrans}: <strong className="text-slate-900">{soilMoisture.evapotranspiration} mm/day</strong>
        </span>
        <span className="text-emerald-700 font-semibold">
          {language === 'hi' ? 'जड़ क्षेत्र संतृप्त' : 'Root-zone Saturated'}
        </span>
      </div>
    </div>
  );
};

interface AgrometAdvisoriesWidgetProps {
  advisories: AgrometAdvisory[];
  language: AppLanguage;
}

export const AgrometAdvisoriesWidget: React.FC<AgrometAdvisoriesWidgetProps> = ({
  advisories,
  language,
}) => {
  const [activeTab, setActiveTab] = useState(0);
  const t = translations[language];

  const currentAdv = advisories[activeTab] || advisories[0];

  return (
    <div className="mx-3 mt-3 p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center">
            <Sprout className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900 leading-tight">
              {t.agrometTitle}
            </h3>
            <p className="text-[10px] text-slate-500">
              {t.agrometSubtitle}
            </p>
          </div>
        </div>
      </div>

      {/* Crop Selector Pills */}
      <div className="flex gap-1.5 border-b border-slate-200 pb-2 mb-2">
        {advisories.map((adv, idx) => (
          <button
            key={adv.cropEn}
            onClick={() => setActiveTab(idx)}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
              activeTab === idx
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {language === 'hi' ? adv.cropHi : adv.cropEn}
          </button>
        ))}
      </div>

      {/* Current Crop Card */}
      <div className="p-2.5 rounded-xl bg-amber-50/70 border border-amber-200/80 space-y-2 text-xs">
        <div className="flex items-center justify-between border-b border-amber-200/60 pb-1.5">
          <span className="font-bold text-amber-950">
            {language === 'hi' ? 'फसल विकास चरण:' : 'Crop Stage:'}{' '}
            <span className="text-amber-800 font-semibold">{language === 'hi' ? currentAdv.stageHi : currentAdv.stageEn}</span>
          </span>
          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-200 text-amber-900">
            GKMS IMD
          </span>
        </div>

        {/* Sowing Advice */}
        <div className="flex items-start gap-1.5">
          <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="text-[11px] leading-snug text-slate-800">
            <strong className="text-slate-900">{language === 'hi' ? 'बुवाई दिशा-निर्देश:' : 'Sowing Guidelines:'} </strong>
            {language === 'hi' ? currentAdv.sowingAdviceHi : currentAdv.sowingAdviceEn}
          </div>
        </div>

        {/* Irrigation Advice */}
        <div className="flex items-start gap-1.5">
          <Droplet className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
          <div className="text-[11px] leading-snug text-slate-800">
            <strong className="text-slate-900">{language === 'hi' ? 'सिंचाई परामर्श:' : 'Irrigation Advice:'} </strong>
            {language === 'hi' ? currentAdv.irrigationAdviceHi : currentAdv.irrigationAdviceEn}
          </div>
        </div>

        {/* Spray Advice */}
        <div className="flex items-start gap-1.5">
          <XCircle className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5" />
          <div className="text-[11px] leading-snug text-slate-800">
            <strong className="text-slate-900">{language === 'hi' ? 'छिड़काव चेतावनी:' : 'Spraying Alert:'} </strong>
            {language === 'hi' ? currentAdv.sprayAdviceHi : currentAdv.sprayAdviceEn}
          </div>
        </div>
      </div>
    </div>
  );
};

// --- COMMUTER WIDGETS ---

interface AqiUvCardProps {
  aqi: {
    value: number;
    categoryEn: string;
    categoryHi: string;
    pm25: number;
    pm10: number;
    no2: number;
    healthAdvisoryEn: string;
    healthAdvisoryHi: string;
  };
  uvIndex: number;
  language: AppLanguage;
}

export const AqiUvCard: React.FC<AqiUvCardProps> = ({ aqi, uvIndex, language }) => {
  const t = translations[language];

  const getAqiColor = (val: number) => {
    if (val <= 50) return { bg: 'bg-emerald-500', text: 'text-emerald-700', badge: 'bg-emerald-100 text-emerald-800' };
    if (val <= 100) return { bg: 'bg-lime-500', text: 'text-lime-800', badge: 'bg-lime-100 text-lime-900' };
    if (val <= 200) return { bg: 'bg-amber-500', text: 'text-amber-800', badge: 'bg-amber-100 text-amber-900' };
    return { bg: 'bg-red-500', text: 'text-red-800', badge: 'bg-red-100 text-red-900' };
  };

  const aqiColor = getAqiColor(aqi.value);

  return (
    <div className="mx-3 mt-3 p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
            <Activity className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900 leading-tight">
              {t.aqiCardTitle}
            </h3>
            <p className="text-[10px] text-slate-500">
              {language === 'hi' ? 'सीपीसीबी एवं सफर (SAFAR) वास्तविक समय डेटा' : 'CPCB & SAFAR Urban Air Quality Sensor Grid'}
            </p>
          </div>
        </div>

        <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${aqiColor.badge}`}>
          {language === 'hi' ? aqi.categoryHi : aqi.categoryEn}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {/* AQI Metric */}
        <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-500">AQI Index</span>
            <span className="text-[9px] font-mono text-slate-400">PM2.5: {aqi.pm25}</span>
          </div>
          <div className="flex items-baseline gap-1 my-1">
            <span className={`text-2xl font-black ${aqiColor.text}`}>{aqi.value}</span>
            <span className="text-[10px] text-slate-400">/ 500</span>
          </div>
          <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
            <div className={`h-full ${aqiColor.bg} rounded-full`} style={{ width: `${Math.min(100, (aqi.value / 300) * 100)}%` }} />
          </div>
        </div>

        {/* UV Index Metric */}
        <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-500">UV Index</span>
            <ThermometerSun className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-2xl font-black text-amber-600">{uvIndex}</span>
            <span className="text-[10px] text-slate-500">
              {uvIndex > 5 ? (language === 'hi' ? 'मध्यम-उच्च' : 'Moderate-High') : (language === 'hi' ? 'सामान्य' : 'Low')}
            </span>
          </div>
          <span className="text-[9px] text-slate-500">
            {language === 'hi' ? 'दोपहर में धूप से बचाव रखें' : 'Sun protection advised'}
          </span>
        </div>
      </div>

      {/* Commuter Health Guidance */}
      <div className="mt-2.5 p-2 rounded-lg bg-blue-50/60 border border-blue-100 text-[11px] text-blue-950 flex items-start gap-1.5">
        <ShieldCheck className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
        <p className="leading-tight">
          {language === 'hi' ? aqi.healthAdvisoryHi : aqi.healthAdvisoryEn}
        </p>
      </div>
    </div>
  );
};

interface TrafficRainImpactsWidgetProps {
  impacts: TrafficRainImpact[];
  language: AppLanguage;
}

export const TrafficRainImpactsWidget: React.FC<TrafficRainImpactsWidgetProps> = ({
  impacts,
  language,
}) => {
  const t = translations[language];

  return (
    <div className="mx-3 mt-3 p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-lg bg-red-100 text-red-700 flex items-center justify-center">
            <Car className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900 leading-tight">
              {t.trafficTitle}
            </h3>
            <p className="text-[10px] text-slate-500">
              {t.trafficSubtitle}
            </p>
          </div>
        </div>

        <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-800 animate-pulse">
          Traffic Police Sync
        </span>
      </div>

      <div className="space-y-2">
        {impacts.map((corridor) => {
          const isHigh = corridor.riskLevel === 'High';
          const isMed = corridor.riskLevel === 'Medium';

          const badgeStyle = isHigh
            ? 'bg-red-100 text-red-800 border-red-300'
            : isMed
            ? 'bg-amber-100 text-amber-800 border-amber-300'
            : 'bg-emerald-100 text-emerald-800 border-emerald-300';

          return (
            <div
              key={corridor.corridorEn}
              className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-bold text-slate-900 text-[11px]">
                  {language === 'hi' ? corridor.corridorHi : corridor.corridorEn}
                </span>
                <span className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded border ${badgeStyle}`}>
                  {language === 'hi' ? corridor.riskLevelHi : corridor.riskLevel}
                </span>
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-600">
                <span>
                  {language === 'hi' ? 'जलभराव गहराई:' : 'Water Depth:'}{' '}
                  <strong className={isHigh ? 'text-red-700 font-extrabold' : 'text-slate-800'}>
                    {corridor.waterloggingDepthCm} cm
                  </strong>
                </span>
                <span className="font-semibold text-slate-700">
                  {language === 'hi' ? corridor.delayEstimateHi : corridor.delayEstimateEn}
                </span>
              </div>

              <p className="text-[10px] text-slate-600 bg-white p-1.5 rounded border border-slate-200/80 mt-1">
                {language === 'hi' ? corridor.statusNoteHi : corridor.statusNoteEn}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// --- TRAVELER / FISHERMAN WIDGETS ---

interface MarineStatusWidgetProps {
  marineData: MarineData;
  language: AppLanguage;
  onOpenRadar: () => void;
}

export const MarineStatusWidget: React.FC<MarineStatusWidgetProps> = ({
  marineData,
  language,
  onOpenRadar,
}) => {
  const t = translations[language];

  return (
    <div className="mx-3 mt-3 p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-lg bg-cyan-100 text-cyan-900 flex items-center justify-center">
            <Waves className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900 leading-tight">
              {t.marineTitle}
            </h3>
            <p className="text-[10px] text-slate-500">
              {language === 'hi' ? 'समुद्री तरंग, हवा की गति व इनकॉइस ज्वार डेटा' : 'Ocean buoy telemetry & wave energy dissipation'}
            </p>
          </div>
        </div>

        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-800 border border-red-200">
          INCOIS Red Alert
        </span>
      </div>

      {/* Metric Grid */}
      <div className="grid grid-cols-2 gap-2">
        {/* Wave Height */}
        <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
          <span className="text-[10px] font-bold text-slate-500 block">{t.waveHeight}</span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-2xl font-black text-cyan-900">{marineData.waveHeightM}</span>
            <span className="text-xs font-bold text-slate-600">meters (ऊंचाई)</span>
          </div>
          <span className="text-[9px] text-red-600 font-bold block">
            {language === 'hi' ? 'अति अशांत समुद्र (Rough)' : 'Swell Warning Active'}
          </span>
        </div>

        {/* Sustained Winds */}
        <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
          <span className="text-[10px] font-bold text-slate-500 block">{t.windKnots}</span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-2xl font-black text-slate-900">{marineData.windSpeedKnots}</span>
            <span className="text-xs font-bold text-slate-600">knots (गांठें)</span>
          </div>
          <span className="text-[9px] text-slate-500 font-medium block">
            Gusts to {marineData.windGustsKnots} kts
          </span>
        </div>
      </div>

      {/* Tide & Sea State */}
      <div className="mt-2.5 p-2 rounded-xl bg-cyan-50/70 border border-cyan-200 text-xs space-y-1">
        <div className="flex items-center justify-between text-[11px] font-bold text-cyan-950">
          <span>{language === 'hi' ? 'समुद्री स्थिति:' : 'Sea State:'}</span>
          <span className="text-cyan-800">{language === 'hi' ? marineData.seaStateHi : marineData.seaStateEn}</span>
        </div>
        <div className="text-[10px] text-slate-600 flex items-center gap-1">
          <Clock className="w-3 h-3 text-cyan-700 shrink-0" />
          <span>{language === 'hi' ? marineData.tideNextHi : marineData.tideNextEn}</span>
        </div>
      </div>

      {/* Severe Marine Warning Bulletin Banner */}
      <div className="mt-2.5 p-2.5 rounded-xl bg-red-50 border border-red-200 text-xs">
        <div className="flex items-center gap-1.5 text-red-900 font-extrabold mb-1">
          <AlertOctagon className="w-4 h-4 text-red-600 shrink-0" />
          <span>{t.marineBulletinTitle}</span>
        </div>
        <p className="text-[11px] text-red-800 leading-snug">
          {language === 'hi' ? marineData.incoisBulletinHi : marineData.incoisBulletinEn}
        </p>
      </div>

      {/* Live Satellite Radar Quick-Link */}
      <button
        onClick={onOpenRadar}
        className="w-full mt-2.5 p-2.5 rounded-xl bg-linear-to-r from-slate-900 to-cyan-950 text-white flex items-center justify-between hover:from-slate-800 hover:to-cyan-900 transition-all shadow-xs"
      >
        <div className="flex items-center gap-2">
          <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
          <div className="text-left">
            <span className="text-xs font-bold block">{t.satelliteRadarLink}</span>
            <span className="text-[9px] text-slate-300 block">{t.satelliteRadarDesc}</span>
          </div>
        </div>
        <ExternalLink className="w-4 h-4 text-cyan-300" />
      </button>
    </div>
  );
};
