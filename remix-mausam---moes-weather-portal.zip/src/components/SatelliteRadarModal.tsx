import React from 'react';
import { X, Radio, Layers, ZoomIn, ZoomOut, RefreshCw } from 'lucide-react';
import { AppLanguage } from '../types';

interface SatelliteRadarModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
}

export const SatelliteRadarModal: React.FC<SatelliteRadarModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 animate-fade-in">
      <div className="w-full max-w-md bg-slate-950 text-white rounded-3xl shadow-2xl border border-slate-800 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
            <div>
              <h3 className="text-xs font-bold text-white leading-none">
                INSAT-3D Thermal IR & Coastal Radar (Kochi Sector)
              </h3>
              <p className="text-[10px] text-cyan-300 font-mono mt-0.5">
                IMD DWR Kochi • Reflectivity Z (dBZ) Max Sweep
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Doppler Radar Simulated Canvas */}
        <div className="p-3 bg-slate-950 flex flex-col items-center">
          <div className="w-full aspect-square max-w-[340px] rounded-2xl bg-slate-900 border border-slate-800 relative overflow-hidden flex items-center justify-center">
            {/* Range Rings */}
            <div className="absolute inset-4 rounded-full border border-cyan-500/20" />
            <div className="absolute inset-12 rounded-full border border-cyan-500/25" />
            <div className="absolute inset-20 rounded-full border border-cyan-500/30" />
            
            {/* Center Crosshairs */}
            <div className="absolute w-full h-[1px] bg-cyan-500/20" />
            <div className="absolute h-full w-[1px] bg-cyan-500/20" />

            {/* Sweep radar beam animation */}
            <div
              className="absolute inset-0 origin-center pointer-events-none"
              style={{
                background: 'conic-gradient(from 0deg, transparent 0deg, rgba(6, 182, 212, 0.25) 60deg, transparent 65deg)',
                animation: 'spin 4s linear infinite',
              }}
            />

            {/* Simulated Radar Rain Echoes (Color Reflectivity dBZ) */}
            <div className="absolute top-1/4 left-1/3 w-28 h-20 bg-emerald-500/40 rounded-full blur-md" />
            <div className="absolute top-[28%] left-[36%] w-16 h-12 bg-amber-500/60 rounded-full blur-sm" />
            <div className="absolute top-[30%] left-[39%] w-8 h-8 bg-red-600/80 rounded-full blur-xs animate-pulse" />

            {/* Coastline outline stylized */}
            <svg className="absolute inset-0 w-full h-full stroke-cyan-400/40 fill-none" viewBox="0 0 100 100">
              <path d="M68,0 Q72,30 65,55 T60,100" strokeWidth="1.5" />
              <circle cx="63" cy="52" r="1.5" fill="#38bdf8" />
              <text x="66" y="54" fill="#bae6fd" fontSize="4" fontFamily="monospace">Kochi DWR</text>
            </svg>

            {/* Live indicator */}
            <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/60 border border-slate-700 text-[9px] font-mono text-cyan-300 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              <span>LIVE SWEEP: 12:45 IST</span>
            </div>

            <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-black/60 border border-slate-700 text-[9px] font-mono text-red-400 font-bold">
              MAX: 52 dBZ (Squall)
            </div>
          </div>

          {/* dBZ Reflectivity Legend */}
          <div className="w-full max-w-[340px] mt-3">
            <div className="flex justify-between text-[9px] font-mono text-slate-400 mb-1">
              <span>Light Rain (15 dBZ)</span>
              <span>Moderate (35 dBZ)</span>
              <span className="text-red-400 font-bold">Gale Storm (55+ dBZ)</span>
            </div>
            <div className="h-2 w-full rounded-full bg-linear-to-r from-blue-500 via-emerald-400 via-amber-400 to-red-600" />
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between">
          <span className="text-[10px] text-slate-400">
            Source: IMD Radar Operations Centre & INCOIS
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-colors"
          >
            {language === 'hi' ? 'वापस जाएं' : 'Back to Home'}
          </button>
        </div>
      </div>
    </div>
  );
};
