import React, { useState } from 'react';
import {
  Settings,
  X,
  Languages,
  Thermometer,
  Wifi,
  Database,
  Check,
  RefreshCw,
  ShieldAlert,
  Volume2,
  Sparkles,
} from 'lucide-react';
import { AppLanguage } from '../types';
import { translations } from '../data/translations';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onLanguageChange: (lang: AppLanguage) => void;
  tempUnit: 'celsius' | 'fahrenheit';
  onTempUnitChange: (unit: 'celsius' | 'fahrenheit') => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  language,
  onLanguageChange,
  tempUnit,
  onTempUnitChange,
}) => {
  const [dataSaver, setDataSaver] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncToast, setSyncToast] = useState(false);
  const t = translations[language];

  if (!isOpen) return null;

  const handleSyncData = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncToast(true);
      setTimeout(() => setSyncToast(false), 2200);
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-3 animate-fade-in">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Authentic Indian Government Tricolor Header Bar */}
        <div className="h-1.5 w-full flex">
          <div className="flex-1 bg-[#FF9933]" />
          <div className="flex-1 bg-white relative flex items-center justify-center border-y border-slate-200">
            <div className="w-1.5 h-1.5 rounded-full border border-blue-900" />
          </div>
          <div className="flex-1 bg-[#138808]" />
        </div>

        {/* Modal Header */}
        <div className="p-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-600 text-white flex items-center justify-center shadow-xs">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">
                  {t.govtIndia}
                </span>
                <span className="text-[9px] px-1 py-0.2 rounded bg-orange-100 text-orange-900 font-bold">
                  SIH26076
                </span>
              </div>
              <h3 className="text-xs font-black text-slate-900 leading-tight">
                {t.settingsTitle}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 space-y-4 overflow-y-auto text-xs">
          {/* MANDATORY BILINGUAL LANGUAGE TOGGLE (Tricolor Themed) */}
          <div className="p-3.5 rounded-2xl bg-linear-to-br from-orange-50/90 via-white to-emerald-50/90 border-2 border-orange-300 shadow-xs space-y-2.5">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-orange-600 text-white flex items-center justify-center shadow-xs">
                  <Languages className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-slate-900 text-xs">
                      {t.languageLabel}
                    </span>
                    <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                      Bilingual
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-600 leading-tight block mt-0.5">
                    {t.languageSub}
                  </span>
                </div>
              </div>
            </div>

            {/* High-Fidelity Saffron / Green Segmented Control */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              {/* English Option */}
              <button
                id="settings-lang-en-btn"
                onClick={() => onLanguageChange('en')}
                className={`py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-between border-2 transition-all cursor-pointer ${
                  language === 'en'
                    ? 'bg-orange-600 text-white border-orange-700 shadow-md scale-[1.02]'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-orange-300 hover:bg-orange-50/40'
                }`}
              >
                <div className="text-left">
                  <span className="block font-black text-xs leading-none">English</span>
                  <span
                    className={`text-[9px] block mt-0.5 ${
                      language === 'en' ? 'text-orange-100' : 'text-slate-400'
                    }`}
                  >
                    अंग्रेजी
                  </span>
                </div>
                {language === 'en' && (
                  <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center">
                    <Check className="w-3.5 h-3.5 text-white" />
                  </div>
                )}
              </button>

              {/* Hindi Option */}
              <button
                id="settings-lang-hi-btn"
                onClick={() => onLanguageChange('hi')}
                className={`py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-between border-2 transition-all cursor-pointer ${
                  language === 'hi'
                    ? 'bg-emerald-700 text-white border-emerald-800 shadow-md scale-[1.02]'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/40'
                }`}
              >
                <div className="text-left">
                  <span className="block font-black text-xs leading-none">हिन्दी</span>
                  <span
                    className={`text-[9px] block mt-0.5 ${
                      language === 'hi' ? 'text-emerald-100' : 'text-slate-400'
                    }`}
                  >
                    Hindi
                  </span>
                </div>
                {language === 'hi' && (
                  <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center">
                    <Check className="w-3.5 h-3.5 text-white" />
                  </div>
                )}
              </button>
            </div>

            {/* Active Language Confirmation Banner */}
            <div className="flex items-center gap-1.5 text-[10px] text-slate-600 bg-white/90 p-1.5 rounded-lg border border-slate-200/80">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
              <span>
                {language === 'hi'
                  ? 'सक्रिय इंटरफ़ेस: हिन्दी भाषा में सभी मौसम विवरण व परामर्श उपलब्ध हैं।'
                  : 'Active interface: All weather bulletins, charts, and voice readouts are in English.'}
              </span>
            </div>
          </div>

          {/* Temperature Units Switcher */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center gap-2">
              <Thermometer className="w-4 h-4 text-orange-600" />
              <div>
                <span className="font-bold text-slate-900 block text-xs">
                  {t.unitsLabel}
                </span>
                <span className="text-[10px] text-slate-500">
                  {language === 'hi'
                    ? 'तापमान मापन पैमाना (सेल्सियस अथवा फ़ारेनहाइट)'
                    : 'Select preferred temperature measurement scale'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                id="settings-unit-celsius-btn"
                onClick={() => onTempUnitChange('celsius')}
                className={`py-1.5 px-3 rounded-xl font-bold text-xs border flex items-center justify-between transition-all ${
                  tempUnit === 'celsius'
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>Celsius (°C)</span>
                {tempUnit === 'celsius' && <Check className="w-3.5 h-3.5" />}
              </button>

              <button
                id="settings-unit-fahrenheit-btn"
                onClick={() => onTempUnitChange('fahrenheit')}
                className={`py-1.5 px-3 rounded-xl font-bold text-xs border flex items-center justify-between transition-all ${
                  tempUnit === 'fahrenheit'
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>Fahrenheit (°F)</span>
                {tempUnit === 'fahrenheit' && <Check className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Low Bandwidth Rural / Maritime Mode */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Wifi className="w-4 h-4 text-emerald-600" />
              <div>
                <span className="font-bold text-slate-900 block text-xs">
                  {language === 'hi' ? 'कम डेटा खपत मोड (2G/3G Saver)' : 'Low-Bandwidth Rural Mode'}
                </span>
                <span className="text-[10px] text-slate-500">
                  {language === 'hi'
                    ? 'दूरदराज के खेतों व तटीय क्षेत्रों में त्वरित लोडिंग'
                    : 'Compress Doppler radar and satellite telemetry for slow rural connectivity'}
                </span>
              </div>
            </div>

            <button
              onClick={() => setDataSaver(!dataSaver)}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                dataSaver ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  dataSaver ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* IMD Data Synchronization */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-600" />
                <div>
                  <span className="font-bold text-slate-900 block text-xs">
                    {t.dataSource}
                  </span>
                  <span className="text-[10px] text-slate-500">{t.lastSync}</span>
                </div>
              </div>

              <button
                onClick={handleSyncData}
                disabled={isSyncing}
                className="p-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 shadow-2xs"
                title="Sync IMD Telemetry"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-orange-600' : ''}`} />
              </button>
            </div>

            {syncToast && (
              <div className="text-[10px] text-emerald-800 bg-emerald-50 border border-emerald-200 p-1.5 rounded-md font-bold animate-fade-in flex items-center gap-1">
                <Check className="w-3 h-3 text-emerald-600" />
                <span>
                  {language === 'hi'
                    ? 'आईएमडी वेधशाला ग्रिड से नवीनतम डेटा सफलतापूर्वक प्राप्त हुआ।'
                    : 'Successfully synchronized with IMD AWS Central Telemetry.'}
                </span>
              </div>
            )}

            <div className="text-[9px] text-slate-400 pt-1 border-t border-slate-200/60 font-mono">
              Server: MoES National Data Center, Mausam Bhavan, New Delhi (AWS-Grid-v4)
            </div>
          </div>

          {/* Ministry Emblems and Hackathon Recognition */}
          <div className="text-center pt-2 text-[10px] text-slate-500 space-y-1 bg-orange-50/40 p-2.5 rounded-xl border border-orange-100">
            <div className="font-extrabold text-slate-800 tracking-wide">
              {language === 'hi' ? 'सत्यमेव जयते' : 'SATYAMEVA JAYATE'}
            </div>
            <div className="font-bold text-orange-800">
              Smart India Hackathon (SIH26076)
            </div>
            <div className="text-slate-600">
              {language === 'hi'
                ? 'पृथ्वी विज्ञान मंत्रालय • भारत सरकार'
                : 'Ministry of Earth Sciences (MoES) • Government of India'}
            </div>
          </div>
        </div>

        {/* Footer with Close Button */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="text-[10px] text-slate-500 font-semibold">
            {language === 'hi' ? 'संस्करण: 3.4 (आईएमडी)' : 'Version 3.4 (IMD MoES)'}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-900 text-white font-bold text-xs hover:bg-slate-800 transition-colors shadow-xs"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
