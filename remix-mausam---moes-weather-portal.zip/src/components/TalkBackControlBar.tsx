import React, { useState, useEffect, useRef } from 'react';
import {
  Volume2,
  VolumeX,
  Play,
  Pause,
  Square,
  Sparkles,
  Radio,
  Mic,
  Languages,
  Check,
  AlertTriangle,
  FileText,
  Clock,
} from 'lucide-react';
import { AppLanguage, PersonaType, PersonaWeatherData } from '../types';
import { translations } from '../data/translations';

interface TalkBackControlBarProps {
  weatherData: PersonaWeatherData;
  activePersona: PersonaType;
  language: AppLanguage;
  onOpenAssistantModal: () => void;
  onLanguageChange?: (lang: AppLanguage) => void;
}

export const TalkBackControlBar: React.FC<TalkBackControlBarProps> = ({
  weatherData,
  activePersona,
  language,
  onOpenAssistantModal,
  onLanguageChange,
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [activeTopic, setActiveTopic] = useState<'full' | 'alerts' | 'advisory' | 'trend'>('full');
  const [currentCaption, setCurrentCaption] = useState<string>('');
  const [voiceLoaded, setVoiceLoaded] = useState<boolean>(false);

  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const t = translations[language];

  // Helper to expand meteorological abbreviations into natural speech
  const prepareSpeechScript = (topic: 'full' | 'alerts' | 'advisory' | 'trend'): string => {
    const locName = language === 'hi' ? weatherData.location.nameHi : weatherData.location.nameEn;
    const temp = Math.round(weatherData.currentTemp);
    const feels = Math.round(weatherData.feelsLike);
    const humidity = weatherData.humidity;
    const condition = language === 'hi' ? weatherData.conditionHi : weatherData.conditionEn;
    const wind = weatherData.windSpeedKmh;

    if (language === 'hi') {
      // Natural Hindi Phrasing with phonetic clarity
      if (topic === 'alerts') {
        if (weatherData.contextualAlert) {
          return `मौसम चेतावनी सूचना। ${locName} के लिए भारत मौसम विज्ञान विभाग ने ${weatherData.contextualAlert.titleHi} जारी किया है। ${weatherData.contextualAlert.detailsHi}। कृपया सतर्क रहें और आधिकारिक निर्देशों का पालन करें।`;
        }
        return `मौसम सूचना। ${locName} में कोई गंभीर आपातकालीन चेतावनी नहीं है। सामान्य मौसम गतिविधियां जारी हैं।`;
      }

      if (topic === 'advisory') {
        if (activePersona === 'farmer') {
          return `ग्रामीण कृषि मौसम सेवा विशेष बुलेटिन। ${weatherData.aiAdvisory.headlineHi}। मुख्य परामर्श: ${weatherData.aiAdvisory.contentHi}। किसान भाई ध्यान दें: ${weatherData.aiAdvisory.actionItemsHi.join('। ')}।`;
        }
        if (activePersona === 'commuter') {
          return `शहरी दैनिक यात्री परामर्श। ${weatherData.aiAdvisory.headlineHi}। जलभराव व मार्ग स्थिति: ${weatherData.aiAdvisory.contentHi}। यात्रा सुझाव: ${weatherData.aiAdvisory.actionItemsHi.join('। ')}।`;
        }
        return `तटीय व समुद्री सुरक्षा बुलेटिन। ${weatherData.aiAdvisory.headlineHi}। समुद्र की स्थिति: ${weatherData.aiAdvisory.contentHi}। नाविक निर्देश: ${weatherData.aiAdvisory.actionItemsHi.join('। ')}।`;
      }

      if (topic === 'trend') {
        const firstDay = weatherData.pastSevenDaysTemp[0];
        const lastDay = weatherData.pastSevenDaysTemp[weatherData.pastSevenDaysTemp.length - 1];
        return `विगत सात दिनों का तापमान विश्लेषण। ${locName} वेधशाला में अधिकतम तापमान ${firstDay.tempMax} डिग्री से ${lastDay.tempMax} डिग्री सेल्सियस के बीच दर्ज किया गया। सामान्य स्तर की तुलना में वर्तमान विचलन ${lastDay.departure > 0 ? 'प्लस ' + lastDay.departure : lastDay.departure} डिग्री सेल्सियस है।`;
      }

      // Default Full Bulletin in Hindi
      const alertSnippet = weatherData.contextualAlert
        ? `विशेष चेतावनी: ${weatherData.contextualAlert.titleHi}। `
        : '';
      const advisorySnippet = weatherData.aiAdvisory
        ? `प्रमुख परामर्श: ${weatherData.aiAdvisory.headlineHi}। `
        : '';

      return `नमस्ते। भारत मौसम विज्ञान विभाग का राष्ट्रीय मौसम वाणी प्रसारण। ${locName} में वर्तमान तापमान ${temp} डिग्री सेल्सियस है, जो ${feels} डिग्री जैसा महसूस हो रहा है। मौसम की स्थिति ${condition} है। हवा में आर्द्रता ${humidity} प्रतिशत तथा हवा की गति ${wind} किलोमीटर प्रति घंटा दर्ज की गई है। ${alertSnippet}${advisorySnippet}आपका दिन मंगलमय हो।`;
    }

    // Natural English Phrasing
    if (topic === 'alerts') {
      if (weatherData.contextualAlert) {
        return `Meteorological Alert Notification. India Meteorological Department has issued ${weatherData.contextualAlert.titleEn} for ${locName}. ${weatherData.contextualAlert.detailsEn}. Please take recommended safety precautions.`;
      }
      return `Meteorological Notification. No extreme warnings are currently active for ${locName}. Conditions remain nominal.`;
    }

    if (topic === 'advisory') {
      if (activePersona === 'farmer') {
        return `Gramin Krishi Mausam Sewa Field Advisory. ${weatherData.aiAdvisory.headlineEn}. Advisory note: ${weatherData.aiAdvisory.contentEn}. Key action items: ${weatherData.aiAdvisory.actionItemsEn.join('. ')}.`;
      }
      if (activePersona === 'commuter') {
        return `Urban Transit & Rain Advisory. ${weatherData.aiAdvisory.headlineEn}. Transit outlook: ${weatherData.aiAdvisory.contentEn}. Recommendations: ${weatherData.aiAdvisory.actionItemsEn.join('. ')}.`;
      }
      return `Coastal Marine Safety Advisory. ${weatherData.aiAdvisory.headlineEn}. Sea state outlook: ${weatherData.aiAdvisory.contentEn}. Marine warnings: ${weatherData.aiAdvisory.actionItemsEn.join('. ')}.`;
    }

    if (topic === 'trend') {
      const firstDay = weatherData.pastSevenDaysTemp[0];
      const lastDay = weatherData.pastSevenDaysTemp[weatherData.pastSevenDaysTemp.length - 1];
      return `Past seven days temperature trend analysis for ${locName}. Recorded maximum temperatures spanned from ${firstDay.tempMax} to ${lastDay.tempMax} degrees Celsius. Climatological departure stands at ${lastDay.departure > 0 ? 'plus ' + lastDay.departure : lastDay.departure} degrees Celsius.`;
    }

    // Default Full Bulletin in English
    const alertSnippet = weatherData.contextualAlert
      ? `Alert notice: ${weatherData.contextualAlert.titleEn}. `
      : '';
    const advisorySnippet = weatherData.aiAdvisory
      ? `Operational guidance: ${weatherData.aiAdvisory.headlineEn}. `
      : '';

    return `Welcome to Mausam Vani National Meteorological Audio Bulletin. At ${locName}, the current temperature is ${temp} degrees Celsius, with a feels-like temperature of ${feels} degrees. Observed weather condition is ${condition}. Relative humidity is ${humidity} percent, with winds blowing at ${wind} kilometers per hour. ${alertSnippet}${advisorySnippet}Have a safe and productive day.`;
  };

  // Find best speech synthesis voice
  const getBestVoice = (lang: AppLanguage): SpeechSynthesisVoice | null => {
    if (!('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices();
    if (voices.length === 0) return null;

    if (lang === 'hi') {
      const hiVoice =
        voices.find((v) => v.lang.startsWith('hi') || v.name.toLowerCase().includes('hindi')) ||
        voices.find((v) => v.lang === 'hi-IN' || v.lang === 'hi_IN');
      if (hiVoice) return hiVoice;
    }

    // For English (India)
    const enInVoice =
      voices.find((v) => v.lang === 'en-IN' || v.lang === 'en_IN') ||
      voices.find((v) => v.name.toLowerCase().includes('india') || v.name.toLowerCase().includes('veena')) ||
      voices.find((v) => v.lang.startsWith('en'));

    return enInVoice || voices[0] || null;
  };

  useEffect(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = () => {
        setVoiceLoaded(true);
      };
      setVoiceLoaded(true);
    }

    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Handle Play
  const handlePlay = (topicToPlay = activeTopic) => {
    if (!('speechSynthesis' in window)) {
      alert(language === 'hi' ? 'आपके ब्राउज़र में वाणी संश्लेषण उपलब्ध नहीं है।' : 'Speech synthesis not supported in this browser.');
      return;
    }

    window.speechSynthesis.cancel();
    const script = prepareSpeechScript(topicToPlay);
    setCurrentCaption(script);

    const utterance = new SpeechSynthesisUtterance(script);
    utterance.rate = speechRate;
    utterance.pitch = 1.0;
    utterance.lang = language === 'hi' ? 'hi-IN' : 'en-IN';

    const selectedVoice = getBestVoice(language);
    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }

    utterance.onstart = () => {
      setIsPlaying(true);
      setIsPaused(false);
    };

    utterance.onend = () => {
      setIsPlaying(false);
      setIsPaused(false);
      setCurrentCaption('');
    };

    utterance.onerror = () => {
      setIsPlaying(false);
      setIsPaused(false);
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  // Handle Pause / Resume
  const handleTogglePause = () => {
    if (!('speechSynthesis' in window)) return;
    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
      setIsPlaying(true);
    } else {
      window.speechSynthesis.pause();
      setIsPaused(true);
      setIsPlaying(false);
    }
  };

  // Handle Stop
  const handleStop = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(false);
    setIsPaused(false);
    setCurrentCaption('');
  };

  // When speech rate changes while speaking, restart at new speed
  const handleRateChange = (newRate: number) => {
    setSpeechRate(newRate);
    if (isPlaying) {
      handlePlay(activeTopic);
    }
  };

  // When topic chip clicked
  const handleTopicClick = (topic: 'full' | 'alerts' | 'advisory' | 'trend') => {
    setActiveTopic(topic);
    if (isPlaying) {
      handlePlay(topic);
    }
  };

  return (
    <div
      id="talkback-dedicated-control-bar"
      className="mx-3 mt-3 rounded-2xl bg-linear-to-r from-orange-50/90 via-amber-50/70 to-emerald-50/80 border border-orange-200/90 shadow-xs p-3 transition-all"
    >
      {/* Top Title & Audio Wave Visualizer Row */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-2">
          <div
            className={`w-8 h-8 rounded-xl flex items-center justify-center shadow-xs transition-colors ${
              isPlaying
                ? 'bg-orange-600 text-white animate-pulse'
                : 'bg-white border border-orange-300 text-orange-700'
            }`}
          >
            <Radio className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3 className="text-xs font-bold text-slate-900 leading-tight">
                {t.talkBackControlTitle}
              </h3>
              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-orange-200 text-orange-900">
                {language === 'hi' ? 'द्विभाषी वाणी' : 'Bilingual TTS'}
              </span>
            </div>
            <p className="text-[10px] text-slate-600">
              {isPlaying
                ? t.talkBackSpeakingNow
                : isPaused
                ? language === 'hi'
                  ? 'ऑडियो रुका हुआ है'
                  : 'Audio paused'
                : t.talkBackControlSub}
            </p>
          </div>
        </div>

        {/* Animated Equalizer Waveform while speaking */}
        {isPlaying && (
          <div className="flex items-center gap-0.5 px-2 py-1 rounded-md bg-orange-100 border border-orange-300 shrink-0">
            <span className="w-1 h-3 bg-orange-600 rounded-full animate-bounce [animation-delay:-0.3s]" />
            <span className="w-1 h-4.5 bg-orange-700 rounded-full animate-bounce [animation-delay:-0.15s]" />
            <span className="w-1 h-2.5 bg-orange-500 rounded-full animate-bounce [animation-delay:-0.4s]" />
            <span className="w-1 h-5 bg-amber-600 rounded-full animate-bounce [animation-delay:-0.2s]" />
            <span className="w-1 h-3.5 bg-emerald-600 rounded-full animate-bounce" />
          </div>
        )}
      </div>

      {/* Main Playback & Topic Controls */}
      <div className="flex items-center justify-between gap-2 pt-1 border-t border-orange-200/50 flex-wrap">
        {/* Play/Pause & Stop Button Group */}
        <div className="flex items-center gap-1.5">
          {!isPlaying && !isPaused ? (
            <button
              id="talkback-play-btn"
              onClick={() => handlePlay()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold shadow-xs active:scale-95 transition-all"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{t.talkBackPlay}</span>
            </button>
          ) : (
            <div className="flex items-center gap-1">
              <button
                id="talkback-pause-btn"
                onClick={handleTogglePause}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs active:scale-95 transition-all"
              >
                {isPaused ? <Play className="w-3 h-3 fill-current" /> : <Pause className="w-3 h-3" />}
                <span>{isPaused ? t.talkBackResume : t.talkBackPause}</span>
              </button>
              <button
                id="talkback-stop-btn"
                onClick={handleStop}
                className="p-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold shadow-xs active:scale-95 transition-all"
                title={t.talkBackStop}
              >
                <Square className="w-3.5 h-3.5 fill-current" />
              </button>
            </div>
          )}

          {/* Voice Speed Selector */}
          <div className="flex items-center gap-1 bg-white/90 border border-orange-200/80 rounded-lg p-0.5 text-[10px]">
            <span className="text-[9px] font-bold text-slate-500 pl-1">
              {t.talkBackSpeed}
            </span>
            {[0.8, 1.0, 1.2].map((rate) => (
              <button
                key={rate}
                onClick={() => handleRateChange(rate)}
                className={`px-1.5 py-0.5 rounded font-bold transition-colors ${
                  speechRate === rate
                    ? 'bg-orange-600 text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {rate}x
              </button>
            ))}
          </div>
        </div>

        {/* Action to launch interactive Dialogue Assistant */}
        <button
          onClick={onOpenAssistantModal}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white border border-emerald-300 text-emerald-800 hover:bg-emerald-50 text-[11px] font-bold shadow-2xs transition-all"
        >
          <Mic className="w-3.5 h-3.5 text-emerald-600" />
          <span>{t.talkBackOpenAssistant}</span>
        </button>
      </div>

      {/* Quick Topic Filters */}
      <div className="mt-2 flex items-center gap-1 overflow-x-auto no-scrollbar pt-1">
        <span className="text-[9px] font-bold text-slate-500 shrink-0">
          {t.talkBackTopic}
        </span>
        <button
          onClick={() => handleTopicClick('full')}
          className={`px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap transition-colors ${
            activeTopic === 'full'
              ? 'bg-slate-900 text-white'
              : 'bg-white/80 border border-slate-200 text-slate-700 hover:bg-white'
          }`}
        >
          {t.topicFull}
        </button>
        <button
          onClick={() => handleTopicClick('alerts')}
          className={`px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap transition-colors ${
            activeTopic === 'alerts'
              ? 'bg-red-600 text-white'
              : 'bg-white/80 border border-slate-200 text-slate-700 hover:bg-white'
          }`}
        >
          {t.topicAlerts}
        </button>
        <button
          onClick={() => handleTopicClick('advisory')}
          className={`px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap transition-colors ${
            activeTopic === 'advisory'
              ? 'bg-amber-700 text-white'
              : 'bg-white/80 border border-slate-200 text-slate-700 hover:bg-white'
          }`}
        >
          {t.topicAdvisory}
        </button>
        <button
          onClick={() => handleTopicClick('trend')}
          className={`px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap transition-colors ${
            activeTopic === 'trend'
              ? 'bg-blue-700 text-white'
              : 'bg-white/80 border border-slate-200 text-slate-700 hover:bg-white'
          }`}
        >
          {t.topicTempTrend}
        </button>
      </div>

      {/* Spoken Transcript / Live Caption display */}
      {currentCaption && (
        <div className="mt-2.5 p-2 rounded-xl bg-white/95 border border-orange-200/80 shadow-2xs text-[11px] text-slate-800 leading-relaxed animate-fade-in flex items-start gap-1.5">
          <Volume2 className="w-3.5 h-3.5 text-orange-600 shrink-0 mt-0.5 animate-pulse" />
          <p className="line-clamp-3 italic font-medium">
            "{currentCaption}"
          </p>
        </div>
      )}
    </div>
  );
};
