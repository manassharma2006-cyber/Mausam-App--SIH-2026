import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Send,
  X,
  Sparkles,
  Bot,
  User,
  Radio,
  RotateCcw,
  Languages,
} from 'lucide-react';
import { AppLanguage, PersonaType, PersonaWeatherData } from '../types';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

interface TalkBackModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onLanguageChange: (lang: AppLanguage) => void;
  activePersona: PersonaType;
  weatherData: PersonaWeatherData;
}

export const TalkBackModal: React.FC<TalkBackModalProps> = ({
  isOpen,
  onClose,
  language,
  onLanguageChange,
  activePersona,
  weatherData,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-msg',
      sender: 'assistant',
      text:
        language === 'hi'
          ? 'नमस्ते! मैं मौसम वाणी (Mausam Vani) हूँ, पृथ्वी विज्ञान मंत्रालय का मौसम सहायक। आप मुझसे वर्षा, तापमान, मृदा नमी, या फसल/यात्रा से संबंधित कोई भी प्रश्न पूछ सकते हैं।'
          : 'Namaste! I am Mausam Vani, the official MoES AI Weather Voice Assistant. Ask me anything about rainfall, temperatures, soil moisture, traffic inundation, or marine swell.',
      timestamp: 'Just now',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Suggested questions based on persona and language
  const suggestedQuestions =
    language === 'hi'
      ? activePersona === 'farmer'
        ? [
            'क्या आज अमृतसर में बारिश होगी?',
            'गेहूं की बुवाई के लिए मृदा नमी कैसी है?',
            'क्या मुझे आज कीटनाशक छिड़कना चाहिए?',
          ]
        : activePersona === 'commuter'
        ? [
            'मुंबई में शाम को जलभराव कहाँ होगा?',
            'क्या मेट्रो ट्रेन सेवाएं प्रभावित होंगी?',
            'वर्तमान एक्यूआई (AQI) स्तर क्या है?',
          ]
        : [
            'क्या आज समुद्र में जाना सुरक्षित है?',
            'लहरों की ऊंचाई और हवा की गति कितनी है?',
            'हाई टाइड (ज्वार) का समय क्या है?',
          ]
      : activePersona === 'farmer'
      ? [
          'Will it rain in Amritsar today?',
          'Is soil moisture ideal for wheat sowing?',
          'Should I postpone pesticide spray today?',
        ]
      : activePersona === 'commuter'
      ? [
          'Which Mumbai roads will face waterlogging?',
          'How is the 2-hour nowcast for evening commute?',
          'What is the current AQI and humidity?',
        ]
      : [
          'Is it safe for fishing vessels off Kochi?',
          'What are current wave heights and wind knots?',
          'When is the next astronomical high tide?',
        ];

  // Auto scroll
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Voice speech synthesis
  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.rate = 0.95;

    const voices = window.speechSynthesis.getVoices();
    const voice = voices.find(
      (v) =>
        (language === 'hi' && v.lang.includes('hi')) ||
        (language === 'en' && (v.lang === 'en-IN' || v.lang.includes('en')))
    );
    if (voice) utterance.voice = voice;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  // Speech Recognition (Mic capture)
  const toggleListening = () => {
    const SpeechRecognition =
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert(
        language === 'hi'
          ? 'आपका ब्राउज़र वॉयस रिकॉग्निशन सपोर्ट नहीं करता। कृपया टेक्स्ट टाइप करें।'
          : 'Voice speech recognition not supported in this browser. Please type your query.'
      );
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          handleSendMessage(transcript);
        }
      };

      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  const handleSendMessage = async (queryText?: string) => {
    const text = (queryText || inputText).trim();
    if (!text || isLoading) return;

    const userMessage: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/talkback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: text,
          language,
          persona: activePersona,
          location: `${weatherData.location.nameEn}, ${weatherData.location.stateEn}`,
          weatherContext: {
            temp: weatherData.currentTemp,
            condition: weatherData.conditionEn,
            humidity: weatherData.humidity,
            dewPoint: weatherData.dewPoint,
            wind: weatherData.windSpeedKmh,
            aqi: weatherData.aqi.value,
          },
        }),
      });

      const data = await res.json();
      const reply = data.reply || (language === 'hi' ? 'मौसम संबंधित जानकारी प्राप्त हुई।' : 'Weather data retrieved.');

      const assistantMessage: Message = {
        id: `asst-${Date.now()}`,
        sender: 'assistant',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMessage]);
      speakText(reply);
    } catch (err) {
      console.warn('TalkBack request error:', err);
      const fallbackReply =
        language === 'hi'
          ? `मौसम विभाग (IMD) के अनुसार ${weatherData.location.nameHi} में वर्तमान तापमान ${weatherData.currentTemp}°C तथा आर्द्रता ${weatherData.humidity}% है। मौसम अनुकूल रहने की संभावना है।`
          : `According to IMD observations in ${weatherData.location.nameEn}, temperature is ${weatherData.currentTemp}°C with ${weatherData.humidity}% humidity. Forecast remains stable for current operations.`;

      const assistantMessage: Message = {
        id: `asst-${Date.now()}`,
        sender: 'assistant',
        text: fallbackReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMessage]);
      speakText(fallbackReply);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 animate-fade-in">
      <div className="w-full max-w-sm h-[620px] bg-white rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-3 bg-linear-to-r from-amber-600 via-orange-600 to-amber-700 text-white flex items-center justify-between shadow-xs shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-xs">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-xs font-black tracking-wide">
                  {language === 'hi' ? 'मौसम वाणी (Mausam Vani)' : 'Mausam Vani AI'}
                </h3>
                <span className="text-[9px] px-1 py-0.2 rounded bg-white/25 font-bold">
                  Bilingual
                </span>
              </div>
              <p className="text-[10px] text-amber-100 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-ping" />
                {language === 'hi' ? 'अंग्रेजी या हिंदी में सवाल पूछें' : 'Voice & Text Query Assistant'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {/* Language toggle inside talk back */}
            <button
              onClick={() => onLanguageChange(language === 'en' ? 'hi' : 'en')}
              className="px-2 py-1 rounded-md bg-white/20 hover:bg-white/30 text-white text-[10px] font-bold transition-colors"
              title="Change Assistant Language"
            >
              {language === 'en' ? 'हिन्दी में बदलें' : 'Switch to English'}
            </button>

            <button
              onClick={() => {
                if ('speechSynthesis' in window) window.speechSynthesis.cancel();
                onClose();
              }}
              className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Audio Output Wave Animation Bar */}
        {isSpeaking && (
          <div className="bg-amber-100 px-3 py-1.5 flex items-center justify-between border-b border-amber-200 shrink-0 animate-pulse">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
              <Volume2 className="w-4 h-4 text-amber-700 animate-bounce" />
              <span>{language === 'hi' ? 'मौसम वाणी बोल रही है...' : 'Mausam Vani is speaking...'}</span>
            </div>
            <button
              onClick={() => {
                if ('speechSynthesis' in window) window.speechSynthesis.cancel();
                setIsSpeaking(false);
              }}
              className="text-[10px] font-bold text-amber-800 underline"
            >
              {language === 'hi' ? 'म्यूट करें' : 'Stop Audio'}
            </button>
          </div>
        )}

        {/* Chat Messages Log */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5 bg-slate-50/60">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center shrink-0 mt-1 shadow-2xs">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                )}

                <div
                  className={`max-w-[82%] p-2.5 rounded-2xl text-xs leading-relaxed shadow-2xs ${
                    isUser
                      ? 'bg-amber-600 text-white rounded-br-none'
                      : 'bg-white border border-slate-200 text-slate-900 rounded-bl-none'
                  }`}
                >
                  <p>{msg.text}</p>
                  <div className="flex items-center justify-between gap-2 mt-1">
                    <span
                      className={`text-[9px] ${
                        isUser ? 'text-amber-200' : 'text-slate-400'
                      }`}
                    >
                      {msg.timestamp}
                    </span>
                    {!isUser && (
                      <button
                        onClick={() => speakText(msg.text)}
                        className="text-[10px] text-amber-700 hover:text-amber-900 p-0.5"
                        title="Repeat speech"
                      >
                        <Volume2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>

                {isUser && (
                  <div className="w-6 h-6 rounded-full bg-slate-700 text-white flex items-center justify-center shrink-0 mt-1">
                    <User className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center gap-2 text-xs text-slate-500 bg-white p-2.5 rounded-xl border border-slate-200 w-fit">
              <div className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
              <span>{language === 'hi' ? 'मौसम डेटा विश्लेषित किया जा रहा है...' : 'Synthesizing IMD telemetry...'}</span>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Suggested Quick Question Chips */}
        <div className="p-2 border-t border-slate-200 bg-slate-100 shrink-0">
          <div className="text-[10px] font-bold text-slate-500 mb-1 px-1">
            {language === 'hi' ? 'त्वरित प्रश्न चुनें:' : 'Quick Questions:'}
          </div>
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
            {suggestedQuestions.map((q, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(q)}
                className="flex-none px-2.5 py-1 rounded-full bg-white hover:bg-amber-50 text-[10px] font-semibold text-slate-700 hover:text-amber-800 border border-slate-300 shadow-2xs transition-colors whitespace-nowrap"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Input Controls: Mic + Text Box */}
        <div className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0">
          {/* Speech capture button */}
          <button
            id="mic-voice-capture-btn"
            onClick={toggleListening}
            className={`p-2.5 rounded-full transition-all shadow-xs ${
              isListening
                ? 'bg-red-600 text-white animate-pulse ring-4 ring-red-200'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
            title={isListening ? 'Listening... click to stop' : 'Click to Speak (Voice Input)'}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          {/* Text input */}
          <input
            id="talk-back-text-input"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={
              language === 'hi'
                ? 'मौसम संबंधी कोई भी प्रश्न लिखें...'
                : 'Ask any weather query...'
            }
            className="flex-1 px-3 py-2 text-xs rounded-xl bg-slate-100 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"
          />

          {/* Submit button */}
          <button
            id="talk-back-send-btn"
            onClick={() => handleSendMessage()}
            disabled={!inputText.trim() || isLoading}
            className="p-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white transition-all shadow-xs"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
