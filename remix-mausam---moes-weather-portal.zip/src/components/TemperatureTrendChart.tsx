import React, { useState } from 'react';
import {
  TrendingUp,
  Thermometer,
  CloudRain,
  MapPin,
  Calendar,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  Equal,
  Info,
  Check,
  Compass,
} from 'lucide-react';
import { PastDayTemp, AppLanguage, PersonaType, LocationInfo } from '../types';
import { translations } from '../data/translations';

interface TemperatureTrendChartProps {
  data: PastDayTemp[];
  location: LocationInfo;
  persona: PersonaType;
  language: AppLanguage;
  tempUnit?: 'celsius' | 'fahrenheit';
}

// Ensure numbers always remain standard English digits (0-9) even in Hindi mode
const formatDigit = (val: number | string): string => String(val);

export const TemperatureTrendChart: React.FC<TemperatureTrendChartProps> = ({
  data,
  location,
  persona,
  language,
  tempUnit = 'celsius',
}) => {
  const [selectedDayIdx, setSelectedDayIdx] = useState<number>(data.length - 1);
  const [filterMode, setFilterMode] = useState<'both' | 'max' | 'min' | 'departure'>('both');
  const [showNormalBand, setShowNormalBand] = useState<boolean>(true);

  const t = translations[language];
  const safeData = data && data.length > 0 ? data : [];
  const selectedDay = safeData[selectedDayIdx] || safeData[safeData.length - 1] || {
    dayEn: 'Today',
    dayHi: 'आज',
    date: '09/09',
    tempMax: 30,
    tempMin: 22,
    normalMax: 31,
    normalMin: 22,
    departure: -1.0,
    rainfallMm: 5.0,
  };

  // Convert celsius to display unit (always standard English digits)
  const formatT = (celsius: number): string => {
    if (tempUnit === 'fahrenheit') {
      const f = Math.round((celsius * 9) / 5 + 32);
      return `${f}°F`;
    }
    const c = celsius.toFixed(1);
    return `${c}°C`;
  };

  // SVG Chart bounds
  const width = 360;
  const height = 150;
  const paddingX = 26;
  const paddingY = 22;

  // Compute domain
  const allTemps = safeData.flatMap((d) => [d.tempMax, d.tempMin, d.normalMax, d.normalMin]);
  const minTemp = allTemps.length > 0 ? Math.floor(Math.min(...allTemps)) - 1 : 18;
  const maxTemp = allTemps.length > 0 ? Math.ceil(Math.max(...allTemps)) + 1 : 38;

  const getX = (idx: number) => {
    if (safeData.length <= 1) return width / 2;
    return paddingX + (idx / (safeData.length - 1)) * (width - paddingX * 2);
  };

  const getY = (val: number) => {
    return height - paddingY - ((val - minTemp) / (maxTemp - minTemp)) * (height - paddingY * 2);
  };

  // Polyline strings
  const maxPoints = safeData.map((d, i) => `${getX(i)},${getY(d.tempMax)}`).join(' ');
  const minPoints = safeData.map((d, i) => `${getX(i)},${getY(d.tempMin)}`).join(' ');
  const normalMaxPoints = safeData.map((d, i) => `${getX(i)},${getY(d.normalMax)}`).join(' ');
  const normalMinPoints = safeData.map((d, i) => `${getX(i)},${getY(d.normalMin)}`).join(' ');

  // SVG Closed polygon for normal comfort corridor
  const normalBandPoints = [
    ...safeData.map((d, i) => `${getX(i)},${getY(d.normalMax)}`),
    ...safeData
      .slice()
      .reverse()
      .map((d, i) => `${getX(safeData.length - 1 - i)},${getY(d.normalMin)}`),
  ].join(' ');

  // Summary stats
  const avgMax = (safeData.reduce((acc, d) => acc + d.tempMax, 0) / (safeData.length || 1)).toFixed(1);
  const avgMin = (safeData.reduce((acc, d) => acc + d.tempMin, 0) / (safeData.length || 1)).toFixed(1);
  const totalRain = safeData.reduce((acc, d) => acc + (d.rainfallMm || 0), 0).toFixed(1);

  // Classify departure according to IMD standards
  const getDepartureClassification = (dep: number) => {
    if (dep >= 3.0) {
      return {
        labelEn: t.depAppreciablyAbove,
        labelHi: t.depAppreciablyAbove,
        color: 'bg-red-100 text-red-800 border-red-300',
        icon: ArrowUpRight,
      };
    }
    if (dep > 1.5) {
      return {
        labelEn: t.depAbove,
        labelHi: t.depAbove,
        color: 'bg-orange-100 text-orange-800 border-orange-300',
        icon: ArrowUpRight,
      };
    }
    if (dep < -3.0) {
      return {
        labelEn: t.depMarkedlyBelow,
        labelHi: t.depMarkedlyBelow,
        color: 'bg-indigo-100 text-indigo-800 border-indigo-300',
        icon: ArrowDownRight,
      };
    }
    if (dep < -1.5) {
      return {
        labelEn: t.depBelow,
        labelHi: t.depBelow,
        color: 'bg-sky-100 text-sky-800 border-sky-300',
        icon: ArrowDownRight,
      };
    }
    return {
      labelEn: t.depNormal,
      labelHi: t.depNormal,
      color: 'bg-emerald-100 text-emerald-800 border-emerald-300',
      icon: Equal,
    };
  };

  const currentDepClass = getDepartureClassification(selectedDay.departure);
  const DepIcon = currentDepClass.icon;

  // Persona-specific impact summary
  const getPersonaImpact = (d: PastDayTemp) => {
    if (persona === 'farmer') {
      if (d.departure > 1.5) {
        return language === 'hi'
          ? 'उच्च तापीय विचलन: खड़ी फसलों में वाष्पीकरण तीव्र; नमी संरक्षण हेतु सायंकालीन सिंचाई उपयुक्त।'
          : 'High thermal departure: Elevated soil evaporation. Schedule evening irrigation to preserve seed moisture.';
      }
      if (d.rainfallMm > 10) {
        return language === 'hi'
          ? 'वर्षा एवं तापीय गिरावट: रबी बुवाई हेतु पर्याप्त आर्द्रता; जड़ों के विकास हेतु तापमान अनुकूल।'
          : 'Rainfall with temperature drop: Optimal moisture for Rabi seed germination; favorable root corridor.';
      }
      return language === 'hi'
        ? 'सामान्य कृषि तापीय परिस्थितियां: खेत की तैयारी एवं बीजारोपण हेतु आदर्श तापमान श्रेणी।'
        : 'Normal agromet thermal band: Ideal temperature regime for seedbed preparation and crop sowing.';
    }

    if (persona === 'commuter') {
      if (d.departure > 1.5) {
        return language === 'hi'
          ? 'शहरी ताप द्वीप प्रभाव: दोपहर में तीव्र उमस व गर्मी; वातानुकूलित सार्वजनिक परिवहन का उपयोग श्रेयस्कर।'
          : 'Urban Heat Island effect: Moderate heat discomfort during peak noon; AC transit recommended.';
      }
      return language === 'hi'
        ? 'सुहावना शहरी मौसम: मानसूनी हवाओं से रात के तापमान में गिरावट; शाम की यात्रा आरामदायक।'
        : 'Comfortable urban commute: Marine breeze cooling night isotherm; pleasant evening transit.';
    }

    // Traveler / Marine
    return language === 'hi'
      ? 'तटीय व समुद्री तापीय रुझान: समुद्र सतह का तापमान स्थिर; तटीय संवहनी बादलों से शाम को फुहारें संभव।'
      : 'Coastal marine thermal trend: Stable sea-surface interface with convective squall clusters.';
  };

  return (
    <div
      id="temperature-trend-visualization"
      className="mx-3 mt-3 rounded-2xl bg-white border border-slate-200/90 shadow-xs overflow-hidden transition-all"
    >
      {/* Authentic Indian Government Tricolor Accent Top Bar */}
      <div className="h-1.5 w-full flex">
        <div className="flex-1 bg-[#FF9933]" title="Saffron / शौर्य" />
        <div className="flex-1 bg-white relative flex items-center justify-center border-y border-slate-200">
          <div className="w-1.5 h-1.5 rounded-full border border-blue-900" />
        </div>
        <div className="flex-1 bg-[#138808]" title="India Green / समृद्धि" />
      </div>

      <div className="p-3.5">
        {/* Government Meteorological Header & Telemetry Source */}
        <div className="flex items-start justify-between gap-2 mb-2.5">
          <div className="flex items-start gap-2">
            {/* Government Emblem / Thermometer Badge */}
            <div className="w-8 h-8 rounded-xl bg-orange-50 border border-orange-200 text-orange-700 flex items-center justify-center shrink-0 shadow-xs mt-0.5">
              <TrendingUp className="w-4 h-4" />
            </div>

            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="text-xs font-bold text-slate-900 leading-tight">
                  {t.tempTrendTitle}
                </h3>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-orange-100 text-orange-900 border border-orange-200">
                  {t.tempTrendBadge}
                </span>
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5">
                {t.tempTrendSubtitle}
              </p>
              {/* Dynamic Station Location Breadcrumb */}
              <div className="flex items-center gap-1.5 text-[10px] text-slate-600 mt-1 flex-wrap">
                <span className="flex items-center gap-0.5 font-semibold text-slate-800">
                  <MapPin className="w-3 h-3 text-orange-600" />
                  {language === 'hi' ? location.nameHi : location.nameEn}
                </span>
                <span className="text-slate-300">•</span>
                <span className="font-mono text-slate-500 text-[9px] bg-slate-100 px-1 py-0.2 rounded">
                  {location.stationId}
                </span>
                <span className="text-slate-300">•</span>
                <span className="text-slate-500 text-[9px]">
                  {location.elevation}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Departure Pill for selected day */}
          <div
            className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold border shrink-0 shadow-xs ${currentDepClass.color}`}
          >
            <DepIcon className="w-3 h-3" />
            <span>
              {selectedDay.departure > 0 ? `+${selectedDay.departure}` : selectedDay.departure}°C
            </span>
          </div>
        </div>

        {/* View Filter Segmented Controls */}
        <div className="flex items-center justify-between gap-1.5 pt-1 pb-2 border-b border-slate-100 flex-wrap">
          <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-[10px]">
            <button
              onClick={() => setFilterMode('both')}
              className={`px-2 py-0.5 rounded-md font-bold transition-colors ${
                filterMode === 'both'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.tempFilterBoth}
            </button>
            <button
              onClick={() => setFilterMode('max')}
              className={`px-2 py-0.5 rounded-md font-bold transition-colors ${
                filterMode === 'max'
                  ? 'bg-orange-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.tempFilterMax}
            </button>
            <button
              onClick={() => setFilterMode('min')}
              className={`px-2 py-0.5 rounded-md font-bold transition-colors ${
                filterMode === 'min'
                  ? 'bg-blue-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.tempFilterMin}
            </button>
            <button
              onClick={() => setFilterMode('departure')}
              className={`px-2 py-0.5 rounded-md font-bold transition-colors ${
                filterMode === 'departure'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.tempFilterDeparture}
            </button>
          </div>

          {/* Normal Band Visibility Toggle */}
          <button
            onClick={() => setShowNormalBand(!showNormalBand)}
            className={`flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border transition-colors ${
              showNormalBand
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                : 'bg-white text-slate-500 border-slate-200'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
            <span>{t.climaticBand}</span>
          </button>
        </div>

        {/* Dynamic Interactive SVG Chart */}
        <div className="relative overflow-hidden pt-2 pb-1">
          <svg
            viewBox={`0 0 ${width} ${height}`}
            className="w-full h-38 overflow-visible select-none"
            aria-label="7-Day Temperature Trend Chart"
          >
            <defs>
              {/* Saffron / Orange Gradient for Daily Max */}
              <linearGradient id="maxOrangeGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#ea580c" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#ea580c" stopOpacity="0.0" />
              </linearGradient>

              {/* Navy / Blue Gradient for Daily Min */}
              <linearGradient id="minNavyGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#0284c7" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#0284c7" stopOpacity="0.0" />
              </linearGradient>

              {/* Green Shade for Climatic Normal corridor */}
              <pattern id="greenDiagonal" width="6" height="6" patternUnits="userSpaceOnUse">
                <path d="M-1,1 l2,-2 M0,6 l6,-6 M5,7 l2,-2" stroke="#10b981" strokeWidth="0.8" opacity="0.3" />
              </pattern>
            </defs>

            {/* Horizontal Gridlines and Isotherm labels */}
            {[minTemp + 2, Math.round((minTemp + maxTemp) / 2), maxTemp - 2].map((gVal) => {
              const y = getY(gVal);
              return (
                <g key={`grid-${gVal}`}>
                  <line
                    x1={paddingX}
                    y1={y}
                    x2={width - paddingX}
                    y2={y}
                    stroke="#f1f5f9"
                    strokeDasharray="3 3"
                    strokeWidth="1"
                  />
                  <text
                    x={paddingX - 4}
                    y={y + 3}
                    textAnchor="end"
                    className="text-[8px] fill-slate-400 font-mono"
                  >
                    {gVal}°
                  </text>
                </g>
              );
            })}

            {/* Climatological Normal Corridor (India Green band) */}
            {showNormalBand && (
              <polygon
                points={normalBandPoints}
                fill="url(#greenDiagonal)"
                stroke="#15803d"
                strokeWidth="0.8"
                strokeDasharray="3 2"
                opacity="0.8"
              />
            )}

            {/* 30-Year Normal Max Baseline (India Green dashed line) */}
            {showNormalBand && (
              <polyline
                fill="none"
                stroke="#15803d"
                strokeDasharray="4 3"
                strokeWidth="1.2"
                points={normalMaxPoints}
              />
            )}

            {/* Max Temperature Line & Gradient (Bhagwa / Saffron #ea580c) */}
            {(filterMode === 'both' || filterMode === 'max') && (
              <>
                <polygon
                  fill="url(#maxOrangeGrad)"
                  points={`${getX(0)},${height - paddingY} ${maxPoints} ${getX(
                    safeData.length - 1
                  )},${height - paddingY}`}
                />
                <polyline
                  fill="none"
                  stroke="#ea580c"
                  strokeWidth="2.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={maxPoints}
                />
              </>
            )}

            {/* Min Temperature Line & Gradient (Ashoka Navy / Sky #0284c7) */}
            {(filterMode === 'both' || filterMode === 'min') && (
              <>
                <polygon
                  fill="url(#minNavyGrad)"
                  points={`${getX(0)},${height - paddingY} ${minPoints} ${getX(
                    safeData.length - 1
                  )},${height - paddingY}`}
                />
                <polyline
                  fill="none"
                  stroke="#0284c7"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={minPoints}
                />
              </>
            )}

            {/* Interactive Day Vertical Scrubber Columns & Interactive Nodes */}
            {safeData.map((d, i) => {
              const x = getX(i);
              const yMax = getY(d.tempMax);
              const yMin = getY(d.tempMin);
              const yNormalMax = getY(d.normalMax);
              const isSelected = i === selectedDayIdx;

              return (
                <g
                  key={`day-col-${d.date}`}
                  className="cursor-pointer group"
                  onClick={() => setSelectedDayIdx(i)}
                >
                  {/* Invisible wide click target */}
                  <rect
                    x={x - 18}
                    y={paddingY}
                    width={36}
                    height={height - paddingY}
                    fill="transparent"
                  />

                  {/* Vertical Guideline */}
                  {isSelected && (
                    <line
                      x1={x}
                      y1={paddingY}
                      x2={x}
                      y2={height - paddingY}
                      stroke="#ea580c"
                      strokeWidth="1.6"
                      strokeDasharray="3 2"
                      opacity="0.8"
                    />
                  )}

                  {/* Rain Bar at bottom if rain occurred */}
                  {d.rainfallMm > 0 && (
                    <rect
                      x={x - 3.5}
                      y={height - paddingY - Math.min(22, d.rainfallMm * 0.8)}
                      width={7}
                      height={Math.min(22, d.rainfallMm * 0.8)}
                      rx={2}
                      className="fill-sky-400/60"
                      title={`${d.rainfallMm} mm rain`}
                    />
                  )}

                  {/* Normal baseline anchor node */}
                  {showNormalBand && (
                    <circle
                      cx={x}
                      cy={yNormalMax}
                      r={1.8}
                      className="fill-emerald-600"
                    />
                  )}

                  {/* Max Temp Dot (Saffron Orange) */}
                  {(filterMode === 'both' || filterMode === 'max') && (
                    <circle
                      cx={x}
                      cy={yMax}
                      r={isSelected ? 5.5 : 3.5}
                      className={`transition-all ${
                        isSelected
                          ? 'fill-orange-600 stroke-white stroke-2 drop-shadow-md'
                          : 'fill-orange-500 hover:fill-orange-600'
                      }`}
                    />
                  )}

                  {/* Min Temp Dot (Navy Sky) */}
                  {(filterMode === 'both' || filterMode === 'min') && (
                    <circle
                      cx={x}
                      cy={yMin}
                      r={isSelected ? 4.8 : 3}
                      className={`transition-all ${
                        isSelected
                          ? 'fill-sky-700 stroke-white stroke-2 drop-shadow-md'
                          : 'fill-sky-500 hover:fill-sky-600'
                      }`}
                    />
                  )}

                  {/* Departure indicator bubble in departure mode */}
                  {filterMode === 'departure' && (
                    <g>
                      <circle
                        cx={x}
                        cy={(yMax + yNormalMax) / 2}
                        r={isSelected ? 8 : 6}
                        className={
                          d.departure > 0
                            ? 'fill-red-500 stroke-white stroke-1'
                            : 'fill-blue-500 stroke-white stroke-1'
                        }
                      />
                      <text
                        x={x}
                        y={(yMax + yNormalMax) / 2 + 3}
                        textAnchor="middle"
                        className="text-[7px] font-black fill-white"
                      >
                        {d.departure > 0 ? `+${Math.round(d.departure)}` : Math.round(d.departure)}
                      </text>
                    </g>
                  )}

                  {/* Temperature label above node when selected */}
                  {isSelected && (filterMode === 'both' || filterMode === 'max') && (
                    <text
                      x={x}
                      y={yMax - 8}
                      textAnchor="middle"
                      className="text-[9px] font-black fill-orange-700 font-mono"
                    >
                      {d.tempMax}°
                    </text>
                  )}

                  {/* X-Axis Date Label */}
                  <text
                    x={x}
                    y={height - 4}
                    textAnchor="middle"
                    className={`text-[9px] font-bold transition-colors ${
                      isSelected
                        ? 'fill-orange-700 font-extrabold scale-110'
                        : 'fill-slate-500'
                    }`}
                  >
                    {language === 'hi' ? d.dayHi : d.dayEn}
                  </text>
                </g>
              );
            })}
          </svg>

          {/* Meteorological Legend with Government Palette */}
          <div className="flex items-center justify-between mt-1 text-[9px] text-slate-500 font-medium px-1 flex-wrap gap-2">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-1 rounded-full bg-orange-600" />
                <span>{t.dailyMax}</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-1 rounded-full bg-sky-600" />
                <span>{t.dailyMin}</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-0.5 border-b border-dashed border-emerald-600" />
                <span>{t.climaticNormal}</span>
              </div>
            </div>

            <div className="text-[9px] text-slate-400 italic">
              {t.tapToInspect}
            </div>
          </div>
        </div>

        {/* Detailed Selected Day Inspection Card */}
        <div className="mt-3 p-3 rounded-2xl bg-orange-50/70 border border-orange-200/90 shadow-2xs space-y-2">
          {/* Day Date and Departure Summary */}
          <div className="flex items-start justify-between gap-2 border-b border-orange-200/60 pb-2">
            <div>
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-orange-700" />
                <span className="font-bold text-slate-900 text-xs">
                  {language === 'hi' ? selectedDay.dayHi : selectedDay.dayEn} ({selectedDay.date})
                </span>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full font-bold bg-white text-slate-700 border border-orange-200">
                  {location.nameEn} AWS
                </span>
              </div>

              {/* Temperatures Row */}
              <div className="text-xs text-slate-700 mt-1 flex items-center gap-2 flex-wrap">
                <span className="font-bold text-orange-700">
                  Max: {formatT(selectedDay.tempMax)}
                </span>
                <span className="text-slate-300">|</span>
                <span className="font-bold text-sky-700">
                  Min: {formatT(selectedDay.tempMin)}
                </span>
                <span className="text-slate-300">|</span>
                <span className="text-slate-500 text-[11px]">
                  {t.climaticNormal}: {formatT(selectedDay.normalMax)}
                </span>
              </div>
            </div>

            {/* Departure Flag */}
            <div className="text-right shrink-0">
              <div className="text-[9px] text-slate-500 font-semibold">
                {t.departureFromNormal}
              </div>
              <div
                className={`text-xs font-black ${
                  selectedDay.departure > 0 ? 'text-red-700' : 'text-blue-700'
                }`}
              >
                {selectedDay.departure > 0 ? `+${selectedDay.departure}` : selectedDay.departure}°C
              </div>
              <div className="text-[9px] text-slate-500 mt-0.5">
                {language === 'hi' ? currentDepClass.labelHi : currentDepClass.labelEn}
              </div>
            </div>
          </div>

          {/* Rainfall & Persona Operational Assessment */}
          <div className="pt-0.5 text-xs text-slate-700 space-y-1">
            {selectedDay.rainfallMm > 0 && (
              <div className="flex items-center gap-1.5 text-sky-800 font-semibold text-[11px]">
                <CloudRain className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                <span>
                  {t.recordedRainfall} {selectedDay.rainfallMm} mm
                </span>
              </div>
            )}

            <p className="text-[11px] text-slate-600 leading-relaxed bg-white/80 p-2 rounded-xl border border-orange-100">
              <strong className="text-slate-800 block mb-0.5">
                {language === 'hi' ? 'मौसम विज्ञान विश्लेषण एवं प्रभाव:' : 'IMD Operational Assessment:'}
              </strong>
              {getPersonaImpact(selectedDay)}
            </p>
          </div>
        </div>

        {/* 7-Day Weekly Summary Bar */}
        <div className="mt-2.5 grid grid-cols-4 gap-1.5 text-center bg-slate-50 p-2 rounded-xl border border-slate-200/80">
          <div>
            <span className="block text-[9px] text-slate-400 font-medium">
              {language === 'hi' ? 'औसत अधि.' : 'Avg Max'}
            </span>
            <span className="text-xs font-bold text-orange-700 font-mono">
              {avgMax}°
            </span>
          </div>

          <div>
            <span className="block text-[9px] text-slate-400 font-medium">
              {language === 'hi' ? 'औसत न्यून.' : 'Avg Min'}
            </span>
            <span className="text-xs font-bold text-sky-700 font-mono">
              {avgMin}°
            </span>
          </div>

          <div>
            <span className="block text-[9px] text-slate-400 font-medium">
              {language === 'hi' ? 'सप्ताह वर्षा' : 'Total Rain'}
            </span>
            <span className="text-xs font-bold text-blue-700 font-mono">
              {totalRain} mm
            </span>
          </div>

          <div>
            <span className="block text-[9px] text-slate-400 font-medium">
              {language === 'hi' ? 'चरम विचलन' : 'Peak Dep.'}
            </span>
            <span className="text-xs font-bold text-slate-800 font-mono">
              {safeData.length > 0
                ? `${Math.max(...safeData.map((d) => Math.abs(d.departure))).toFixed(1)}°`
                : '0°'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
