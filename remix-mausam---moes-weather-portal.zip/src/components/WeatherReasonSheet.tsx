import React from 'react';
import { X, Info, CloudRain, Droplets, Thermometer, Eye, Radio, CheckCircle2 } from 'lucide-react';

interface WeatherReasonSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  context?: string;
  data?: {
    rainProbability?: number | string;
    visibility?: string;
    humidity?: number | string;
    temperature?: number | string;
    source?: string;
    lastUpdated?: string;
    factors?: string[];
  };
}

export default function WeatherReasonSheet({
  isOpen,
  onClose,
  title = 'Why are we suggesting this?',
  context = 'Rain overlaps with your scheduled commute between 8:30 AM and 9:20 AM.',
  data = {
    rainProbability: '78%',
    visibility: 'Moderate (7.0 km)',
    humidity: '82%',
    temperature: '29°C',
    source: 'IMD AWS Hindon & Safdarjung Radar Network',
    lastUpdated: '6 minutes ago',
    factors: [
      'Convective monsoon cloud formation detected 14 km southwest',
      'Wind speed accelerating to 18 km/h with sudden dew point elevation',
      'Historical 10-year probability for this time window: 65%',
    ],
  },
}: WeatherReasonSheetProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      {/* Backdrop tap to close */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Sheet Modal */}
      <div className="relative w-full max-w-md bg-white rounded-t-[32px] sm:rounded-3xl p-6 shadow-2xl border border-slate-100 flex flex-col z-10 animate-in slide-in-from-bottom-6 duration-250">
        {/* Handle bar */}
        <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto mb-4" />

        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-[#1A4FA0] flex items-center justify-center font-bold">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 leading-snug">
                {title}
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Transparent meteorological reasoning
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Context Summary Banner */}
        <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-100 text-xs text-slate-700 leading-relaxed mb-4">
          <span className="font-bold text-blue-900 block mb-0.5">Primary Observation:</span>
          {context}
        </div>

        {/* Telemetry Metrics Grid */}
        <div className="grid grid-cols-2 gap-2.5 mb-4">
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70">
            <div className="flex items-center gap-1.5 text-slate-500 text-[11px] font-semibold mb-1">
              <CloudRain className="w-3.5 h-3.5 text-blue-600" />
              Rain Probability
            </div>
            <div className="text-base font-black text-slate-900">
              {data.rainProbability || '78%'}
            </div>
            <span className="text-[10px] text-amber-700 font-bold">High likelihood</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70">
            <div className="flex items-center gap-1.5 text-slate-500 text-[11px] font-semibold mb-1">
              <Eye className="w-3.5 h-3.5 text-indigo-600" />
              Visibility
            </div>
            <div className="text-base font-black text-slate-900">
              {data.visibility || 'Moderate'}
            </div>
            <span className="text-[10px] text-slate-500 font-medium">Safe driving speed</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70">
            <div className="flex items-center gap-1.5 text-slate-500 text-[11px] font-semibold mb-1">
              <Droplets className="w-3.5 h-3.5 text-cyan-600" />
              Humidity
            </div>
            <div className="text-base font-black text-slate-900">
              {data.humidity || '82%'}
            </div>
            <span className="text-[10px] text-slate-500 font-medium">High moisture saturation</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70">
            <div className="flex items-center gap-1.5 text-slate-500 text-[11px] font-semibold mb-1">
              <Thermometer className="w-3.5 h-3.5 text-amber-600" />
              Temperature
            </div>
            <div className="text-base font-black text-slate-900">
              {data.temperature || '29°C'}
            </div>
            <span className="text-[10px] text-slate-500 font-medium">Feels like 31°C</span>
          </div>
        </div>

        {/* Contributing factors */}
        {data.factors && data.factors.length > 0 && (
          <div className="mb-4 space-y-1.5">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Key Contributing Factors
            </span>
            {data.factors.map((f, i) => (
              <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                <span>{f}</span>
              </div>
            ))}
          </div>
        )}

        {/* Source & Last Updated Metadata */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 mb-4">
          <div className="flex items-center gap-1.5 truncate max-w-[210px]">
            <Radio className="w-3 h-3 text-emerald-600 shrink-0 animate-pulse" />
            <span className="truncate font-medium">
              Source: <strong className="text-slate-700">{data.source || 'IMD'}</strong>
            </span>
          </div>
          <span className="font-semibold text-slate-600">
            Updated {data.lastUpdated || '6 minutes ago'}
          </span>
        </div>

        {/* Dismiss CTA button */}
        <button
          onClick={onClose}
          className="w-full py-3.5 rounded-2xl bg-[#1A4FA0] hover:bg-[#15438E] text-white text-sm font-bold shadow-md transition-all active:scale-[0.99]"
        >
          Got It, Thanks
        </button>
      </div>
    </div>
  );
}
