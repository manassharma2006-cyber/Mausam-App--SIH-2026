import React, { createContext, useContext, useState, useEffect } from 'react';
import type { PersonaType, AppLanguage, LocationInfo, PersonaWeatherData } from '../types';
import { personaWeatherMap, getWeatherDataFor } from '../data/mockWeatherData';
import { majorIndianCities } from '../data/indianLocations';
import { fetchLiveWeatherByQuery } from '../services/liveWeatherService';

export interface UserProfile {
  name: string;
  phone: string;
  city: string;
  interests: string[];
  morningAlert: string;
  eveningAlert: string;
  notificationsEnabled: boolean;
  severeAlertsEnabled: boolean;
  lightningAlertsEnabled: boolean;
}

interface WeatherContextType {
  weatherData: PersonaWeatherData;
  setWeatherData: React.Dispatch<React.SetStateAction<PersonaWeatherData>>;
  activePersona: PersonaType;
  setActivePersona: (p: PersonaType) => void;
  language: AppLanguage;
  setLanguage: (l: AppLanguage) => void;
  tempUnit: 'celsius' | 'fahrenheit';
  setTempUnit: (u: 'celsius' | 'fahrenheit') => void;
  userProfile: UserProfile;
  updateUserProfile: (u: Partial<UserProfile>) => void;
  savedLocations: LocationInfo[];
  toggleSaveLocation: (loc: LocationInfo) => void;
  switchLocation: (loc: LocationInfo, persona?: PersonaType) => Promise<void>;
  isLiveLoading: boolean;
  formatTemp: (celsius: number) => string;
  speakText: (text: string) => void;
  isSpeaking: boolean;
  stopSpeaking: () => void;
  refreshWeather: () => Promise<void>;
}

const defaultProfile: UserProfile = {
  name: 'राजेश कुमार',
  phone: '+91 98765 43210',
  city: 'Amritsar',
  interests: ['commute', 'agriculture', 'storm-alerts'],
  morningAlert: '07:00 AM',
  eveningAlert: '06:30 PM',
  notificationsEnabled: true,
  severeAlertsEnabled: true,
  lightningAlertsEnabled: true,
};

const WeatherContext = createContext<WeatherContextType | undefined>(undefined);

export const WeatherProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activePersona, setActivePersona] = useState<PersonaType>('farmer');
  const [language, setLanguage] = useState<AppLanguage>('en');
  const [tempUnit, setTempUnit] = useState<'celsius' | 'fahrenheit'>('celsius');
  const [userProfile, setUserProfile] = useState<UserProfile>(defaultProfile);
  const [weatherData, setWeatherData] = useState<PersonaWeatherData>(personaWeatherMap[activePersona]);
  const [isLiveLoading, setIsLiveLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Initial saved cities
  const [savedLocations, setSavedLocations] = useState<LocationInfo[]>([
    majorIndianCities[0], // Amritsar
    majorIndianCities[1], // New Delhi
    majorIndianCities[2], // Mumbai
    majorIndianCities[4], // Bengaluru
  ]);

  // Load weather initially
  useEffect(() => {
    let isMounted = true;
    setIsLiveLoading(true);
    fetchLiveWeatherByQuery(userProfile.city || 'Amritsar', activePersona, language)
      .then((live) => {
        if (isMounted && live) {
          setWeatherData(live);
        }
      })
      .catch((err) => {
        console.warn('Initial weather load fallback:', err);
      })
      .finally(() => {
        if (isMounted) setIsLiveLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  // Sync on persona change
  useEffect(() => {
    const cityName = weatherData?.location?.nameEn || userProfile.city || 'Amritsar';
    setIsLiveLoading(true);
    fetchLiveWeatherByQuery(cityName, activePersona, language)
      .then((live) => {
        if (live) setWeatherData(live);
      })
      .catch(() => {
        setWeatherData((prev) => getWeatherDataFor(activePersona, prev?.location?.stationId));
      })
      .finally(() => setIsLiveLoading(false));
  }, [activePersona]);

  const switchLocation = async (loc: LocationInfo, personaOverride?: PersonaType) => {
    const targetPersona = personaOverride || activePersona;
    setIsLiveLoading(true);
    setUserProfile((prev) => ({ ...prev, city: loc.nameEn }));
    try {
      const live = await fetchLiveWeatherByQuery(loc.nameEn, targetPersona, language);
      setWeatherData(live);
    } catch {
      const mock = getWeatherDataFor(targetPersona, loc.stationId);
      setWeatherData(mock);
    } finally {
      setIsLiveLoading(false);
    }
  };

  const refreshWeather = async () => {
    const cityName = weatherData?.location?.nameEn || userProfile.city || 'Amritsar';
    setIsLiveLoading(true);
    try {
      const live = await fetchLiveWeatherByQuery(cityName, activePersona, language);
      setWeatherData(live);
    } catch (err) {
      console.warn('Refresh error:', err);
    } finally {
      setIsLiveLoading(false);
    }
  };

  const toggleSaveLocation = (loc: LocationInfo) => {
    setSavedLocations((prev) => {
      const exists = prev.some((l) => l.nameEn === loc.nameEn);
      if (exists) {
        return prev.filter((l) => l.nameEn !== loc.nameEn);
      } else {
        return [...prev, loc];
      }
    });
  };

  const updateUserProfile = (patch: Partial<UserProfile>) => {
    setUserProfile((prev) => ({ ...prev, ...patch }));
  };

  const formatTemp = (celsius: number) => {
    if (tempUnit === 'fahrenheit') {
      return `${Math.round((celsius * 9) / 5 + 32)}°F`;
    }
    return `${Math.round(celsius)}°C`;
  };

  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*_#`~]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.rate = 0.95;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  return (
    <WeatherContext.Provider
      value={{
        weatherData,
        setWeatherData,
        activePersona,
        setActivePersona,
        language,
        setLanguage,
        tempUnit,
        setTempUnit,
        userProfile,
        updateUserProfile,
        savedLocations,
        toggleSaveLocation,
        switchLocation,
        isLiveLoading,
        formatTemp,
        speakText,
        isSpeaking,
        stopSpeaking,
        refreshWeather,
      }}
    >
      {children}
    </WeatherContext.Provider>
  );
};

export const useWeather = () => {
  const context = useContext(WeatherContext);
  if (!context) {
    throw new Error('useWeather must be used within a WeatherProvider');
  }
  return context;
};
