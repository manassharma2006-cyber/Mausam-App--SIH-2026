import React from 'react';
import {
  Activity,
  Wind,
  Sun,
  Thermometer,
  CloudRain,
  Eye,
  Droplets,
  Sparkles,
  Compass,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowRight,
  ShieldCheck,
  Plane,
  AlertTriangle,
  Clock,
  Car,
} from 'lucide-react';

export type InterestId =
  | 'fitness'
  | 'health'
  | 'commute'
  | 'family'
  | 'travel'
  | 'beach'
  | 'farming'
  | 'events';

export interface PersonaQuickCard {
  id: string;
  category: string;
  metric: string;
  sub: string;
  badge: string;
  badgeColor: string; // e.g. bg-emerald-50 text-emerald-800
  icon: typeof Activity;
  iconBg: string;
  iconColor: string;
  route?: string;
}

export interface PersonaTimelineItem {
  time: string;
  title: string;
  sub: string;
  status: 'safe' | 'caution' | 'warning';
  icon: typeof Activity;
  badge: string;
}

export interface PersonaDashboardConfig {
  id: InterestId;
  label: string;
  emoji: string;
  heroInsight: {
    badge: string;
    title: string;
    subtitle: string;
    secondaryNote?: string;
    icon: typeof CloudRain;
    iconBg: string;
    iconColor: string;
    actionLabel: string;
    whyContext: string;
    whyFactors: string[];
    advisoryHeadline: string;
    advisoryItems: { title: string; desc: string; iconType: 'emerald' | 'blue' | 'indigo' | 'amber' }[];
  };
  quickCards: PersonaQuickCard[];
  timelineItems: PersonaTimelineItem[];
  hourlyHighlight: {
    time: string;
    label: string;
    icon: string;
  };
  specialBanner?: {
    type: 'travel' | 'farming' | 'health' | 'family';
    title: string;
    subtitle: string;
    badge: string;
    actionLabel: string;
    route?: string;
  };
}

export const ALL_PERSONA_CONFIGS: Record<InterestId, PersonaDashboardConfig> = {
  fitness: {
    id: 'fitness',
    label: 'Fitness & Running',
    emoji: '🏃',
    heroInsight: {
      badge: 'Best Run Window',
      title: '🏃 Best run: 6:00–6:50 AM',
      subtitle: 'Lower heat (23°C), comfortable humidity and low rain risk (8%). Safe aerobic conditions before solar radiation builds up.',
      icon: Activity,
      iconBg: 'bg-emerald-600',
      iconColor: 'text-white',
      actionLabel: 'Workout Guidance',
      whyContext: 'Morning boundary layer temperature remains at 23°C with 8% precipitation probability until 7:15 AM.',
      whyFactors: [
        'Surface temperature stays 8°C below daily maximum (33°C)',
        'Wet Bulb Globe Temperature (WBGT) index indicates low heat exhaustion hazard',
        'Morning solar UV is < 1.0; no sunburn risk during this session',
        'Wind speed at 9 km/h provides natural convective cooling',
      ],
      advisoryHeadline: 'Optimal Workout Recommendations',
      advisoryItems: [
        {
          title: 'Hydrate 300ml prior to warm-up',
          desc: 'High ambient humidity (82%) slows evaporative cooling during sprint intervals.',
          iconType: 'blue',
        },
        {
          title: 'Complete cooldown by 7:15 AM',
          desc: 'Particulate matter and traffic exhaust increase on main roads after 7:30 AM.',
          iconType: 'emerald',
        },
        {
          title: 'Wear light, breathable technical fabric',
          desc: 'Dew point of 21°C favors loose, moisture-wicking gear.',
          iconType: 'indigo',
        },
      ],
    },
    quickCards: [
      {
        id: 'run-window',
        category: 'Best Workout Window',
        metric: '6:00–6:50 AM',
        sub: 'Optimal 23°C • Low UV',
        badge: 'Prime Window',
        badgeColor: 'bg-emerald-50 text-emerald-800',
        icon: Activity,
        iconBg: 'bg-emerald-50',
        iconColor: 'text-emerald-600',
        route: 'best-window',
      },
      {
        id: 'run-aqi',
        category: 'Running Air Quality',
        metric: 'AQI 128',
        sub: 'Safe for steady aerobic pace',
        badge: 'Safe Pace',
        badgeColor: 'bg-blue-50 text-blue-800',
        icon: Wind,
        iconBg: 'bg-blue-50',
        iconColor: 'text-blue-600',
        route: 'air-quality',
      },
      {
        id: 'heat-stress',
        category: 'Thermal Comfort',
        metric: 'Low Heat Stress',
        sub: 'Dew point 21°C • Hydrate well',
        badge: 'Comfortable',
        badgeColor: 'bg-teal-50 text-teal-800',
        icon: Thermometer,
        iconBg: 'bg-teal-50',
        iconColor: 'text-teal-600',
      },
      {
        id: 'solar-uv',
        category: 'Solar UV Radiation',
        metric: 'UV 1 at 6 AM',
        sub: 'Rises to UV 7.2 by noon',
        badge: 'Low Solar',
        badgeColor: 'bg-amber-50 text-amber-800',
        icon: Sun,
        iconBg: 'bg-amber-50',
        iconColor: 'text-amber-600',
      },
    ],
    timelineItems: [
      {
        time: '6:00 AM',
        title: 'Prime Running Window',
        sub: '23°C, clean air, low UV, 8% rain probability • Optimal 5k pace',
        status: 'safe',
        icon: Activity,
        badge: 'Recommended',
      },
      {
        time: '8:30 AM',
        title: 'Indoor Cool-down & Core',
        sub: 'Light rain arrives (78% chance) • Move routines indoors',
        status: 'caution',
        icon: CloudRain,
        badge: 'Indoor Only',
      },
      {
        time: '1:00 PM',
        title: 'High Heat / UV Caution',
        sub: 'Peak 33°C with UV Index 7.2 • High dehydration risk',
        status: 'warning',
        icon: Sun,
        badge: 'Avoid Running',
      },
      {
        time: '6:15 PM',
        title: 'Secondary Jog / Walk Window',
        sub: '27°C with cool eastern breeze • Safe post-sunset recovery run',
        status: 'safe',
        icon: Activity,
        badge: 'Good Window',
      },
    ],
    hourlyHighlight: {
      time: '6 AM',
      label: '🏃 Run',
      icon: '🏃',
    },
  },

  health: {
    id: 'health',
    label: 'Health & Air Quality',
    emoji: '😷',
    heroInsight: {
      badge: 'Air Quality & Health',
      title: '😷 Outdoor conditions need attention today',
      subtitle: 'Elevated particulate inversion in early morning (PM2.5: 68 µg/m³). Cleanest atmospheric dispersion window is 10:30 AM to 1:00 PM.',
      icon: Wind,
      iconBg: 'bg-emerald-600',
      iconColor: 'text-white',
      actionLabel: 'Health Advisory',
      whyContext: 'Low nocturnal planetary boundary layer height (420m) trapped fine particulates overnight.',
      whyFactors: [
        'Ground-level inversion traps PM2.5 until solar surface heating initiates thermals',
        'Relative humidity of 82% increases hygroscopic growth of aerosol particles',
        'After 10:30 AM, solar convective mixing disperses pollutants upward',
        'Pollen counts remain low-moderate across central NCR stations',
      ],
      advisoryHeadline: 'Environmental Health Guidance',
      advisoryItems: [
        {
          title: 'Sensitive groups: wear N95 outdoors before 9:30 AM',
          desc: 'Fine particulate concentration is 4.5x WHO recommended guideline.',
          iconType: 'emerald',
        },
        {
          title: 'Plan outdoor exercise between 10:30 AM and 12:30 PM',
          desc: 'Optimal atmospheric mixing lowers ground-level respiratory irritation.',
          iconType: 'blue',
        },
        {
          title: 'High midday UV protection (12 PM - 2:30 PM)',
          desc: 'UV Index reaches 7.2; apply SPF 30+ if staying in direct sun over 20 mins.',
          iconType: 'amber',
        },
      ],
    },
    quickCards: [
      {
        id: 'aqi-breakdown',
        category: 'Air Quality Index',
        metric: 'AQI 128 Moderate',
        sub: 'PM2.5: 68 • PM10: 112 µg/m³',
        badge: 'Sensitives Mask',
        badgeColor: 'bg-emerald-50 text-emerald-800',
        icon: Wind,
        iconBg: 'bg-emerald-50',
        iconColor: 'text-emerald-600',
        route: 'air-quality',
      },
      {
        id: 'pollen-index',
        category: 'Pollen & Allergens',
        metric: 'Low-Mod Risk',
        sub: 'Tree pollen 14 • Grass 8 gr/m³',
        badge: 'Allergen Low',
        badgeColor: 'bg-teal-50 text-teal-800',
        icon: Sparkles,
        iconBg: 'bg-teal-50',
        iconColor: 'text-teal-600',
      },
      {
        id: 'uv-solar',
        category: 'UV Radiation Index',
        metric: 'UV 7.2 Very High',
        sub: 'Peak solar 12:15–2:30 PM',
        badge: 'UV Caution',
        badgeColor: 'bg-amber-50 text-amber-800',
        icon: Sun,
        iconBg: 'bg-amber-50',
        iconColor: 'text-amber-600',
      },
      {
        id: 'clean-window',
        category: 'Cleanest Air Window',
        metric: '10:30 AM–12:30 PM',
        sub: 'Best atmospheric dispersion',
        badge: 'Best Air',
        badgeColor: 'bg-blue-50 text-blue-800',
        icon: Activity,
        iconBg: 'bg-blue-50',
        iconColor: 'text-blue-600',
        route: 'best-window',
      },
    ],
    timelineItems: [
      {
        time: '7:00 AM',
        title: 'Morning Inversion Alert',
        sub: 'Particulates concentrated near ground • Sensitive individuals stay indoors',
        status: 'caution',
        icon: Wind,
        badge: 'Inversion',
      },
      {
        time: '10:30 AM',
        title: 'Optimal Fresh Air Window',
        sub: 'Convective mixing disperses PM2.5 • Cleanest window for outdoor chores',
        status: 'safe',
        icon: Activity,
        badge: 'Cleanest Air',
      },
      {
        time: '1:00 PM',
        title: 'High Solar UV Peak',
        sub: 'UV Index 7.2 • High erythemal dose; seek shade and wear sunglasses',
        status: 'warning',
        icon: Sun,
        badge: 'UV 7.2',
      },
      {
        time: '7:00 PM',
        title: 'Evening Particulate Advisory',
        sub: 'Cooling ground layer triggers gradual re-accumulation of particulates',
        status: 'caution',
        icon: Wind,
        badge: 'Monitor AQI',
      },
    ],
    hourlyHighlight: {
      time: '11 AM',
      label: '🍃 Clean Air',
      icon: '🍃',
    },
    specialBanner: {
      type: 'health',
      title: 'Respiratory Protection Advisory',
      subtitle: 'PM2.5 elevated until 9:30 AM. Seniors and asthma patients advised to use air purification or reschedule morning stroll.',
      badge: 'Health Guard',
      actionLabel: 'View Detailed AQI',
      route: 'air-quality',
    },
  },

  commute: {
    id: 'commute',
    label: 'Daily Commute',
    emoji: '💼',
    heroInsight: {
      badge: 'Commute Risk',
      title: '☔ Rain overlaps with your morning commute',
      subtitle: 'Light to moderate rain is expected around 8:30–9:20 AM along your route from Vasundhara to Cyber City Gurugram.',
      icon: CloudRain,
      iconBg: 'bg-blue-600',
      iconColor: 'text-white',
      actionLabel: 'Commute Advice',
      whyContext: 'Doppler Radar Safdarjung detects a convective cloud band moving northeast from Haryana border.',
      whyFactors: [
        'Rain probability spikes to 78% between 8:30 AM and 9:20 AM',
        'Arterial link roads risk 10-15 min delays due to slick surface conditions',
        'Visibility dips from 7.0 km to 3.5 km during peak convective burst',
        'Evening return journey (after 5:30 PM) is forecast to be completely dry (15% rain risk)',
      ],
      advisoryHeadline: 'Smart Departure Recommendations',
      advisoryItems: [
        {
          title: 'Depart 15 minutes early (by 8:15 AM)',
          desc: 'Avoid peak congestion when the shower begins around 8:35 AM.',
          iconType: 'emerald',
        },
        {
          title: 'Prefer Delhi-Meerut Expressway & NH-48',
          desc: 'Better stormwater drainage and lower waterlogging risk than old link roads.',
          iconType: 'blue',
        },
        {
          title: 'Keep umbrella and rain cover ready',
          desc: 'Intermittent drizzle expected when parking and walking to office lobby.',
          iconType: 'indigo',
        },
      ],
    },
    quickCards: [
      {
        id: 'morning-departure',
        category: 'Morning Departure Window',
        metric: 'Leave by 8:15 AM',
        sub: 'Beat convective shower window',
        badge: 'Leave Early',
        badgeColor: 'bg-amber-50 text-amber-800',
        icon: Car,
        iconBg: 'bg-blue-50',
        iconColor: 'text-blue-600',
        route: 'commute',
      },
      {
        id: 'route-visibility',
        category: 'Route Visibility & Fog',
        metric: '7.0 km Good',
        sub: 'Clear sightlines on expressways',
        badge: 'No Fog',
        badgeColor: 'bg-emerald-50 text-emerald-800',
        icon: Eye,
        iconBg: 'bg-emerald-50',
        iconColor: 'text-emerald-600',
      },
      {
        id: 'evening-commute',
        category: 'Evening Return Window',
        metric: '6:00 PM Dry',
        sub: '27°C, clear highway conditions',
        badge: 'Smooth Run',
        badgeColor: 'bg-teal-50 text-teal-800',
        icon: Car,
        iconBg: 'bg-teal-50',
        iconColor: 'text-teal-600',
      },
      {
        id: 'waterlogging-risk',
        category: 'Waterlogging Vulnerability',
        metric: 'Low on NH-48 / DME',
        sub: 'Underpasses clear, normal flow',
        badge: 'Expressway Best',
        badgeColor: 'bg-indigo-50 text-indigo-800',
        icon: Droplets,
        iconBg: 'bg-indigo-50',
        iconColor: 'text-indigo-600',
      },
    ],
    timelineItems: [
      {
        time: '8:15 AM',
        title: 'Recommended Departure Window',
        sub: 'Dry asphalt, smooth traffic flow • Depart before approaching drizzle',
        status: 'safe',
        icon: Car,
        badge: 'Optimal',
      },
      {
        time: '8:45 AM',
        title: 'Rain Overlap on Route',
        sub: 'Light to moderate shower (78% probability) • Carry umbrella & drive safe',
        status: 'caution',
        icon: CloudRain,
        badge: 'Rain Alert',
      },
      {
        time: '1:00 PM',
        title: 'Midday Office Transit',
        sub: 'Warm 33°C, overcast skies • AC shuttle or indoor walkways recommended',
        status: 'safe',
        icon: Sun,
        badge: 'Warm',
      },
      {
        time: '6:00 PM',
        title: 'Evening Return Journey',
        sub: '27°C with clear skies • Fast commute back to Vasundhara',
        status: 'safe',
        icon: Car,
        badge: 'Clear Highway',
      },
    ],
    hourlyHighlight: {
      time: '9 AM',
      label: '🌧️ Commute',
      icon: '🌧️',
    },
  },

  family: {
    id: 'family',
    label: 'Family & School',
    emoji: '🎒',
    heroInsight: {
      badge: 'School & Kids Safety',
      title: "🎒 Tomorrow's school commute may be rainy",
      subtitle: 'Pack umbrellas and rain covers tonight. Morning school bus window (7:45–8:15 AM) has a 70% rain probability.',
      icon: CloudRain,
      iconBg: 'bg-amber-500',
      iconColor: 'text-white',
      actionLabel: 'Kid Safety Tips',
      whyContext: 'Monsoon trough depression will trigger scattered early morning precipitation over urban school zones.',
      whyFactors: [
        'Rainfall probability reaches 70% between 7:30 AM and 8:30 AM',
        'Surface puddles and bus stop splash risk along suburban routes',
        'Afternoon dismissal (2:00 PM) will be warmer at 33°C under clearing skies',
        'Playground UV Index reaches 6.0 during noon outdoor recess',
      ],
      advisoryHeadline: 'School Run Checklist',
      advisoryItems: [
        {
          title: 'Pack lightweight poncho and shoes with grip',
          desc: 'Prevent wet socks and slip hazards during morning bus boarding.',
          iconType: 'amber',
        },
        {
          title: 'Ensure electrolyte / water bottle for afternoon',
          desc: 'Classroom dispersal at 2:00 PM coincides with humid 33°C temperatures.',
          iconType: 'blue',
        },
        {
          title: 'Advise sunscreen & caps for noon recess',
          desc: 'High UV Index (6.0) between 11:30 AM and 1:30 PM.',
          iconType: 'indigo',
        },
      ],
    },
    quickCards: [
      {
        id: 'morning-bus',
        category: 'Morning Bus Drop-off',
        metric: '7:45–8:15 AM',
        sub: 'Rain chance 70% • Pack poncho',
        badge: 'Rain Alert',
        badgeColor: 'bg-amber-50 text-amber-800',
        icon: CloudRain,
        iconBg: 'bg-amber-50',
        iconColor: 'text-amber-600',
      },
      {
        id: 'afternoon-pickup',
        category: 'Afternoon Pick-up',
        metric: '1:30–2:15 PM',
        sub: 'Warm 33°C • Keep water bottle',
        badge: 'Warm Transit',
        badgeColor: 'bg-blue-50 text-blue-800',
        icon: Sun,
        iconBg: 'bg-blue-50',
        iconColor: 'text-blue-600',
      },
      {
        id: 'playground-uv',
        category: 'Playground UV Recess',
        metric: 'UV 6 (High)',
        sub: 'Recess shade advised',
        badge: 'Sun Protection',
        badgeColor: 'bg-rose-50 text-rose-800',
        icon: Sun,
        iconBg: 'bg-rose-50',
        iconColor: 'text-rose-600',
      },
      {
        id: 'kids-aqi',
        category: 'Air Quality for Kids',
        metric: 'AQI 128 Moderate',
        sub: 'Limit high-intensity sports',
        badge: 'Monitor Kids',
        badgeColor: 'bg-emerald-50 text-emerald-800',
        icon: Wind,
        iconBg: 'bg-emerald-50',
        iconColor: 'text-emerald-600',
        route: 'air-quality',
      },
    ],
    timelineItems: [
      {
        time: '7:30 AM',
        title: 'School Morning Departure',
        sub: 'Cool 24°C, overcast skies with drizzle • Umbrella and bag covers needed',
        status: 'caution',
        icon: CloudRain,
        badge: 'School Drop',
      },
      {
        time: '11:30 AM',
        title: 'School Recess Window',
        sub: 'UV building up to 6.0 • Hydration break and shaded courtyard play',
        status: 'warning',
        icon: Sun,
        badge: 'UV 6.0',
      },
      {
        time: '2:00 PM',
        title: 'Afternoon School Dismissal',
        sub: 'Warm 33°C with sun • Ensure cool water bottles for the bus ride home',
        status: 'safe',
        icon: Sun,
        badge: 'Pick-up',
      },
      {
        time: '5:30 PM',
        title: 'Kids Outdoor Park Window',
        sub: 'Pleasant 28°C, clean air, safe breeze • Ideal time for society park play',
        status: 'safe',
        icon: Activity,
        badge: 'Play Window',
      },
    ],
    hourlyHighlight: {
      time: '8 AM',
      label: '🎒 School',
      icon: '🎒',
    },
    specialBanner: {
      type: 'family',
      title: "Tomorrow's School Prep Reminder",
      subtitle: 'Rain expected during 7:45 AM school bus arrival. Keep raincoats and waterproof bag sleeves packed by the door.',
      badge: 'Parent Checklist',
      actionLabel: 'Check Weather Timeline',
    },
  },

  travel: {
    id: 'travel',
    label: 'Travel & Trips',
    emoji: '✈️',
    heroInsight: {
      badge: 'Trip Weather Radar',
      title: '✈️ Jaipur · 18–21 Sep',
      subtitle: 'Saturday currently looks best for outdoor plans (Amer Fort & Hawa Mahal) with zero rain risk and comfortable 32°C/24°C.',
      secondaryNote: 'Route radar active: Delhi to Jaipur NH-48 expressway clear with 10 km visibility.',
      icon: Plane,
      iconBg: 'bg-purple-600',
      iconColor: 'text-white',
      actionLabel: 'View Trip Itinerary',
      whyContext: 'A dry continental air mass over Rajasthan keeps rain probability under 5% throughout your journey dates.',
      whyFactors: [
        'Stable high-pressure ridge over eastern Rajasthan ensures cloudless skies',
        'Day temperatures peak at 32°C between 1:30 PM and 3:30 PM',
        'Night and early morning temperatures drop to comfortable 24°C',
        'Zero road fog or severe convective turbulence detected along NH-48 corridor',
      ],
      advisoryHeadline: 'Travel Weather Insights',
      advisoryItems: [
        {
          title: 'Best heritage sightseeing: 8:00 AM – 11:30 AM',
          desc: 'Visit Amer Fort and Jal Mahal in morning coolness before midday heat.',
          iconType: 'indigo',
        },
        {
          title: 'Packing: Breathable cottons, sunglasses & sun hat',
          desc: 'Zero rainfall expected; focus on sun protection and comfortable walking shoes.',
          iconType: 'emerald',
        },
        {
          title: 'Plan open-air dinner at Nahargarh for 7:30 PM',
          desc: 'Pleasant 26°C with cool ridge breeze and clear panoramic city views.',
          iconType: 'blue',
        },
      ],
    },
    quickCards: [
      {
        id: 'dest-temp',
        category: 'Destination Outlook',
        metric: 'Jaipur 32°C / 24°C',
        sub: 'Dry, sunny heritage skies',
        badge: 'Pleasant',
        badgeColor: 'bg-purple-50 text-purple-800',
        icon: Sun,
        iconBg: 'bg-purple-50',
        iconColor: 'text-purple-600',
        route: 'trip-planner',
      },
      {
        id: 'sightseeing-window',
        category: 'Sightseeing Window',
        metric: '8:00–11:30 AM',
        sub: 'Cool morning heritage walks',
        badge: 'Best Window',
        badgeColor: 'bg-emerald-50 text-emerald-800',
        icon: Compass,
        iconBg: 'bg-emerald-50',
        iconColor: 'text-emerald-600',
      },
      {
        id: 'travel-packing',
        category: 'Smart Packing Tips',
        metric: 'Cotton & Sunglasses',
        sub: 'Zero rain expected • Sun hat',
        badge: 'Pack Light',
        badgeColor: 'bg-amber-50 text-amber-800',
        icon: Sparkles,
        iconBg: 'bg-amber-50',
        iconColor: 'text-amber-600',
      },
      {
        id: 'highway-route',
        category: 'Highway Road Weather',
        metric: 'NH-48 Route Clear',
        sub: '10 km visibility, dry asphalt',
        badge: 'Safe Driving',
        badgeColor: 'bg-blue-50 text-blue-800',
        icon: Car,
        iconBg: 'bg-blue-50',
        iconColor: 'text-blue-600',
      },
    ],
    timelineItems: [
      {
        time: '8:00 AM',
        title: 'Morning Sightseeing Window',
        sub: 'Amer Fort & Jal Mahal • Comfortable 25°C, soft morning sunlight',
        status: 'safe',
        icon: Compass,
        badge: 'Prime Visit',
      },
      {
        time: '1:00 PM',
        title: 'Indoor Museums & Bazaars',
        sub: 'Peak afternoon heat 32°C • City Palace AC exhibits & Johari Bazaar shopping',
        status: 'caution',
        icon: Sun,
        badge: 'Indoor Best',
      },
      {
        time: '5:30 PM',
        title: 'Sunset at Nahargarh Fort',
        sub: 'Pleasant 28°C, panoramic golden hour breeze across the Aravalli hills',
        status: 'safe',
        icon: Activity,
        badge: 'Golden Hour',
      },
      {
        time: '8:00 PM',
        title: 'Open Air Dinner & Culture',
        sub: 'Comfortable 26°C with starry sky • Ideal for traditional Rajasthani dinner',
        status: 'safe',
        icon: Sparkles,
        badge: 'Dinner Time',
      },
    ],
    hourlyHighlight: {
      time: '8 AM',
      label: '✈️ Tour',
      icon: '✈️',
    },
    specialBanner: {
      type: 'travel',
      title: 'AI Weather Trip Planner',
      subtitle: 'Planning an intercity journey? Explore day-by-day meteorological forecasts, route radar & smart packing tips.',
      badge: 'Trip Planner',
      actionLabel: 'Open Trip Planner →',
      route: 'trip-planner',
    },
  },

  farming: {
    id: 'farming',
    label: 'Farming & Gardening',
    emoji: '🌱',
    heroInsight: {
      badge: 'GKMS Agromet Alert',
      title: '🌧 Rain expected tomorrow afternoon',
      subtitle: "Consider tomorrow's rainfall (18–24 mm) before planning canal irrigation or top-dressing fertilizers.",
      secondaryNote: '🌾 Best field-work window today: 6:30–10:00 AM (Gentle wind 7 km/h, comfortable 23°C).',
      icon: CloudRain,
      iconBg: 'bg-emerald-700',
      iconColor: 'text-white',
      actionLabel: 'Agromet Advisory',
      whyContext: 'A low-pressure trough over northwest India will trigger widespread moderate convective rainfall within 24–36 hrs.',
      whyFactors: [
        'Precipitation forecast: 18 to 24 mm accumulation by tomorrow 6:00 PM',
        'Topsoil moisture (10cm depth) currently at 68% field capacity — adequate for standing crops',
        'Wind speed remains below 10 km/h until 11 AM, offering safe foliar spray conditions',
        'High humidity (82%) favors fungal spore germination; monitor paddy sheath blight',
      ],
      advisoryHeadline: 'Agromet GKMS Field Directives',
      advisoryItems: [
        {
          title: 'Hold canal & tube-well irrigation',
          desc: 'Conserve water and avoid waterlogging as 20mm rainfall is imminent.',
          iconType: 'blue',
        },
        {
          title: 'Complete foliar / pesticide spray by 10:00 AM',
          desc: 'Low wind (< 8 km/h) prevents spray drift. Rain may wash off late sprays.',
          iconType: 'emerald',
        },
        {
          title: 'Clear drainage channels in low-lying plots',
          desc: 'Ensure smooth stormwater run-off to prevent root asphyxiation.',
          iconType: 'amber',
        },
      ],
    },
    quickCards: [
      {
        id: 'field-work',
        category: 'Field Work Window',
        metric: '6:30–10:00 AM',
        sub: 'Low heat, wind 7 km/h',
        badge: 'Optimal',
        badgeColor: 'bg-emerald-50 text-emerald-800',
        icon: Activity,
        iconBg: 'bg-emerald-50',
        iconColor: 'text-emerald-600',
        route: 'krishi-mausam',
      },
      {
        id: 'irrigation-advisory',
        category: 'Irrigation Consideration',
        metric: 'Hold Irrigation',
        sub: '18–24 mm rain arriving',
        badge: 'Save Water',
        badgeColor: 'bg-blue-50 text-blue-800',
        icon: Droplets,
        iconBg: 'bg-blue-50',
        iconColor: 'text-blue-600',
        route: 'krishi-mausam',
      },
      {
        id: 'spray-conditions',
        category: 'Pesticide Spray Window',
        metric: 'Favorable Morning',
        sub: 'Wind < 10 km/h • No drift',
        badge: 'Safe Spray',
        badgeColor: 'bg-teal-50 text-teal-800',
        icon: Wind,
        iconBg: 'bg-teal-50',
        iconColor: 'text-teal-600',
      },
      {
        id: 'soil-moisture',
        category: 'Soil Moisture (10 & 30cm)',
        metric: '68% Adequate',
        sub: 'Evapotranspiration: 4.2 mm/d',
        badge: 'Root Moisture',
        badgeColor: 'bg-amber-50 text-amber-800',
        icon: Thermometer,
        iconBg: 'bg-amber-50',
        iconColor: 'text-amber-600',
      },
    ],
    timelineItems: [
      {
        time: '6:30 AM',
        title: 'Field Sowing & Harvesting Window',
        sub: 'Cool 23°C, gentle breeze • Ideal for field operations and manual labor',
        status: 'safe',
        icon: Activity,
        badge: 'Field Work',
      },
      {
        time: '9:30 AM',
        title: 'Pesticide / Foliar Spray Window',
        sub: 'Wind speed 7 km/h with dry foliage • Good absorption before midday sun',
        status: 'safe',
        icon: Wind,
        badge: 'Spray Window',
      },
      {
        time: '1:00 PM',
        title: 'Peak Evapotranspiration',
        sub: 'High solar heat (33°C) • Protect nursery beds and keep livestock in shade',
        status: 'warning',
        icon: Sun,
        badge: 'Heat Peak',
      },
      {
        time: '5:30 PM',
        title: 'Canal & Drainage Channel Check',
        sub: 'Inspect field bunds and prepare drainage channels for incoming rain band',
        status: 'caution',
        icon: Droplets,
        badge: 'Prep Drain',
      },
    ],
    hourlyHighlight: {
      time: '7 AM',
      label: '🌾 Spray',
      icon: '🌾',
    },
    specialBanner: {
      type: 'farming',
      title: 'GKMS Agromet Advisory (MoES / IMD)',
      subtitle: 'Paddy: Grain development stage, inspect for blast. Mustard: Seedbed preparation window opens Friday with incoming moisture.',
      badge: 'Krishi Bulletin',
      actionLabel: 'Open Krishi Mausam →',
      route: 'krishi-mausam',
    },
  },

  beach: {
    id: 'beach',
    label: 'Beach & Outdoor',
    emoji: '🏖️',
    heroInsight: {
      badge: 'Coastal Safety Status',
      title: '🏖️ Favorable coastal & beach conditions today',
      subtitle: 'Wave height 1.1m with moderate onshore breeze (14 km/h). Safe for shoreline activities until 2:00 PM.',
      icon: Sun,
      iconBg: 'bg-cyan-600',
      iconColor: 'text-white',
      actionLabel: 'Beach Safety Check',
      whyContext: 'INCOIS coastal telemetry reports calm-to-moderate swell period (8.5s) with normal tidal range.',
      whyFactors: [
        'Significant wave height remains steady between 0.9m and 1.2m',
        'Low tide (0.4m) occurs at 9:15 AM; wide firm sandbank for walking',
        'High tide (2.4m) arrives at 3:45 PM; retreat from exposed rocky outcroppings by 2:00 PM',
        'Solar UV Index climbs to 7.5; water surface reflection intensifies erythemal exposure',
      ],
      advisoryHeadline: 'Coastal & Water Safety Guide',
      advisoryItems: [
        {
          title: 'Swim only in designated lifeguard zones',
          desc: 'Green flag status active; mild longshore current near sandbars.',
          iconType: 'emerald',
        },
        {
          title: 'Apply water-resistant SPF 50+ sunscreen',
          desc: 'Sand and sea surface reflection increase UV exposure by 25%.',
          iconType: 'amber',
        },
        {
          title: 'Watch incoming tide between 2:30 PM and 4:30 PM',
          desc: 'Shoreline narrows rapidly during rising tide to 2.4m.',
          iconType: 'blue',
        },
      ],
    },
    quickCards: [
      {
        id: 'coastal-breeze',
        category: 'Coastal Breeze & Wind',
        metric: '14 km/h (Gusts 20)',
        sub: 'Onshore breeze from SW',
        badge: 'Moderate',
        badgeColor: 'bg-cyan-50 text-cyan-800',
        icon: Wind,
        iconBg: 'bg-cyan-50',
        iconColor: 'text-cyan-600',
      },
      {
        id: 'tide-schedule',
        category: 'Tide Timings (INCOIS)',
        metric: 'Low 9:15A · High 3:45P',
        sub: 'Safe beach walk timing',
        badge: 'Safe Shore',
        badgeColor: 'bg-blue-50 text-blue-800',
        icon: Droplets,
        iconBg: 'bg-blue-50',
        iconColor: 'text-blue-600',
      },
      {
        id: 'wave-height',
        category: 'Wave Height & Swell',
        metric: '1.1m (Calm-Mod)',
        sub: 'Swell 8.5s • Safe zone',
        badge: 'Green Flag',
        badgeColor: 'bg-emerald-50 text-emerald-800',
        icon: Activity,
        iconBg: 'bg-emerald-50',
        iconColor: 'text-emerald-600',
      },
      {
        id: 'beach-uv',
        category: 'UV Radiation & Sea Glare',
        metric: 'UV 7.5 Very High',
        sub: 'Water reflection factor',
        badge: 'SPF 50+',
        badgeColor: 'bg-rose-50 text-rose-800',
        icon: Sun,
        iconBg: 'bg-rose-50',
        iconColor: 'text-rose-600',
      },
    ],
    timelineItems: [
      {
        time: '7:00 AM',
        title: 'Morning Shoreline Walk & Jog',
        sub: 'Low tide approaching (9:15 AM) • Broad, firm sand and refreshing sea breeze',
        status: 'safe',
        icon: Activity,
        badge: 'Low Tide',
      },
      {
        time: '11:30 AM',
        title: 'Water Sports & Swim Window',
        sub: 'Calm swell 1.0m, lifeguard on duty • Re-apply waterproof sunblock',
        status: 'safe',
        icon: Sun,
        badge: 'Swim Safe',
      },
      {
        time: '2:00 PM',
        title: 'High UV & Rising Tide Caution',
        sub: 'Tide rising to 2.4m • Move umbrellas and gear back from waterline',
        status: 'caution',
        icon: Droplets,
        badge: 'Tide Rising',
      },
      {
        time: '5:30 PM',
        title: 'Beach Sunset Stroll',
        sub: 'Pleasant 26°C with cool onshore breeze • Safe shore conditions',
        status: 'safe',
        icon: Sun,
        badge: 'Sunset',
      },
    ],
    hourlyHighlight: {
      time: '11 AM',
      label: '🏖️ Swim',
      icon: '🏖️',
    },
  },

  events: {
    id: 'events',
    label: 'Events & Weddings',
    emoji: '🎉',
    heroInsight: {
      badge: 'Outdoor Event Forecast',
      title: '🎉 Your outdoor event window looks good until 4 PM',
      subtitle: '94% dry probability for morning and afternoon gathering. Evening marquee/tent canopy recommended as light rain is possible post 7 PM.',
      icon: Sparkles,
      iconBg: 'bg-rose-600',
      iconColor: 'text-white',
      actionLabel: 'Event Weather Checklist',
      whyContext: 'Surface convection may generate isolated rain cells after 7:15 PM over open grounds.',
      whyFactors: [
        'Clear daytime skies (10 AM - 4 PM) ensure zero precipitation during main ceremonies',
        'Wind speed remains under 12 km/h; safe for decorative arches, floral canopies and sound stages',
        'Evening temperature settles at a comfortable 26°C for open lawn dining',
        'Radar confidence index is 92% based on Safdarjung & Hindon telemetry',
      ],
      advisoryHeadline: 'Event Weather Preparation',
      advisoryItems: [
        {
          title: 'Stage & floral setup: 9:00 AM – 1:00 PM',
          desc: 'Dry, calm weather conditions minimize flower wilting and decor delays.',
          iconType: 'emerald',
        },
        {
          title: 'Keep waterproof canopy/shamiana on standby',
          desc: 'Light drizzle (30% chance) possible around 7:45 PM.',
          iconType: 'amber',
        },
        {
          title: 'Guest comfort: Outdoor lawn heaters not required',
          desc: 'Pleasant 26°C evening temperature ideal for festive attire.',
          iconType: 'blue',
        },
      ],
    },
    quickCards: [
      {
        id: 'event-rain',
        category: 'Rain Probability for Event',
        metric: '12% Daytime Risk',
        sub: 'Isolated drizzle post 7 PM',
        badge: 'Clear Day',
        badgeColor: 'bg-rose-50 text-rose-800',
        icon: CloudRain,
        iconBg: 'bg-rose-50',
        iconColor: 'text-rose-600',
      },
      {
        id: 'wind-tent',
        category: 'Wind & Marquee Safety',
        metric: '11 km/h Gentle',
        sub: 'Safe for arches & marquees',
        badge: 'Stable Winds',
        badgeColor: 'bg-teal-50 text-teal-800',
        icon: Wind,
        iconBg: 'bg-teal-50',
        iconColor: 'text-teal-600',
      },
      {
        id: 'event-temp',
        category: 'Evening Lawn Comfort',
        metric: '27°C at 7:00 PM',
        sub: 'Pleasant open-air dining',
        badge: 'Pleasant',
        badgeColor: 'bg-amber-50 text-amber-800',
        icon: Sun,
        iconBg: 'bg-amber-50',
        iconColor: 'text-amber-600',
      },
      {
        id: 'forecast-confidence',
        category: 'Forecast Confidence',
        metric: '92% High Confidence',
        sub: 'IMD Radar verified',
        badge: 'Reliable',
        badgeColor: 'bg-emerald-50 text-emerald-800',
        icon: CheckCircle2,
        iconBg: 'bg-emerald-50',
        iconColor: 'text-emerald-600',
      },
    ],
    timelineItems: [
      {
        time: '10:00 AM',
        title: 'Stage Setup & Floral Decor',
        sub: 'Pleasant 28°C, dry conditions • Ideal for vendor setup and soundchecks',
        status: 'safe',
        icon: Sparkles,
        badge: 'Setup',
      },
      {
        time: '2:00 PM',
        title: 'Guest Arrival & Lunch',
        sub: 'Warm 32°C • Shaded lawn or air-conditioned banquet hall recommended',
        status: 'safe',
        icon: Sun,
        badge: 'Arrival',
      },
      {
        time: '5:30 PM',
        title: 'Outdoor High Tea & Photos',
        sub: 'Golden hour 28°C with soft diffuse sunlight • Perfect for outdoor photography',
        status: 'safe',
        icon: Activity,
        badge: 'Photography',
      },
      {
        time: '8:00 PM',
        title: 'Evening Dinner & Celebration',
        sub: 'Comfortable 26°C • Keep backup marquee open as precaution',
        status: 'caution',
        icon: CloudRain,
        badge: 'Celebration',
      },
    ],
    hourlyHighlight: {
      time: '6 PM',
      label: '🎉 Event',
      icon: '🎉',
    },
  },
};

/**
 * Normalizes any incoming interest ID string to our standard set
 */
export function normalizeInterestId(raw: string): InterestId {
  const s = raw.toLowerCase();
  if (s.includes('run') || s.includes('fit')) return 'fitness';
  if (s.includes('health') || s.includes('aqi') || s.includes('air')) return 'health';
  if (s.includes('commute') || s.includes('transit') || s.includes('work')) return 'commute';
  if (s.includes('family') || s.includes('school') || s.includes('kid')) return 'family';
  if (s.includes('travel') || s.includes('trip')) return 'travel';
  if (s.includes('beach') || s.includes('coastal') || s.includes('marine')) return 'beach';
  if (s.includes('farm') || s.includes('agri') || s.includes('krishi') || s.includes('garden')) return 'farming';
  if (s.includes('event') || s.includes('wed') || s.includes('party')) return 'events';
  return 'commute';
}

/**
 * Derives dynamic Home Dashboard content based on user interests
 */
export function getActiveDashboard(userInterests: string[]): {
  activeIds: InterestId[];
  isSingle: boolean;
  primaryConfig: PersonaDashboardConfig;
  quickCards: PersonaQuickCard[];
  timelineItems: PersonaTimelineItem[];
  hourlyHighlight: { time: string; label: string; icon: string };
  heroInsight: PersonaDashboardConfig['heroInsight'];
  specialBanner?: PersonaDashboardConfig['specialBanner'];
} {
  const normalized = Array.from(
    new Set(
      (userInterests && userInterests.length > 0 ? userInterests : ['commute']).map(normalizeInterestId)
    )
  );

  const primaryId = normalized[0] || 'commute';
  const primaryConfig = ALL_PERSONA_CONFIGS[primaryId] || ALL_PERSONA_CONFIGS.commute;

  // If SINGLE interest: strictly that persona only
  if (normalized.length === 1) {
    return {
      activeIds: normalized,
      isSingle: true,
      primaryConfig,
      quickCards: primaryConfig.quickCards,
      timelineItems: primaryConfig.timelineItems,
      hourlyHighlight: primaryConfig.hourlyHighlight,
      heroInsight: primaryConfig.heroInsight,
      specialBanner: primaryConfig.specialBanner,
    };
  }

  // If MULTIPLE interests: intelligently combine without clutter
  const combinedCards: PersonaQuickCard[] = [];
  const combinedTimeline: PersonaTimelineItem[] = [];

  normalized.forEach((id) => {
    const cfg = ALL_PERSONA_CONFIGS[id];
    if (cfg) {
      // Pick top 2 cards from each selected persona up to 4 total
      cfg.quickCards.slice(0, 2).forEach((c) => {
        if (combinedCards.length < 4 && !combinedCards.some((existing) => existing.id === c.id)) {
          combinedCards.push(c);
        }
      });

      // Merge timeline milestones
      cfg.timelineItems.slice(0, 2).forEach((t) => {
        if (!combinedTimeline.some((existing) => existing.time === t.time)) {
          combinedTimeline.push(t);
        }
      });
    }
  });

  // Sort timeline by hour
  combinedTimeline.sort((a, b) => {
    const parseHour = (str: string) => {
      const parts = str.split(' ');
      const timeParts = parts[0].split(':');
      let h = parseInt(timeParts[0], 10);
      if (parts[1] === 'PM' && h !== 12) h += 12;
      if (parts[1] === 'AM' && h === 12) h = 0;
      return h;
    };
    return parseHour(a.time) - parseHour(b.time);
  });

  return {
    activeIds: normalized,
    isSingle: false,
    primaryConfig,
    quickCards: combinedCards.slice(0, 4),
    timelineItems: combinedTimeline.slice(0, 4),
    hourlyHighlight: primaryConfig.hourlyHighlight,
    heroInsight: primaryConfig.heroInsight,
    specialBanner: primaryConfig.specialBanner,
  };
}

/**
 * Dynamic Mausam Saathi prompt chips tailored by persona and language (Hinglish, English, Hindi)
 */
export function getSaathiSuggestionsForInterests(
  userInterests: string[],
  language: 'hinglish' | 'english' | 'hindi' = 'hinglish'
): string[] {
  const normalized = Array.from(new Set(userInterests.map(normalizeInterestId)));
  const primaryId = normalized[0] || 'commute';

  const englishChips: Record<InterestId, string[]> = {
    fitness: [
      'Can I run this evening?',
      'Best time for 5k morning jog?',
      'How high is the UV today?',
      'Will humidity cause heat cramps?',
    ],
    health: [
      'Is AQI safe for a morning walk?',
      'Pollen count today in my area?',
      'Do I need an N95 mask today?',
      'Best clean-air window today?',
    ],
    commute: [
      'Should I carry an umbrella today?',
      'Will Delhi-Gurugram road be waterlogged?',
      'Leave early or wait for rain to pass?',
      'Evening return commute weather?',
    ],
    family: [
      'Will it rain during school hours?',
      'Should kids wear jackets tomorrow?',
      'Afternoon pick-up weather?',
      'Is playground UV safe at noon?',
    ],
    travel: [
      'Plan weather for my Jaipur trip.',
      'What should I pack for Rajasthan?',
      'Is rain expected on Delhi-Jaipur highway?',
      'Best time for Amer Fort sightseeing?',
    ],
    farming: [
      'Best time for field work today?',
      'When is rainfall expected?',
      'Can I spray pesticide today?',
      'Next 5 days rainfall forecast?',
    ],
    beach: [
      'Are tides safe for swimming today?',
      'Wave height and swell today?',
      'Wind speed at coast?',
      'What time is high tide?',
    ],
    events: [
      'Will it rain during evening banquet?',
      'Is wind safe for outdoor tent?',
      'Backup indoor plan needed?',
      'Evening lawn temperature forecast?',
    ],
  };

  const hinglishChips: Record<InterestId, string[]> = {
    fitness: [
      'Kya shaam ko running ja sakte hain?',
      'Subah 5k jog ke liye best time?',
      'Aaj UV kitna high hai?',
      'Kya umas se heat cramps honge?',
    ],
    health: [
      'Morning walk ke liye AQI safe hai?',
      'Mere area mein pollen count kitna hai?',
      'Kya aaj N95 mask lagana chahiye?',
      'Clean air breathing window kab hai?',
    ],
    commute: [
      'Chhaata leke nikalna padega kya?',
      'Kya highway par waterlogging hogi?',
      'Pehle niklu ya baarish rukne ka wait karu?',
      'Shaam ko ghar wapsi ka mausam?',
    ],
    family: [
      'School bus ke time par baarish hogi?',
      'Kal bachhon ko jacket pehnayein kya?',
      'Afternoon school pick-up weather?',
      'Dopahar mein playground UV kaisa hai?',
    ],
    travel: [
      'Jaipur trip ka mausam plan batao.',
      'Rajasthan trip ke liye kya pack karein?',
      'Delhi-Jaipur highway par baarish hogi?',
      'Amer Fort ghumne ka best time?',
    ],
    farming: [
      'Khet mein kaam ke liye best time?',
      'Baarish kab tak aane wali hai?',
      'Kya aaj pesticide spray kar sakte hain?',
      'Agle 5 din ka varsha anuman?',
    ],
    beach: [
      'Swimming ke liye waves safe hain?',
      'Aaj samundar mein lehar kitni unchi hai?',
      'Coastal area mein hawa ki speed?',
      'High tide kis samay aayegi?',
    ],
    events: [
      'Shaam ke function mein baarish hogi kya?',
      'Tent/shamiana ke liye hawa safe hai?',
      'Indoor backup plan zaroori hai?',
      'Shaam ko lawn ka temperature kitna hoga?',
    ],
  };

  const hindiChips: Record<InterestId, string[]> = {
    fitness: [
      'क्या आज शाम दौड़ने जा सकते हैं?',
      'प्रातः 5 किमी दौड़ का सर्वश्रेष्ठ समय?',
      'आज पराबैंगनी (UV) स्तर कितना है?',
      'उमस से मांसपेशियों में खिंचाव तो नहीं होगा?',
    ],
    health: [
      'क्या सुबह की सैर हेतु AQI सुरक्षित है?',
      'मेरे क्षेत्र में परागकण (Pollen) स्तर?',
      'क्या आज N-95 मास्क पहनना चाहिए?',
      'स्वच्छ वायु में सांस लेने का अनुकूल समय?',
    ],
    commute: [
      'क्या आज छाता लेकर जाना चाहिए?',
      'सड़कों पर जलभराव की क्या स्थिति है?',
      'जल्दी निकलें या बारिश रुकने की प्रतीक्षा करें?',
      'शाम को वापसी के समय मौसम कैसा रहेगा?',
    ],
    family: [
      'स्कूल के समय वर्षा की क्या संभावना है?',
      'क्या बच्चों को कल स्वेटर/जैकेट पहनाएं?',
      'दोपहर छुट्टी के समय कैसा रहेगा मौसम?',
      'दोपहर में खेल के मैदान में धूप सुरक्षित है?',
    ],
    travel: [
      'जयपुर यात्रा हेतु मौसम की योजना बताएं।',
      'राजस्थान यात्रा हेतु क्या सामान रखें?',
      'दिल्ली-जयपुर राजमार्ग पर बारिश के आसार?',
      'आमेर किला भ्रमण का सर्वश्रेष्ठ समय?',
    ],
    farming: [
      'आज खेत में कार्य का सर्वश्रेष्ठ समय?',
      'वर्षा कब तक होने का अनुमान है?',
      'क्या आज कीटनाशक छिड़काव संभव है?',
      'आगामी 5 दिनों का वर्षा पूर्वानुमान?',
    ],
    beach: [
      'क्या आज समुद्र में तैरना सुरक्षित है?',
      'तटीय क्षेत्र में लहरों की ऊंचाई?',
      'तट पर हवा की गति कितनी है?',
      'ज्वार-भाटा (High tide) किस समय आएगा?',
    ],
    events: [
      'क्या शाम के उत्सव में वर्षा की संभावना है?',
      'खुले शामियाने हेतु हवा की गति अनुकूल है?',
      'क्या इनडोर बैकअप योजना आवश्यक है?',
      'शाम को लॉन का तापमान कितना रहेगा?',
    ],
  };

  const chipsMap =
    language === 'hindi'
      ? hindiChips
      : language === 'english'
      ? englishChips
      : hinglishChips;

  // If multiple interests, blend chips from each
  if (normalized.length > 1) {
    const blended: string[] = [];
    normalized.forEach((id) => {
      const items = chipsMap[id] || [];
      if (items[0] && !blended.includes(items[0])) blended.push(items[0]);
      if (items[1] && !blended.includes(items[1]) && blended.length < 4) blended.push(items[1]);
    });
    return blended.slice(0, 4);
  }

  return chipsMap[primaryId] || chipsMap.commute;
}
