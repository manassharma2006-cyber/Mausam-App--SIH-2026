import React from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  ArrowLeft,
  Wind,
  ShieldAlert,
  AlertCircle,
  Activity,
  HeartPulse,
  Clock,
  Sparkles,
} from 'lucide-react';

export default function AirQuality({ navigate }: { navigate: Navigate }) {
  const { weatherData, language } = useWeather();
  const aqi = weatherData.aqi || {
    value: 124,
    categoryEn: 'Moderate',
    categoryHi: 'मध्यम',
    pm25: 48,
    pm10: 92,
    no2: 24,
    healthAdvisoryEn: 'Air quality is acceptable; however, sensitive individuals should limit prolonged outdoor exertion.',
    healthAdvisoryHi: 'वायु गुणवत्ता स्वीकार्य है; संवेदनशील व्यक्तियों को बाहर अधिक परिश्रम से बचना चाहिए।',
  };

  const getAqiColor = (val: number) => {
    if (val <= 50) return { bg: 'bg-emerald-500', text: 'text-emerald-800', light: 'bg-emerald-50' };
    if (val <= 100) return { bg: 'bg-lime-500', text: 'text-lime-800', light: 'bg-lime-50' };
    if (val <= 200) return { bg: 'bg-amber-500', text: 'text-amber-800', light: 'bg-amber-50' };
    if (val <= 300) return { bg: 'bg-orange-500', text: 'text-orange-800', light: 'bg-orange-50' };
    return { bg: 'bg-red-500', text: 'text-red-800', light: 'bg-red-50' };
  };

  const palette = getAqiColor(aqi.value);

  return (
    <div className="min-h-screen text-slate-900 pb-8" style={{ background: 'var(--m-bg)' }}>
      {/* Header */}
      <div className="bg-[#0A2A65] text-white px-5 pt-3 pb-6 rounded-b-3xl shadow-md">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-1 text-xs font-bold text-blue-200 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </button>
          <span className="text-[11px] font-bold text-amber-300 font-emblem tracking-wider">
            CPCB • IMD SAFAR
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/15">
            <Wind className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-white">Air Quality Index (AQI)</h1>
            <p className="text-xs text-blue-200 font-devanagari">
              वायु गुणवत्ता सूचकांक एवं स्वास्थ्य सुरक्षा परामर्श
            </p>
          </div>
        </div>
      </div>

      <div className="px-5 py-4 space-y-4">
        {/* Main AQI Gauge Card */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm text-center">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Current Air Quality
          </span>

          <div className="text-6xl font-black text-slate-900 tracking-tight my-2">
            {aqi.value}
          </div>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wider mb-3 bg-amber-100 text-amber-900">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span>{language === 'hi' ? aqi.categoryHi : aqi.categoryEn}</span>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed max-w-xs mx-auto">
            {language === 'hi' ? aqi.healthAdvisoryHi : aqi.healthAdvisoryEn}
          </p>
        </div>

        {/* Major Pollutants Breakdown */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-sm">
          <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-3">
            Key Particulate Matter Concentrations
          </h3>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold text-slate-500 block">PM2.5</span>
              <span className="text-lg font-black text-slate-900 block my-0.5">
                {aqi.pm25} <span className="text-[10px] font-normal text-slate-400">µg/m³</span>
              </span>
              <span className="text-[9px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.2 rounded">
                Moderate
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold text-slate-500 block">PM10</span>
              <span className="text-lg font-black text-slate-900 block my-0.5">
                {aqi.pm10} <span className="text-[10px] font-normal text-slate-400">µg/m³</span>
              </span>
              <span className="text-[9px] font-bold text-lime-700 bg-lime-50 px-1.5 py-0.2 rounded">
                Satisfactory
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold text-slate-500 block">NO₂</span>
              <span className="text-lg font-black text-slate-900 block my-0.5">
                {aqi.no2} <span className="text-[10px] font-normal text-slate-400">ppb</span>
              </span>
              <span className="text-[9px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded">
                Good
              </span>
            </div>
          </div>
        </div>

        {/* Clean Air Hours Recommendation */}
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-slate-900 flex items-start gap-3">
          <Clock className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed">
            <span className="font-bold text-emerald-900 block mb-0.5">
              Clean Air Window Recommendation:
            </span>
            Atmospheric dispersion models show optimal air quality between 05:00 AM and 07:30 AM before morning traffic inversions.
          </div>
        </div>

        {/* Health Precautions */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <HeartPulse className="w-4 h-4 text-red-500" />
            <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
              Health Guidelines
            </h3>
          </div>

          <div className="space-y-2 text-xs">
            <div className="p-2.5 rounded-xl bg-slate-50 flex items-center justify-between">
              <span className="text-slate-800">Elderly & Respiratory Patients</span>
              <span className="font-bold text-amber-700">Limit long walks</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 flex items-center justify-between">
              <span className="text-slate-800">Outdoor Jogging / Sports</span>
              <span className="font-bold text-emerald-700">Safe in early morning</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 flex items-center justify-between">
              <span className="text-slate-800">Indoor Air Quality</span>
              <span className="font-bold text-blue-700">Keep windows open</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
