import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  ArrowLeft,
  Clock,
  Wheat,
  Activity,
  Car,
  Shirt,
  Sun,
  CheckCircle2,
  XCircle,
  Wind,
  Droplets,
  Thermometer,
} from 'lucide-react';

interface ActivityType {
  id: string;
  nameEn: string;
  nameHi: string;
  icon: typeof Wheat;
  idealTempRange: string;
  maxWindKmh: number;
  maxRainProb: number;
  recommendedTimeEn: string;
  recommendedTimeHi: string;
  reasonEn: string;
  reasonHi: string;
}

const ACTIVITIES: ActivityType[] = [
  {
    id: 'spray',
    nameEn: 'Pesticide / Foliar Spray',
    nameHi: 'कीटनाशक व खाद छिड़काव',
    icon: Wheat,
    idealTempRange: '20°C - 28°C',
    maxWindKmh: 12,
    maxRainProb: 20,
    recommendedTimeEn: '06:00 AM – 09:30 AM',
    recommendedTimeHi: 'सुबह 06:00 से 09:30 बजे',
    reasonEn: 'Calm winds (< 8 km/h) prevent chemical drift, and 0% rain ensures absorption.',
    reasonHi: 'हवा की गति 8 किमी/घंटा से कम होने के कारण दवा बहती नहीं और पूर्ण अवशोषण होता है।',
  },
  {
    id: 'running',
    nameEn: 'Running & Outdoor Workout',
    nameHi: 'दौड़ व व्यायाम',
    icon: Activity,
    idealTempRange: '18°C - 25°C',
    maxWindKmh: 25,
    maxRainProb: 30,
    recommendedTimeEn: '05:30 AM – 07:30 AM',
    recommendedTimeHi: 'सुबह 05:30 से 07:30 बजे',
    reasonEn: 'Lowest air pollution levels (AQI: 84) and comfortable thermal index.',
    reasonHi: 'वायु गुणवत्ता सूचकांक बेहतर रहता है तथा तापमान आरामदायक रहता है।',
  },
  {
    id: 'commute',
    nameEn: 'Safe City Travel / Drive',
    nameHi: 'सुरक्षित सड़क यात्रा',
    icon: Car,
    idealTempRange: '15°C - 35°C',
    maxWindKmh: 35,
    maxRainProb: 40,
    recommendedTimeEn: '11:00 AM – 03:30 PM',
    recommendedTimeHi: 'सुबह 11:00 से दोपहर 03:30 बजे',
    reasonEn: 'Clear road visibility and zero waterlogging reported in this duration.',
    reasonHi: 'सड़कों पर स्पष्ट दृश्यता एवं इस समयावधि में जलभराव का जोखिम शून्य है।',
  },
  {
    id: 'laundry',
    nameEn: 'Clothes Drying & Solar Work',
    nameHi: 'धूप में कपड़े सुखाना व सौर कार्य',
    icon: Shirt,
    idealTempRange: '26°C - 38°C',
    maxWindKmh: 20,
    maxRainProb: 15,
    recommendedTimeEn: '10:30 AM – 02:30 PM',
    recommendedTimeHi: 'सुबह 10:30 से दोपहर 02:30 बजे',
    reasonEn: 'Direct solar radiation (UV 7+) and low relative humidity.',
    reasonHi: 'पर्याप्त धूप व कम सापेक्ष आर्द्रता के कारण त्वरित सुखाई।',
  },
];

export default function BestWindow({ navigate }: { navigate: Navigate }) {
  const { weatherData, formatTemp, language } = useWeather();
  const [selectedActivity, setSelectedActivity] = useState<string>('spray');

  const currentAct = ACTIVITIES.find((a) => a.id === selectedActivity) || ACTIVITIES[0];

  return (
    <div className="min-h-screen text-slate-900 pb-8" style={{ background: 'var(--m-bg)' }}>
      {/* Header */}
      <div className="bg-[#0A2A65] text-white px-5 pt-3 pb-6 rounded-b-3xl shadow-md">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-1 text-xs font-bold text-blue-200 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </button>
          <span className="text-[11px] font-bold text-amber-300 font-emblem tracking-wider">
            WEATHER OPTIMIZER
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/15">
            <Clock className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-white">Best Activity Window</h1>
            <p className="text-xs text-blue-200 font-devanagari">
              मौसम के अनुसार श्रेष्ठ समय स्लॉट का निर्धारण
            </p>
          </div>
        </div>
      </div>

      <div className="px-5 py-4 space-y-4">
        {/* Activity Selection Carousel */}
        <div>
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
            Select Your Activity (कार्य चुनें)
          </span>

          <div className="grid grid-cols-2 gap-2">
            {ACTIVITIES.map((act) => {
              const Icon = act.icon;
              const isSelected = selectedActivity === act.id;
              return (
                <button
                  key={act.id}
                  type="button"
                  onClick={() => setSelectedActivity(act.id)}
                  className={`p-3 rounded-2xl border text-left transition-all flex items-center gap-2.5 ${
                    isSelected
                      ? 'bg-white border-[#1A4FA0] shadow-sm ring-2 ring-[#1A4FA0]/15'
                      : 'bg-white/70 border-slate-200 hover:bg-white'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      isSelected ? 'bg-blue-100 text-[#1A4FA0]' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span className="font-extrabold text-xs text-slate-900 block truncate">
                      {language === 'hi' ? act.nameHi : act.nameEn}
                    </span>
                    <span className="text-[10px] text-slate-500 block truncate">
                      {act.idealTempRange}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Highlighted Best Window Card */}
        <div className="p-5 rounded-3xl bg-emerald-950 text-white border border-emerald-800 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 -mt-6 -mr-6 w-32 h-32 rounded-full bg-emerald-500/20 blur-xl pointer-events-none" />

          <div className="flex items-center justify-between mb-3 relative z-10">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-extrabold uppercase tracking-wider">
              Optimal Window Identified
            </span>
            <div className="flex items-center gap-1 text-emerald-300 text-xs font-bold">
              <CheckCircle2 className="w-4 h-4" />
              <span>96% Match</span>
            </div>
          </div>

          <div className="text-2xl font-black text-white tracking-tight mb-1 relative z-10">
            {language === 'hi' ? currentAct.recommendedTimeHi : currentAct.recommendedTimeEn}
          </div>
          <p className="text-xs text-emerald-200 leading-relaxed mb-4 relative z-10">
            {language === 'hi' ? currentAct.reasonHi : currentAct.reasonEn}
          </p>

          {/* Meteorological constraints parameters */}
          <div className="grid grid-cols-3 gap-2 pt-3 border-t border-emerald-800/80 text-center relative z-10">
            <div className="bg-white/10 rounded-xl p-2">
              <div className="flex items-center justify-center gap-1 text-[10px] text-emerald-300 font-bold mb-0.5">
                <Wind className="w-3 h-3" /> Wind
              </div>
              <div className="text-xs font-extrabold text-white">
                {'< ' + currentAct.maxWindKmh + ' km/h'}
              </div>
            </div>

            <div className="bg-white/10 rounded-xl p-2">
              <div className="flex items-center justify-center gap-1 text-[10px] text-emerald-300 font-bold mb-0.5">
                <Droplets className="w-3 h-3" /> Rain Risk
              </div>
              <div className="text-xs font-extrabold text-white">
                {'< ' + currentAct.maxRainProb + '%'}
              </div>
            </div>

            <div className="bg-white/10 rounded-xl p-2">
              <div className="flex items-center justify-center gap-1 text-[10px] text-emerald-300 font-bold mb-0.5">
                <Thermometer className="w-3 h-3" /> Comfort
              </div>
              <div className="text-xs font-extrabold text-white">
                {currentAct.idealTempRange}
              </div>
            </div>
          </div>
        </div>

        {/* 24-Hour Timeline Barometer */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-sm">
          <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-3">
            24-Hour Suitability Timeline
          </h3>

          <div className="space-y-2">
            {[
              { time: '06:00 AM', status: 'optimal', note: 'Ideal window: Minimal wind & no rain' },
              { time: '09:00 AM', status: 'optimal', note: 'Comfortable temperature and dry' },
              { time: '12:00 PM', status: 'moderate', note: 'High solar radiation, warm' },
              { time: '03:00 PM', status: 'avoid', note: 'Gusty winds and humidity spike' },
              { time: '06:00 PM', status: 'avoid', note: 'Shower risk (60% rain probability)' },
              { time: '09:00 PM', status: 'moderate', note: 'Pleasant evening settling' },
            ].map((slot, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 bg-slate-50 text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <span className="font-bold text-slate-800 font-mono w-16">{slot.time}</span>
                  <span className="text-slate-600 text-[11px]">{slot.note}</span>
                </div>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    slot.status === 'optimal'
                      ? 'bg-emerald-100 text-emerald-800'
                      : slot.status === 'moderate'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-red-100 text-red-800'
                  }`}
                >
                  {slot.status === 'optimal' ? 'Best' : slot.status === 'moderate' ? 'Fair' : 'Avoid'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
