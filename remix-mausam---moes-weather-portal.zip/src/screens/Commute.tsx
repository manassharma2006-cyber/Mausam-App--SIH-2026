import React from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  ArrowLeft,
  Car,
  AlertTriangle,
  Droplets,
  Eye,
  Train,
  CheckCircle2,
  Clock,
  ShieldCheck,
} from 'lucide-react';

export default function Commute({ navigate }: { navigate: Navigate }) {
  const { weatherData, language } = useWeather();
  const impacts = weatherData.trafficImpacts || [
    {
      corridorEn: 'Outer Ring Road / Arterial Expressway',
      corridorHi: 'आउटर रिंग रोड / एक्सप्रेसवे',
      riskLevel: 'Medium',
      riskLevelHi: 'मध्यम',
      waterloggingDepthCm: 8,
      delayEstimateEn: '+15 to 25 mins',
      delayEstimateHi: '+15 से 25 मिनट देरी',
      statusNoteEn: 'Slow moving traffic due to wet surface and low visibility.',
      statusNoteHi: 'गीली सड़क एवं कम दृश्यता के कारण यातायात धीमा।',
    },
    {
      corridorEn: 'Low-Lying Underpass & Subway Crossings',
      corridorHi: 'निचले अंडरपास व सबवे',
      riskLevel: 'High',
      riskLevelHi: 'उच्च',
      waterloggingDepthCm: 22,
      delayEstimateEn: 'Route Diverted',
      delayEstimateHi: 'मार्ग परिवर्तित',
      statusNoteEn: 'Localized water stagnation detected; light vehicles avoid this route.',
      statusNoteHi: 'जलभराव के कारण छोटे वाहनों को वैकल्पिक मार्ग लेने की सलाह।',
    },
    {
      corridorEn: 'Elevated Metro & Rail Transit Line',
      corridorHi: 'मेट्रो व रेल लाइन',
      riskLevel: 'Low',
      riskLevelHi: 'निम्न',
      waterloggingDepthCm: 0,
      delayEstimateEn: 'On Time (0 min)',
      delayEstimateHi: 'समय पर (0 मिनट)',
      statusNoteEn: 'Normal operations with zero weather delays reported.',
      statusNoteHi: 'मौसम संबंधी कोई व्यवधान नहीं, सुचारू संचालन।',
    },
  ];

  return (
    <div className="min-h-screen text-slate-900 pb-8" style={{ background: 'var(--m-bg)' }}>
      {/* Header */}
      <div className="bg-[#0A2A65] text-white px-5 pt-3 pb-6 rounded-b-3xl shadow-md">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-1 text-xs font-bold text-blue-200 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </button>
          <span className="text-[11px] font-bold text-amber-300 font-emblem tracking-wider">
            TRANSIT NOWCASTING
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/15">
            <Car className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-white">Commuter Weather & Traffic</h1>
            <p className="text-xs text-blue-200 font-devanagari">
              वर्षा, जलभराव एवं प्रमुख मार्गों पर यातायात प्रभाव
            </p>
          </div>
        </div>
      </div>

      <div className="px-5 py-4 space-y-4">
        {/* Visibility & Road Grip Metrics */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
            <div className="flex items-center justify-between text-slate-500 mb-1">
              <span className="text-[10px] font-bold uppercase tracking-wider">Visibility</span>
              <Eye className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-2xl font-black text-slate-900">
              {weatherData.visibilityKm || 4.2} <span className="text-xs font-normal text-slate-500">km</span>
            </div>
            <span className="text-[10px] text-emerald-700 font-bold block mt-1">
              Clear driving vision
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
            <div className="flex items-center justify-between text-slate-500 mb-1">
              <span className="text-[10px] font-bold uppercase tracking-wider">Road Surface</span>
              <Droplets className="w-4 h-4 text-cyan-600" />
            </div>
            <div className="text-2xl font-black text-slate-900">
              Damp
            </div>
            <span className="text-[10px] text-amber-700 font-bold block mt-1">
              Moderate braking caution
            </span>
          </div>
        </div>

        {/* Corridor Risk Cards */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Monitored Corridors & Subways
            </span>
            <span className="text-[11px] text-slate-400 font-medium">Real-Time AWS</span>
          </div>

          {impacts.map((imp, idx) => {
            const isHigh = imp.riskLevel === 'High';
            const isMed = imp.riskLevel === 'Medium';

            const borderCol = isHigh
              ? 'border-red-200 bg-red-50/50'
              : isMed
              ? 'border-amber-200 bg-amber-50/50'
              : 'border-slate-200/80 bg-white';

            const badgeCol = isHigh
              ? 'bg-red-100 text-red-800'
              : isMed
              ? 'bg-amber-100 text-amber-800'
              : 'bg-emerald-100 text-emerald-800';

            return (
              <div key={idx} className={`p-4 rounded-3xl border shadow-sm ${borderCol}`}>
                <div className="flex items-center justify-between mb-2">
                  <div className="font-extrabold text-xs text-slate-900">
                    {language === 'hi' ? imp.corridorHi : imp.corridorEn}
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${badgeCol}`}>
                    {language === 'hi' ? imp.riskLevelHi : imp.riskLevel} Risk
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs mb-2">
                  <div className="flex items-center gap-1.5 text-slate-600">
                    <Droplets className="w-3.5 h-3.5 text-blue-600" />
                    <span>Waterlogging: <strong>{imp.waterloggingDepthCm} cm</strong></span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-600 font-bold">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{language === 'hi' ? imp.delayEstimateHi : imp.delayEstimateEn}</span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-600 leading-snug border-t border-slate-200/60 pt-2">
                  {language === 'hi' ? imp.statusNoteHi : imp.statusNoteEn}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
