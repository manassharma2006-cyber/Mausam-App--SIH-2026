import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  Calendar,
  CloudRain,
  Sun,
  Sunrise,
  Sunset,
  Wind,
  Droplets,
  Eye,
  MapPin,
  Sparkles,
  AlertCircle,
  Clock,
  Layers,
  Activity,
  Compass,
} from 'lucide-react';

export default function Forecast({ navigate }: { navigate: Navigate }) {
  const { weatherData, language, formatTemp } = useWeather();
  const [activeTab, setActiveTab] = useState<'today' | '10days' | 'map'>('today');

  // 10-Day forecast data
  const tenDayData = [
    { day: 'Today', date: 'Thu, 10 Sep', icon: '🌦️', condition: 'Scattered Showers', high: 33, low: 25, rain: '78%' },
    { day: 'Fri', date: '11 Sep', icon: '⛅', condition: 'Partly Cloudy', high: 34, low: 26, rain: '20%' },
    { day: 'Sat', date: '12 Sep', icon: '🌧️', condition: 'Monsoon Rain', high: 31, low: 24, rain: '85%' },
    { day: 'Sun', date: '13 Sep', icon: '⛈️', condition: 'Thunderstorm', high: 30, low: 24, rain: '90%' },
    { day: 'Mon', date: '14 Sep', icon: '🌦️', condition: 'Passing Showers', high: 32, low: 25, rain: '45%' },
    { day: 'Tue', date: '15 Sep', icon: '🌤️', condition: 'Mostly Sunny', high: 35, low: 26, rain: '15%' },
    { day: 'Wed', date: '16 Sep', icon: '☀️', condition: 'Clear Sky', high: 36, low: 27, rain: '5%' },
    { day: 'Thu', date: '17 Sep', icon: '☀️', condition: 'Warm & Sunny', high: 36, low: 26, rain: '0%' },
    { day: 'Fri', date: '18 Sep', icon: '🌤️', condition: 'Pleasant Breeze', high: 34, low: 25, rain: '10%' },
    { day: 'Sat', date: '19 Sep', icon: '⛅', condition: 'Partly Cloudy', high: 33, low: 24, rain: '25%' },
  ];

  return (
    <div className="min-h-screen text-slate-900 pb-24 bg-[#F4F7FB]">
      {/* Top Header */}
      <div className="px-5 pt-4 pb-3">
        <div className="flex items-center justify-between mb-3">
          <div>
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Meteorological Outlook
            </span>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">
              Weather Forecast
            </h1>
          </div>
          <div className="px-3 py-1 rounded-full bg-blue-50 border border-blue-200/80 text-[11px] font-bold text-[#1A4FA0]">
            {weatherData.location.nameEn || 'Ghaziabad, NCR'}
          </div>
        </div>

        {/* ─── Segmented Tabs: Today / 10 Days / Map ─── */}
        <div className="p-1 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex gap-1">
          {(
            [
              { id: 'today', label: 'Today' },
              { id: '10days', label: '10 Days' },
              { id: 'map', label: 'Radar Map' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-[#1A4FA0] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 space-y-4">
        {/* ────────────────────────────────────────────────────────── */}
        {/* TAB 1: TODAY DETAILED VIEW                               */}
        {/* ────────────────────────────────────────────────────────── */}
        {activeTab === 'today' && (
          <div className="space-y-4">
            {/* Personalized Summaries Cards */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-4 rounded-3xl bg-emerald-50/80 border border-emerald-200/80 shadow-2xs space-y-1">
                <div className="flex items-center gap-1.5 text-emerald-800 text-[11px] font-bold uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Best Time Outside</span>
                </div>
                <div className="text-sm font-black text-slate-900">
                  06:10 – 07:30 PM
                </div>
                <p className="text-[11px] text-slate-600 font-medium">
                  26°C, cool breeze, 0% rain probability.
                </p>
              </div>

              <div className="p-4 rounded-3xl bg-amber-50/80 border border-amber-200/80 shadow-2xs space-y-1">
                <div className="flex items-center gap-1.5 text-amber-800 text-[11px] font-bold uppercase tracking-wider">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Weather Concern</span>
                </div>
                <div className="text-sm font-black text-slate-900">
                  Morning Commute Rain
                </div>
                <p className="text-[11px] text-slate-600 font-medium">
                  Shower expected 8:30–9:20 AM. Carry umbrella.
                </p>
              </div>
            </div>

            {/* Today Summary Card */}
            <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-sm text-slate-900">
                  Today’s Synoptic Summary
                </h3>
                <span className="text-[11px] font-bold text-[#1A4FA0]">
                  IMD AWS Live
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                A trough of low pressure across Northern UP and NCR brings moderate moist winds from the Bay of Bengal. Humid morning transitioning into localized convective thundershowers during rush hour, settling into a pleasant overcast evening.
              </p>
            </div>

            {/* Sun & Atmosphere Cards Grid */}
            <div className="grid grid-cols-2 gap-3">
              {/* Sunrise & Sunset */}
              <div className="p-4 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-2.5">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                  Sun Cycle
                </span>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sunrise className="w-4 h-4 text-amber-500" />
                    <div>
                      <span className="text-[10px] text-slate-500 block">Sunrise</span>
                      <span className="text-xs font-black text-slate-900">06:04 AM</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Sunset className="w-4 h-4 text-orange-500" />
                    <div>
                      <span className="text-[10px] text-slate-500 block">Sunset</span>
                      <span className="text-xs font-black text-slate-900">06:31 PM</span>
                    </div>
                  </div>
                </div>
                <div className="w-full h-1 bg-amber-100 rounded-full overflow-hidden">
                  <div className="w-2/3 h-full bg-gradient-to-r from-amber-400 to-orange-400 rounded-full" />
                </div>
              </div>

              {/* Humidity & Dew Point */}
              <div className="p-4 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                  Humidity
                </span>
                <div className="text-2xl font-black text-slate-900">82%</div>
                <p className="text-[11px] text-slate-500 font-medium">
                  Dew point: 24°C • High moisture
                </p>
              </div>

              {/* UV Radiation */}
              <div className="p-4 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                  UV Index
                </span>
                <div className="text-2xl font-black text-slate-900">
                  7 <span className="text-xs font-bold text-amber-600">Very High</span>
                </div>
                <p className="text-[11px] text-slate-500 font-medium">
                  Peak at 12:30 PM • Sun protection advised
                </p>
              </div>

              {/* Wind & Gusts */}
              <div className="p-4 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                  Wind Speed
                </span>
                <div className="text-2xl font-black text-slate-900">
                  14 <span className="text-xs font-bold text-slate-500">km/h E</span>
                </div>
                <p className="text-[11px] text-slate-500 font-medium">
                  Gusts up to 24 km/h during rain
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ────────────────────────────────────────────────────────── */}
        {/* TAB 2: 10 DAYS FORECAST                                  */}
        {/* ────────────────────────────────────────────────────────── */}
        {activeTab === '10days' && (
          <div className="space-y-2.5">
            {tenDayData.map((item, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs flex items-center justify-between gap-3"
              >
                {/* Day & Date */}
                <div className="w-24">
                  <span className="text-xs font-black text-slate-900 block">
                    {item.day}
                  </span>
                  <span className="text-[11px] font-medium text-slate-500">
                    {item.date}
                  </span>
                </div>

                {/* Condition & Icon */}
                <div className="flex items-center gap-2 flex-1">
                  <span className="text-xl">{item.icon}</span>
                  <span className="text-xs font-bold text-slate-700 truncate max-w-[90px]">
                    {item.condition}
                  </span>
                </div>

                {/* Rain % */}
                <div className="w-12 text-center">
                  <span className="text-[11px] font-extrabold text-blue-600 flex items-center justify-center gap-0.5">
                    <CloudRain className="w-3 h-3" />
                    {item.rain}
                  </span>
                </div>

                {/* High / Low Bar */}
                <div className="flex items-center gap-2 w-24 justify-end">
                  <span className="text-xs font-medium text-slate-500">
                    {item.low}°
                  </span>
                  <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="w-full h-full bg-gradient-to-r from-blue-400 to-amber-400 rounded-full" />
                  </div>
                  <span className="text-xs font-black text-slate-900">
                    {item.high}°
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ────────────────────────────────────────────────────────── */}
        {/* TAB 3: RADAR MAP VIEW                                    */}
        {/* ────────────────────────────────────────────────────────── */}
        {activeTab === 'map' && (
          <div className="space-y-3">
            <div className="relative rounded-3xl overflow-hidden border border-slate-200/90 shadow-md bg-slate-900 h-80 flex flex-col justify-between p-4">
              {/* Simulated Doppler Radar Map Graphic */}
              <div
                className="absolute inset-0 opacity-70"
                style={{
                  background:
                    'radial-gradient(circle at 60% 45%, rgba(14, 165, 233, 0.6) 0%, rgba(16, 185, 129, 0.4) 30%, rgba(234, 179, 8, 0.4) 45%, rgba(239, 68, 68, 0.5) 60%, transparent 80%)',
                }}
              />

              {/* Grid Lines */}
              <div className="absolute inset-0 bg-[radial-gradient(#ffffff22_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

              {/* Top Controls */}
              <div className="relative z-10 flex items-center justify-between">
                <span className="px-3 py-1 rounded-full bg-slate-900/80 backdrop-blur-md border border-white/20 text-[11px] font-bold text-white flex items-center gap-1.5">
                  <Layers className="w-3 h-3 text-sky-400" />
                  <span>IMD Doppler Composite Radar</span>
                </span>
                <span className="px-2.5 py-1 rounded-full bg-emerald-500/80 text-white text-[10px] font-bold">
                  LIVE 10m
                </span>
              </div>

              {/* Center Radar Sweep & City Pin */}
              <div className="relative z-10 my-auto text-center">
                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-white/90 backdrop-blur-md shadow-lg border border-white text-slate-900 text-xs font-black">
                  <MapPin className="w-3.5 h-3.5 text-rose-600" />
                  <span>Vasundhara, Ghaziabad AWS</span>
                </div>
              </div>

              {/* Bottom Radar Legend */}
              <div className="relative z-10 bg-slate-900/80 backdrop-blur-md p-2.5 rounded-2xl border border-white/10 flex items-center justify-between text-[10px] text-white">
                <span>Light</span>
                <div className="w-36 h-2 rounded-full bg-gradient-to-r from-sky-400 via-emerald-400 via-yellow-400 to-rose-600" />
                <span>Heavy (50+ dBZ)</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 text-center font-medium">
              Radar sweep updated automatically every 10 minutes from IMD Palam & Hindon stations.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
