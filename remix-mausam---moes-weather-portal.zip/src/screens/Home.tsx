import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import WeatherReasonSheet from '../components/WeatherReasonSheet';
import LocationPickerModal from '../components/LocationPickerModal';
import {
  getActiveDashboard,
  ALL_PERSONA_CONFIGS,
  InterestId,
} from '../data/personaData';
import {
  MapPin,
  ChevronDown,
  Bell,
  Sparkles,
  CloudRain,
  Wind,
  Sun,
  Activity,
  Car,
  CheckCircle2,
  Clock,
  WifiOff,
  ArrowRight,
  Info,
  Droplets,
  Eye,
  Thermometer,
  Compass,
  Plane,
  ShieldCheck,
  Calendar,
} from 'lucide-react';

export default function Home({
  navigate,
  interests = ['commute'],
}: {
  navigate: Navigate;
  interests?: string[];
}) {
  const { weatherData, userProfile, updateUserProfile, isOffline, setIsOffline } = useWeather();

  // Active interests resolved from user profile or props
  const effectiveInterests =
    userProfile.interests && userProfile.interests.length > 0
      ? userProfile.interests
      : interests;

  const dashboard = getActiveDashboard(effectiveInterests);

  // Modals state
  const [isWhyOpen, setIsWhyOpen] = useState(false);
  const [isAdvisoryOpen, setIsAdvisoryOpen] = useState(false);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);

  // Hourly forecast data adapting to persona highlights
  const hourlyData = [
    { time: 'Now', temp: '29°', rain: '20%', icon: '⛅', isCurrent: true },
    { time: '6 AM', temp: '23°', rain: '8%', icon: '🌅', isHighlight: dashboard.hourlyHighlight.time === '6 AM', label: dashboard.hourlyHighlight.time === '6 AM' ? dashboard.hourlyHighlight.label : undefined },
    { time: '7 AM', temp: '25°', rain: '12%', icon: '🌤️', isHighlight: dashboard.hourlyHighlight.time === '7 AM', label: dashboard.hourlyHighlight.time === '7 AM' ? dashboard.hourlyHighlight.label : undefined },
    { time: '8 AM', temp: '27°', rain: '45%', icon: '🌦️', isHighlight: dashboard.hourlyHighlight.time === '8 AM', label: dashboard.hourlyHighlight.time === '8 AM' ? dashboard.hourlyHighlight.label : undefined },
    { time: '9 AM', temp: '28°', rain: '78%', icon: '🌧️', isHighlight: dashboard.hourlyHighlight.time === '9 AM', label: dashboard.hourlyHighlight.time === '9 AM' ? dashboard.hourlyHighlight.label : undefined },
    { time: '10 AM', temp: '30°', rain: '30%', icon: '⛅' },
    { time: '11 AM', temp: '31°', rain: '10%', icon: '🌤️', isHighlight: dashboard.hourlyHighlight.time === '11 AM', label: dashboard.hourlyHighlight.time === '11 AM' ? dashboard.hourlyHighlight.label : undefined },
    { time: '12 PM', temp: '33°', rain: '5%', icon: '☀️' },
    { time: '1 PM', temp: '33°', rain: '5%', icon: '☀️' },
    { time: '2 PM', temp: '32°', rain: '10%', icon: '🌤️' },
    { time: '3 PM', temp: '31°', rain: '15%', icon: '⛅' },
    { time: '4 PM', temp: '30°', rain: '20%', icon: '⛅' },
    { time: '5 PM', temp: '29°', rain: '15%', icon: '🌤️' },
    { time: '6 PM', temp: '27°', rain: '8%', icon: '🌇', isHighlight: dashboard.hourlyHighlight.time === '6 PM', label: dashboard.hourlyHighlight.time === '6 PM' ? dashboard.hourlyHighlight.label : undefined },
    { time: '7 PM', temp: '26°', rain: '5%', icon: '🌙' },
  ];

  const HeroIcon = dashboard.heroInsight.icon;

  const handleActionClick = () => {
    if (dashboard.primaryConfig.id === 'travel' && dashboard.heroInsight.actionLabel.includes('Trip')) {
      navigate('trip-planner');
      return;
    }
    if (dashboard.primaryConfig.id === 'farming' && dashboard.heroInsight.actionLabel.includes('Agromet')) {
      setIsAdvisoryOpen(true);
      return;
    }
    setIsAdvisoryOpen(true);
  };

  return (
    <div className="min-h-screen text-slate-900 pb-20 relative bg-[#F4F7FB]">
      {/* ─── Offline Mode Banner ─── */}
      {isOffline && (
        <div className="bg-amber-50 border-b border-amber-200 px-5 py-2.5 flex items-center justify-between text-xs text-amber-900 font-medium">
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4 text-amber-700 shrink-0" />
            <div>
              <span className="font-bold block text-amber-950">Offline mode</span>
              <span>Showing your latest saved forecast (Updated 8:12 AM)</span>
            </div>
          </div>
          <button
            onClick={() => setIsOffline(false)}
            className="text-[11px] font-bold text-amber-800 underline hover:text-amber-950 px-1 cursor-pointer"
          >
            Reconnect
          </button>
        </div>
      )}

      {/* ─── Top Header: Greeting, Location Chip, Notifications ─── */}
      <div className="px-5 pt-3 pb-2 flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">
            Today’s Mausam
          </p>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">
            Good morning, {userProfile.name?.split(' ')[0] || 'Manvi'}
          </h1>
        </div>

        <div className="flex items-center gap-2">
          {/* Location Chip Dropdown */}
          <button
            onClick={() => setIsLocationModalOpen(true)}
            className="h-10 px-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs text-xs font-bold text-slate-800 flex items-center gap-1.5 hover:bg-slate-50 transition-all cursor-pointer"
          >
            <MapPin className="w-3.5 h-3.5 text-[#1A4FA0]" />
            <span className="max-w-[125px] truncate">
              {weatherData.location.nameEn || 'Vasundhara, Ghaziabad'}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {/* Notification Bell */}
          <button
            onClick={() => navigate('notif-center')}
            className="w-10 h-10 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex items-center justify-center text-slate-700 hover:text-slate-900 relative cursor-pointer"
            title="Notification Center"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white" />
          </button>
        </div>
      </div>

      {/* ─── Active Persona Selector Bar (Dynamic Personalization Demo & Switcher) ─── */}
      <div className="px-5 pt-1 pb-2">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
            <span>Focus:</span>
            <span className="text-[#1A4FA0] font-black">
              {dashboard.primaryConfig.emoji} {dashboard.primaryConfig.label}
            </span>
          </span>
          <span className="text-[10px] font-bold text-slate-500">
            {dashboard.isSingle ? 'Tailored View' : `${dashboard.activeIds.length} Selected`}
          </span>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto hide-scroll pb-1 -mx-5 px-5">
          {(Object.keys(ALL_PERSONA_CONFIGS) as InterestId[]).map((pid) => {
            const p = ALL_PERSONA_CONFIGS[pid];
            const isCurrent = dashboard.activeIds.includes(pid);
            return (
              <button
                key={pid}
                onClick={() => {
                  updateUserProfile({ interests: [pid] });
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
                  isCurrent
                    ? 'bg-[#1A4FA0] text-white shadow-xs scale-102'
                    : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200/85 hover:border-slate-300'
                }`}
              >
                <span>{p.emoji}</span>
                <span>{p.label.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-5 space-y-4">
        {/* ─── Universal Weather Hero (Common for all users) ─── */}
        <div
          className="relative rounded-[32px] p-6 shadow-md border border-sky-100 overflow-hidden text-slate-900"
          style={{
            background:
              'linear-gradient(145deg, #FFFFFF 0%, #F0F7FF 55%, #FEF9EE 100%)',
          }}
        >
          {/* Subtle Sun Atmosphere Glow */}
          <div className="absolute -top-12 -right-12 w-44 h-44 rounded-full bg-amber-200/40 blur-2xl pointer-events-none" />
          <div className="absolute -bottom-8 -left-8 w-44 h-44 rounded-full bg-sky-200/30 blur-2xl pointer-events-none" />

          {/* Weather Content Row */}
          <div className="relative z-10 flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-baseline gap-2">
                <span className="text-5xl sm:text-6xl font-black text-slate-900 tracking-tighter">
                  29°
                </span>
                <span className="text-sm font-bold text-slate-500">
                  Feels like 31°
                </span>
              </div>

              <div className="text-lg font-extrabold text-slate-800">
                Partly Cloudy
              </div>

              <div className="text-xs font-semibold text-slate-500">
                High 33° · Low 25°
              </div>
            </div>

            {/* Large Polished Weather Illustration */}
            <div className="relative w-28 h-28 flex items-center justify-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 shadow-lg shadow-amber-300/40 flex items-center justify-center">
                <Sun className="w-9 h-9 text-amber-900/40" />
              </div>

              {/* Dynamic condition pill */}
              <div className="absolute -bottom-1 -left-2 px-3 py-2 rounded-2xl bg-white/95 backdrop-blur-xs border border-white/80 shadow-md flex items-center gap-1.5">
                <CloudRain className="w-4 h-4 text-blue-500" />
                <span className="text-[11px] font-black text-slate-700">Rain 8:30 AM</span>
              </div>
            </div>
          </div>

          {/* Bottom Telemetry Mini Bar */}
          <div className="relative z-10 pt-4 mt-4 border-t border-slate-200/60 grid grid-cols-3 gap-2 text-center text-xs">
            <div>
              <span className="text-slate-500 block text-[10px] font-bold">AQI</span>
              <span className="font-black text-slate-900">128 Moderate</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] font-bold">HUMIDITY</span>
              <span className="font-black text-slate-900">82%</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] font-bold">WIND</span>
              <span className="font-black text-slate-900">14 km/h E</span>
            </div>
          </div>
        </div>

        {/* ─── DYNAMIC HERO INSIGHT CARD (Purely Personalized to Selected Persona) ─── */}
        <div className="pt-1">
          <div className="flex items-center justify-between mb-2.5">
            <h2 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#1A4FA0]" />
              <span>Here’s what matters to you today</span>
            </h2>
            <span className="text-[11px] font-bold text-[#1A4FA0]">
              {dashboard.primaryConfig.label}
            </span>
          </div>

          <div className="p-5 rounded-3xl bg-blue-50/85 border border-blue-200/90 shadow-2xs space-y-3.5">
            <div className="flex items-start gap-3">
              <div
                className={`w-11 h-11 rounded-2xl ${dashboard.heroInsight.iconBg} ${dashboard.heroInsight.iconColor} flex items-center justify-center shrink-0 shadow-xs`}
              >
                <HeroIcon className="w-6 h-6" />
              </div>
              <div className="space-y-1 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 leading-snug">
                    {dashboard.heroInsight.title}
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-blue-200/80 text-[#0A2A65] text-[10px] font-bold uppercase shrink-0">
                    {dashboard.heroInsight.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-600 font-medium leading-relaxed">
                  {dashboard.heroInsight.subtitle}
                </p>
                {dashboard.heroInsight.secondaryNote && (
                  <p className="text-[11px] font-semibold text-emerald-800 bg-emerald-50/80 px-2.5 py-1 rounded-xl border border-emerald-200/60 mt-1.5">
                    {dashboard.heroInsight.secondaryNote}
                  </p>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 pt-1">
              <button
                onClick={handleActionClick}
                className="flex-1 py-2.5 px-3 rounded-2xl bg-[#1A4FA0] hover:bg-[#15438E] text-white text-xs font-bold shadow-xs transition-all active:scale-[0.98] cursor-pointer text-center"
              >
                {dashboard.heroInsight.actionLabel}
              </button>

              <button
                onClick={() => setIsWhyOpen(true)}
                className="py-2.5 px-4 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold border border-slate-200/90 shadow-2xs transition-all active:scale-[0.98] cursor-pointer flex items-center gap-1"
              >
                <Info className="w-3.5 h-3.5 text-blue-600" />
                <span>Why?</span>
              </button>
            </div>
          </div>
        </div>

        {/* ─── DYNAMIC PERSONALIZED QUICK CARDS (Relevant only to active persona) ─── */}
        <div className="grid grid-cols-2 gap-3">
          {dashboard.quickCards.map((card) => {
            const IconComponent = card.icon;
            return (
              <div
                key={card.id}
                onClick={() => {
                  if (card.route) navigate(card.route as any);
                }}
                className={`p-4 rounded-3xl bg-white border border-slate-200/90 shadow-2xs hover:shadow-xs transition-all space-y-2 ${
                  card.route ? 'cursor-pointer' : ''
                }`}
              >
                <div className="flex items-center justify-between">
                  <div
                    className={`w-9 h-9 rounded-2xl ${card.iconBg} ${card.iconColor} flex items-center justify-center`}
                  >
                    <IconComponent className="w-4 h-4" />
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${card.badgeColor}`}
                  >
                    {card.badge}
                  </span>
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {card.category}
                  </div>
                  <div className="text-sm font-black text-slate-900 mt-0.5">
                    {card.metric}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 font-medium leading-tight">
                    {card.sub}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* ─── SPECIALIZED SECTION BANNER (If Applicable) ─── */}
        {dashboard.specialBanner && (
          <div className="p-4 rounded-3xl bg-gradient-to-r from-blue-50 via-indigo-50/60 to-purple-50 border border-blue-200/80 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/90 text-[#1A4FA0] px-2.5 py-0.5 rounded-full border border-blue-200/60">
                {dashboard.specialBanner.badge}
              </span>
              {dashboard.specialBanner.route && (
                <button
                  onClick={() => navigate(dashboard.specialBanner!.route as any)}
                  className="text-xs font-bold text-[#1A4FA0] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>{dashboard.specialBanner.actionLabel}</span>
                </button>
              )}
            </div>
            <div>
              <h4 className="text-sm font-black text-slate-900">
                {dashboard.specialBanner.title}
              </h4>
              <p className="text-xs text-slate-600 font-medium mt-0.5 leading-relaxed">
                {dashboard.specialBanner.subtitle}
              </p>
            </div>
          </div>
        )}

        {/* ─── "MY DAY" TIMELINE (Dynamic Schedule strictly matching active persona) ─── */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-[#1A4FA0]" />
              <span>My Day • {dashboard.primaryConfig.label}</span>
            </h3>
            <button
              onClick={() => navigate('my-day')}
              className="text-[11px] font-bold text-[#1A4FA0] hover:underline cursor-pointer"
            >
              Full Schedule →
            </button>
          </div>

          {/* Vertical Connector Timeline */}
          <div className="space-y-4 relative pl-3">
            <div className="absolute left-[20px] top-3 bottom-3 w-0.5 bg-slate-200" />

            {dashboard.timelineItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index} className="flex items-start gap-3 relative z-10">
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border ${
                      item.status === 'safe'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : item.status === 'caution'
                        ? 'bg-blue-50 text-blue-700 border-blue-200'
                        : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>

                  <div className="flex-1 space-y-0.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-slate-900">
                          {item.time}
                        </span>
                        <span className="text-xs font-bold text-slate-800">
                          {item.title}
                        </span>
                      </div>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          item.status === 'safe'
                            ? 'bg-emerald-100/70 text-emerald-800'
                            : item.status === 'caution'
                            ? 'bg-blue-100/70 text-[#0A2A65]'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {item.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
                      {item.sub}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ─── HOURLY FORECAST (Row with persona highlight cues) ─── */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
              Hourly Forecast
            </h3>
            <span className="text-[11px] font-semibold text-slate-500">
              Next 24 Hours
            </span>
          </div>

          <div className="flex gap-2.5 overflow-x-auto hide-scroll pb-1 -mx-5 px-5">
            {hourlyData.map((hour, idx) => (
              <div
                key={idx}
                className={`flex flex-col items-center justify-between p-3 rounded-2xl min-w-[76px] text-center border transition-all shrink-0 ${
                  hour.isCurrent
                    ? 'bg-[#1A4FA0] text-white border-[#1A4FA0] shadow-sm'
                    : hour.isHighlight
                    ? 'bg-blue-50/90 text-slate-900 border-blue-300 ring-1 ring-blue-300/60'
                    : 'bg-white text-slate-900 border-slate-200/90'
                }`}
              >
                <div
                  className={`text-[11px] font-bold ${
                    hour.isCurrent ? 'text-blue-100' : 'text-slate-500'
                  }`}
                >
                  {hour.time}
                </div>

                <div className="text-xl my-1.5">{hour.icon}</div>

                <div className="text-sm font-black">{hour.temp}</div>

                {hour.label ? (
                  <div className="text-[10px] font-extrabold text-[#1A4FA0] bg-white px-1.5 py-0.5 rounded-md mt-1 shadow-2xs">
                    {hour.label}
                  </div>
                ) : (
                  <div
                    className={`text-[10px] font-bold mt-1 flex items-center justify-center gap-0.5 ${
                      hour.isCurrent ? 'text-blue-200' : 'text-slate-400'
                    }`}
                  >
                    <CloudRain className="w-2.5 h-2.5" />
                    <span>{hour.rain}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ─── Interactive "Why?" Bottom Sheet Modal ─── */}
      <WeatherReasonSheet
        isOpen={isWhyOpen}
        onClose={() => setIsWhyOpen(false)}
        title="Why are we suggesting this?"
        context={dashboard.heroInsight.whyContext}
        data={{
          rainProbability: '78%',
          visibility: 'Moderate (7.0 km)',
          humidity: '82%',
          temperature: '29°C',
          source: 'IMD AWS Hindon & Safdarjung Radar Network',
          lastUpdated: '5 minutes ago',
          factors: dashboard.heroInsight.whyFactors,
        }}
      />

      {/* ─── Interactive Advisory Bottom Sheet Modal (Persona-Specific Guidance) ─── */}
      {isAdvisoryOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="absolute inset-0" onClick={() => setIsAdvisoryOpen(false)} />
          <div className="relative w-full max-w-md bg-white rounded-t-[32px] sm:rounded-3xl p-6 shadow-2xl border border-slate-100 flex flex-col z-10 animate-in slide-in-from-bottom-6 duration-250">
            <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto mb-4" />
            <div className="flex items-center gap-2.5 mb-4">
              <div
                className={`w-10 h-10 rounded-2xl ${dashboard.heroInsight.iconBg} ${dashboard.heroInsight.iconColor} flex items-center justify-center font-bold`}
              >
                <HeroIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-slate-900">
                  {dashboard.heroInsight.advisoryHeadline}
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Optimized for {dashboard.primaryConfig.label}
                </p>
              </div>
            </div>

            <div className="space-y-2.5 mb-5 text-xs text-slate-700 max-h-[50vh] overflow-y-auto pr-1">
              {dashboard.heroInsight.advisoryItems.map((item, i) => (
                <div
                  key={i}
                  className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-start gap-2.5"
                >
                  <CheckCircle2
                    className={`w-4 h-4 shrink-0 mt-0.5 ${
                      item.iconType === 'emerald'
                        ? 'text-emerald-600'
                        : item.iconType === 'blue'
                        ? 'text-blue-600'
                        : item.iconType === 'indigo'
                        ? 'text-indigo-600'
                        : 'text-amber-600'
                    }`}
                  />
                  <div>
                    <strong className="block text-slate-900">{item.title}</strong>
                    <span className="text-slate-600">{item.desc}</span>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setIsAdvisoryOpen(false)}
              className="w-full py-3.5 rounded-2xl bg-[#1A4FA0] text-white font-bold text-sm shadow-md cursor-pointer hover:bg-[#15438E] transition-all"
            >
              Acknowledge & Dismiss
            </button>
          </div>
        </div>
      )}

      {/* ─── Searchable IMD Location Station Modal ─── */}
      <LocationPickerModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
      />
    </div>
  );
}
