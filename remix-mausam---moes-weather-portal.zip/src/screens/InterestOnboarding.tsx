import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  RotateCcw,
  Check,
  X,
  Heart,
  ArrowRight,
  Flame,
  Wind,
  CloudRain,
  Sun,
  Activity,
  Compass,
  Trees,
  PartyPopper,
  Sparkles,
} from 'lucide-react';

interface InterestCard {
  id: string;
  emoji: string;
  title: string;
  benefit: string;
  weatherCue: string;
  gradient: string;
  accentColor: string;
  badge: string;
}

const CARDS: InterestCard[] = [
  {
    id: 'fitness',
    emoji: '🏃',
    title: 'Fitness & Running',
    benefit: 'Find the best time for outdoor workouts and avoid thermal exhaustion.',
    weatherCue: '⚡ Optimal window: 06:10 AM • 23°C • Low UV',
    gradient: 'linear-gradient(145deg, #EFF6FF 0%, #DBEAFE 100%)',
    accentColor: '#1A4FA0',
    badge: 'Popular for Runners',
  },
  {
    id: 'health',
    emoji: '❤️',
    title: 'Health & Air Quality',
    benefit: 'Stay aware of AQI, pollen, UV index and humidity before stepping out.',
    weatherCue: '🍃 Live AQI 128 (Moderate) • Mask Advisory',
    gradient: 'linear-gradient(145deg, #ECFDF5 0%, #D1FAE5 100%)',
    accentColor: '#059669',
    badge: 'Family & Senior Wellness',
  },
  {
    id: 'commute',
    emoji: '💼',
    title: 'Daily Commute',
    benefit: 'Get rain, fog and heat alerts before leaving for office or campus.',
    weatherCue: '☔ Rain alert 8:30 AM • Arterial traffic delay',
    gradient: 'linear-gradient(145deg, #F0F9FF 0%, #E0F2FE 100%)',
    accentColor: '#0284C7',
    badge: 'Office Routine',
  },
  {
    id: 'family',
    emoji: '👨‍👩‍👧',
    title: 'Family & School',
    benefit: 'Plan school runs and afternoon pick-ups around changing weather.',
    weatherCue: '☀️ High UV window 12–3 PM • Shade & hydration needed',
    gradient: 'linear-gradient(145deg, #FFFBEB 0%, #FEF3C7 100%)',
    accentColor: '#D97706',
    badge: 'Parents & Kids',
  },
  {
    id: 'travel',
    emoji: '✈️',
    title: 'Travel & Trips',
    benefit: 'Prepare intercity journeys with weather-aware packing recommendations.',
    weatherCue: '🌄 Route radar active: Delhi to Jaipur clear',
    gradient: 'linear-gradient(145deg, #F5F3FF 0%, #EDE9FE 100%)',
    accentColor: '#7C3AED',
    badge: 'Weekend Explorer',
  },
  {
    id: 'beach',
    emoji: '🏖️',
    title: 'Beach & Outdoor',
    benefit: 'Check wind speed, tide levels and outdoor environmental safety conditions.',
    weatherCue: '🌊 Coastal breeze 14 km/h • Wave height 1.1m',
    gradient: 'linear-gradient(145deg, #ECFEFF 0%, #CFFAFE 100%)',
    accentColor: '#0891B2',
    badge: 'Water & Sports',
  },
  {
    id: 'farming',
    emoji: '🌱',
    title: 'Farming & Gardening',
    benefit: 'Track rainfall forecast and weather-based soil growing conditions.',
    weatherCue: '🌾 Soil moisture 68% • Ideal spray window Friday',
    gradient: 'linear-gradient(145deg, #F0FDF4 0%, #DCFCE7 100%)',
    accentColor: '#16A34A',
    badge: 'GKMS Agromet',
  },
  {
    id: 'events',
    emoji: '🎉',
    title: 'Events & Gatherings',
    benefit: 'Plan outdoor celebrations and festivals with higher weather confidence.',
    weatherCue: '🎪 94% dry probability for evening gathering',
    gradient: 'linear-gradient(145deg, #FFF1F2 0%, #FFE4E6 100%)',
    accentColor: '#E11D48',
    badge: 'Social & Weekends',
  },
];

export default function InterestOnboarding({
  navigate,
  onComplete,
}: {
  navigate: Navigate;
  onComplete: (ids: string[]) => void;
}) {
  const { updateUserProfile } = useWeather();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [interestedIds, setInterestedIds] = useState<string[]>([]);
  const [history, setHistory] = useState<{ id: string; action: 'add' | 'skip' }[]>([]);
  const [dragOffset, setDragOffset] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const [startX, setStartX] = useState(0);

  const currentCard = CARDS[currentIndex];
  const isFinished = currentIndex >= CARDS.length;

  const handleAction = (action: 'add' | 'skip') => {
    if (isFinished) return;
    const card = CARDS[currentIndex];
    if (action === 'add') {
      setInterestedIds((prev) => [...prev, card.id]);
    }
    setHistory((prev) => [...prev, { id: card.id, action }]);
    setCurrentIndex((prev) => prev + 1);
    setDragOffset(0);

    if (currentIndex + 1 >= CARDS.length) {
      setTimeout(() => {
        const finalSelected = action === 'add' ? [...interestedIds, card.id] : interestedIds;
        updateUserProfile({ interests: finalSelected });
        onComplete(finalSelected);
      }, 400);
    }
  };

  const handleUndo = () => {
    if (currentIndex === 0 || history.length === 0) return;
    const last = history[history.length - 1];
    setHistory((prev) => prev.slice(0, -1));
    if (last.action === 'add') {
      setInterestedIds((prev) => prev.filter((id) => id !== last.id));
    }
    setCurrentIndex((prev) => prev - 1);
    setDragOffset(0);
  };

  // Touch / Drag event handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    setIsSwiping(true);
    setStartX(e.touches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isSwiping) return;
    const currentX = e.touches[0].clientX;
    setDragOffset(currentX - startX);
  };

  const handleTouchEnd = () => {
    if (!isSwiping) return;
    setIsSwiping(false);
    if (dragOffset > 80) {
      handleAction('add');
    } else if (dragOffset < -80) {
      handleAction('skip');
    }
    setDragOffset(0);
  };

  return (
    <div
      className="min-h-screen flex flex-col justify-between px-6 pt-5 pb-8 relative select-none overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #F8FAFC 0%, #EFF6FF 100%)' }}
    >
      {/* Top Header & Progress */}
      <div className="space-y-4">
        <div>
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-2">
            <span className="text-[#1A4FA0]">Step 2 of 4 • Discovery</span>
            <span>
              {Math.min(currentIndex + 1, CARDS.length)} of {CARDS.length}
            </span>
          </div>
          <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#1A4FA0] rounded-full transition-all duration-300"
              style={{
                width: `${((currentIndex + 1) / CARDS.length) * 100}%`,
              }}
            />
          </div>
        </div>

        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            What matters to you?
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">
            Swipe right for what you care about, left to skip.
          </p>
        </div>
      </div>

      {/* ─── Tinder-Style Card Stack Area ─── */}
      <div className="relative my-auto py-6 flex items-center justify-center min-h-[360px]">
        {!isFinished ? (
          <div className="relative w-full max-w-xs flex items-center justify-center">
            {/* Background stacked card (peek preview) */}
            {currentIndex + 1 < CARDS.length && (
              <div
                className="absolute inset-x-3 top-3 bottom-0 rounded-[32px] bg-white border border-slate-200/80 shadow-sm opacity-60 scale-95 pointer-events-none"
                style={{
                  transform: 'translateY(12px) scale(0.95)',
                }}
              />
            )}
            {currentIndex + 2 < CARDS.length && (
              <div
                className="absolute inset-x-6 top-6 bottom-0 rounded-[32px] bg-white border border-slate-200/50 shadow-2xs opacity-30 scale-90 pointer-events-none"
                style={{
                  transform: 'translateY(24px) scale(0.90)',
                }}
              />
            )}

            {/* Top Active Card */}
            <div
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              style={{
                background: currentCard.gradient,
                transform: `translateX(${dragOffset}px) rotate(${dragOffset * 0.08}deg)`,
                transition: isSwiping ? 'none' : 'transform 0.25s ease',
              }}
              className="relative w-full rounded-[32px] p-6 shadow-xl border border-white/80 cursor-grab active:cursor-grabbing flex flex-col justify-between min-h-[350px] z-10"
            >
              {/* Swipe badges feedback */}
              {dragOffset > 40 && (
                <div className="absolute top-5 left-5 px-3 py-1 rounded-xl bg-emerald-600 text-white font-extrabold text-xs uppercase tracking-wider shadow-md transform -rotate-12 animate-pulse">
                  Interested ❤️
                </div>
              )}
              {dragOffset < -40 && (
                <div className="absolute top-5 right-5 px-3 py-1 rounded-xl bg-rose-600 text-white font-extrabold text-xs uppercase tracking-wider shadow-md transform rotate-12 animate-pulse">
                  Skip ❌
                </div>
              )}

              {/* Card Top Category & Badge */}
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full bg-white/80 text-[11px] font-bold text-slate-700 shadow-2xs border border-white/60">
                  {currentCard.badge}
                </span>
                <span className="text-xs font-bold text-slate-400">
                  {currentIndex + 1} / {CARDS.length}
                </span>
              </div>

              {/* Card Main Visual & Illustration */}
              <div className="text-center my-3">
                <div className="w-20 h-20 mx-auto rounded-3xl bg-white shadow-md border border-white/80 flex items-center justify-center text-4xl mb-3">
                  {currentCard.emoji}
                </div>
                <h3 className="text-xl font-black text-slate-900 tracking-tight">
                  {currentCard.title}
                </h3>
                <p className="text-xs text-slate-600 font-medium mt-1 leading-relaxed px-1">
                  {currentCard.benefit}
                </p>
              </div>

              {/* Weather Cue Pill */}
              <div className="p-3 rounded-2xl bg-white/90 border border-white shadow-2xs text-[11px] font-bold text-slate-700 text-center flex items-center justify-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>{currentCard.weatherCue}</span>
              </div>
            </div>
          </div>
        ) : (
          /* Finished State */
          <div className="text-center p-6 bg-white rounded-3xl border border-slate-200 shadow-sm max-w-xs space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center font-bold">
              <Check className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-black text-slate-900">
              Preferences Recorded!
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              You selected {interestedIds.length} key areas to personalize your weather alerts.
            </p>
            <button
              onClick={() => {
                updateUserProfile({ interests: interestedIds });
                onComplete(interestedIds);
              }}
              className="w-full py-3 rounded-2xl bg-[#1A4FA0] text-white font-bold text-xs shadow-md"
            >
              Continue to Routine Setup
            </button>
          </div>
        )}
      </div>

      {/* ─── Control Buttons: Skip, Undo, Add ─── */}
      <div className="pt-2 space-y-3">
        <div className="flex items-center justify-center gap-4">
          {/* Left: Skip Button */}
          <button
            onClick={() => handleAction('skip')}
            disabled={isFinished}
            className="w-16 h-16 rounded-full bg-white hover:bg-rose-50 text-rose-500 font-bold border border-slate-200/90 shadow-md flex items-center justify-center transition-all active:scale-90 cursor-pointer disabled:opacity-40"
            title="Skip this item"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Middle: Undo Button */}
          <button
            onClick={handleUndo}
            disabled={currentIndex === 0}
            className="w-11 h-11 rounded-full bg-white hover:bg-slate-100 text-slate-500 border border-slate-200/90 shadow-2xs flex items-center justify-center transition-all active:scale-90 cursor-pointer disabled:opacity-30"
            title="Undo last action"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Right: Add / Interested Button */}
          <button
            onClick={() => handleAction('add')}
            disabled={isFinished}
            className="w-16 h-16 rounded-full text-white font-bold shadow-lg flex items-center justify-center transition-all active:scale-90 cursor-pointer disabled:opacity-40"
            style={{
              background: 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
              boxShadow: '0 6px 20px -2px rgba(16, 185, 129, 0.4)',
            }}
            title="Add to my interests"
          >
            <Heart className="w-6 h-6 fill-white" />
          </button>
        </div>

        {/* Text Skip or Direct Continue */}
        <div className="text-center pt-1 space-y-2">
          {/* Quick Select 1 Persona Pills */}
          <div className="pt-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
              Quick test single persona
            </span>
            <div className="flex items-center justify-center gap-1.5 flex-wrap">
              {CARDS.map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    updateUserProfile({ interests: [c.id] });
                    onComplete([c.id]);
                  }}
                  className="px-2 py-1 rounded-lg bg-white/90 hover:bg-white text-[11px] font-bold text-slate-700 border border-slate-200 shadow-2xs hover:border-[#1A4FA0] transition-all cursor-pointer"
                  title={`Select only ${c.title}`}
                >
                  <span>{c.emoji}</span> {c.title.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => {
              const res = interestedIds.length > 0 ? interestedIds : ['commute'];
              updateUserProfile({
                interests: res,
              });
              onComplete(res);
            }}
            className="text-xs font-bold text-slate-500 hover:text-slate-800 pt-1 block mx-auto cursor-pointer"
          >
            Skip remaining & continue →
          </button>
        </div>
      </div>
    </div>
  );
}
