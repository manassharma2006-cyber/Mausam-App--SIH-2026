import React from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  ArrowLeft,
  Wheat,
  Droplets,
  Layers,
  Sprout,
  AlertCircle,
  CheckCircle2,
  Calendar,
  Thermometer,
  Wind,
  ShieldCheck,
} from 'lucide-react';

export default function KrishiMausam({ navigate }: { navigate: Navigate }) {
  const { weatherData, language, formatTemp } = useWeather();
  const soil = weatherData.soilMoisture || {
    depth10cm: { value: 34, statusEn: 'Optimal', statusHi: 'उपयुक्त', color: 'bg-emerald-500' },
    depth30cm: { value: 46, statusEn: 'High Moisture', statusHi: 'पर्याप्त नमी', color: 'bg-blue-500' },
    depth60cm: { value: 52, statusEn: 'Saturated', statusHi: 'संतृप्त', color: 'bg-indigo-500' },
    fieldCapacityPercent: 78,
    evapotranspiration: 4.2,
  };

  const cropAdvisories = weatherData.agrometAdvisories || [
    {
      cropEn: 'Wheat (गेहूं)',
      cropHi: 'गेहूं (Triticum aestivum)',
      stageEn: 'Crown Root Initiation (CRI)',
      stageHi: 'ताज जड़ निर्माण अवस्था',
      sowingAdviceEn: 'Favorable soil temperature (18-22°C) for tillering. Maintain light surface moisture.',
      sowingAdviceHi: 'कल्ले फूटने हेतु अनुकूल तापमान। खेत में हल्की नमी बनाए रखें।',
      irrigationAdviceEn: 'Postpone irrigation by 48 hours in view of forecasted rain.',
      irrigationAdviceHi: 'पूर्वानुमानित वर्षा को देखते हुए सिंचाई 48 घंटे के लिए स्थगित करें।',
      sprayAdviceEn: 'Avoid foliar weedicides during windy afternoon hours (> 12 km/h).',
      sprayAdviceHi: 'दोपहर की तेज हवाओं में खरपतवारनाशी छिड़काव न करें।',
    },
    {
      cropEn: 'Mustard (सरसों)',
      cropHi: 'सरसों (Brassica juncea)',
      stageEn: 'Pod Formation / Flowering',
      stageHi: 'फूल व फली निर्माण',
      sowingAdviceEn: 'Monitor for aphid (चेपा) infestation due to continuous high relative humidity (> 75%).',
      sowingAdviceHi: 'लगातार उच्च आर्द्रता (>75%) के कारण माहू कीट (चेपा) की निगरानी रखें।',
      irrigationAdviceEn: 'Ensure proper field drainage to prevent root waterlogging.',
      irrigationAdviceHi: 'खेत में जल निकास की उचित व्यवस्था रखें ताकि जड़ों को नुकसान न हो।',
      sprayAdviceEn: 'Spray Neem oil formulation (5ml/L) in clear morning hours.',
      sprayAdviceHi: 'मौसम साफ रहने पर सुबह नीम तेल का छिड़काव करें।',
    },
  ];

  return (
    <div className="min-h-screen text-slate-900 pb-8" style={{ background: 'var(--m-bg)' }}>
      {/* Deep Emerald Forest Header */}
      <div
        className="text-white px-5 pt-3 pb-6 rounded-b-3xl shadow-lg relative overflow-hidden"
        style={{
          background: 'linear-gradient(175deg, #064E3B 0%, #065F46 50%, #047857 100%)',
        }}
      >
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-1 text-xs font-bold text-emerald-200 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </button>
          <span className="text-[11px] font-bold text-amber-300 font-emblem tracking-wider">
            GKMS • ICAR • MoES
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
            <Wheat className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-white">Krishi Mausam Sewa</h1>
            <p className="text-xs text-emerald-100 font-devanagari">
              ग्रामीण कृषि मौसम सेवा • जिला कृषि मौसम परामर्श
            </p>
          </div>
        </div>
      </div>

      <div className="px-5 py-4 space-y-4">
        {/* Soil Moisture 3-Layer Telemetry */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-700" />
              <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
                Multi-Depth Soil Moisture Sensors
              </h3>
            </div>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              AWS Probes Active
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center mb-3">
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold text-slate-500 block">10 cm (Topsoil)</span>
              <span className="text-xl font-black text-slate-900 block my-1">
                {soil.depth10cm.value}%
              </span>
              <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                {language === 'hi' ? soil.depth10cm.statusHi : soil.depth10cm.statusEn}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold text-slate-500 block">30 cm (Root Zone)</span>
              <span className="text-xl font-black text-slate-900 block my-1">
                {soil.depth30cm.value}%
              </span>
              <span className="text-[9px] font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-full">
                {language === 'hi' ? soil.depth30cm.statusHi : soil.depth30cm.statusEn}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold text-slate-500 block">60 cm (Subsoil)</span>
              <span className="text-xl font-black text-slate-900 block my-1">
                {soil.depth60cm.value}%
              </span>
              <span className="text-[9px] font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-full">
                {language === 'hi' ? soil.depth60cm.statusHi : soil.depth60cm.statusEn}
              </span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs text-slate-600">
            <span>Evapotranspiration (वाष्पोत्सर्जन)</span>
            <span className="font-bold text-slate-900">{soil.evapotranspiration} mm/day</span>
          </div>
        </div>

        {/* Chemical Spray Safety Index */}
        <div className="p-4 rounded-3xl bg-amber-50 border border-amber-200 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed">
            <span className="font-extrabold text-amber-950 block mb-0.5">
              Pesticide Spray Advisory (कीटनाशक छिड़काव अलर्ट):
            </span>
            Winds are forecast to pick up to 14 km/h with 45% rain chance this evening. Postpone spray operations until tomorrow 07:00 AM to avoid chemical wastage.
          </div>
        </div>

        {/* GKMS Crop Bulletins */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Regional Crop Bulletins
            </span>
            <span className="text-[10px] text-slate-500">ICAR GKMS Bulletin</span>
          </div>

          {cropAdvisories.map((advisory, idx) => (
            <div
              key={idx}
              className="p-4 rounded-3xl bg-white border border-slate-200/80 shadow-sm space-y-2.5"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div>
                  <h4 className="font-extrabold text-sm text-emerald-950">
                    {language === 'hi' ? advisory.cropHi : advisory.cropEn}
                  </h4>
                  <span className="text-[10px] text-slate-500">
                    Stage: {language === 'hi' ? advisory.stageHi : advisory.stageEn}
                  </span>
                </div>
                <span className="p-2 rounded-xl bg-emerald-100 text-emerald-800 font-bold text-xs">
                  🌾 Agromet
                </span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="text-slate-700">
                  <strong className="text-slate-900">Sowing / Tillering:</strong>{' '}
                  {language === 'hi' ? advisory.sowingAdviceHi : advisory.sowingAdviceEn}
                </div>
                <div className="text-slate-700">
                  <strong className="text-slate-900">Irrigation:</strong>{' '}
                  {language === 'hi' ? advisory.irrigationAdviceHi : advisory.irrigationAdviceEn}
                </div>
                <div className="text-slate-700">
                  <strong className="text-slate-900">Plant Protection:</strong>{' '}
                  {language === 'hi' ? advisory.sprayAdviceHi : advisory.sprayAdviceEn}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Mandi Weather & Grain Storage Guidance */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
              Mandi Weather & Grain Protection
            </h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Ensure harvested grains in open APMC mandis are covered with tarpaulin sheets before 04:00 PM today due to gusty thunderstorm potential.
          </p>
        </div>
      </div>
    </div>
  );
}
