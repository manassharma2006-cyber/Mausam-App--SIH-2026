import React, { useState, useEffect, useRef } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import MausamBrandMark from '../components/MausamBrandMark';
import { ArrowLeft, ArrowRight, ShieldCheck, Sun, Cloud, Sparkles, Check, RefreshCw } from 'lucide-react';

export default function Login({ navigate }: { navigate: Navigate }) {
  const { userProfile, updateUserProfile } = useWeather();

  // Mode: 'options' -> 'mobile' -> 'otp'
  const [mode, setMode] = useState<'options' | 'mobile' | 'otp'>('options');
  const [countryCode, setCountryCode] = useState('+91');
  const [phoneNumber, setPhoneNumber] = useState('9876543210');
  const [otp, setOtp] = useState(['2', '6', '0', '7', '1', '9']);
  const [resendTimer, setResendTimer] = useState(27);
  const [canResend, setCanResend] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  // OTP input refs
  const otpInputsRef = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (mode === 'otp' && resendTimer > 0) {
      interval = setInterval(() => {
        setResendTimer((prev) => {
          if (prev <= 1) {
            setCanResend(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [mode, resendTimer]);

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length < 10) return;
    updateUserProfile({ phone: `${countryCode} ${phoneNumber}` });
    setMode('otp');
    setResendTimer(27);
    setCanResend(false);
  };

  const handleOtpChange = (index: number, value: string) => {
    // Check if pasted full OTP
    if (value.length > 1) {
      const cleanDigits = value.replace(/\D/g, '').slice(0, 6).split('');
      const newOtp = [...otp];
      cleanDigits.forEach((d, i) => {
        if (i < 6) newOtp[i] = d;
      });
      setOtp(newOtp);
      const nextIdx = Math.min(cleanDigits.length, 5);
      otpInputsRef.current[nextIdx]?.focus();
      return;
    }

    const digit = value.replace(/\D/g, '');
    const newOtp = [...otp];
    newOtp[index] = digit;
    setOtp(newOtp);

    // Auto advance focus to next box
    if (digit && index < 5) {
      otpInputsRef.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpInputsRef.current[index - 1]?.focus();
    }
  };

  const handleVerifyOtp = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      navigate('profile-setup');
    }, 450);
  };

  const handleResend = () => {
    if (!canResend) return;
    setResendTimer(30);
    setCanResend(false);
    setOtp(['', '', '', '', '', '']);
    otpInputsRef.current[0]?.focus();
  };

  return (
    <div
      className="min-h-screen flex flex-col justify-between px-6 pt-5 pb-8 relative overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, #F0F7FF 0%, #E8F2FF 50%, #F8FAFC 100%)',
      }}
    >
      {/* Soft Ambient Background Elements */}
      <div className="absolute -top-10 -right-10 w-64 h-64 rounded-full bg-sky-200/40 blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 -left-10 w-64 h-64 rounded-full bg-amber-100/50 blur-3xl pointer-events-none" />

      {/* Top Bar Navigation */}
      <div className="relative z-10 flex items-center justify-between pt-1">
        {mode !== 'options' ? (
          <button
            onClick={() => setMode(mode === 'otp' ? 'mobile' : 'options')}
            className="flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-xl bg-white/70 border border-slate-200/70 shadow-2xs"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <MausamBrandMark size="sm" />
            <span className="font-extrabold text-sm text-slate-800 tracking-tight">
              Mausam
            </span>
          </div>
        )}

        <button
          onClick={() => navigate('home')}
          className="text-xs font-semibold text-[#1A4FA0] hover:text-[#0A2A65] px-2.5 py-1"
        >
          Skip to App
        </button>
      </div>

      {/* ────────────────────────────────────────────────────────── */}
      {/* MODE 1: WELCOME & LOGIN OPTIONS                          */}
      {/* ────────────────────────────────────────────────────────── */}
      {mode === 'options' && (
        <div className="relative z-10 my-auto py-6 flex flex-col items-center text-center">
          {/* Brand Mark with Weather Aura */}
          <div className="mb-6 relative">
            <MausamBrandMark size="md" />
            <div className="absolute -bottom-2 -right-3 p-1 rounded-lg bg-amber-50 border border-amber-200 text-amber-600 shadow-2xs">
              <Sun className="w-3.5 h-3.5" />
            </div>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mb-2">
            Welcome to Mausam
          </h2>

          <p className="text-sm text-slate-600 max-w-xs leading-relaxed mb-8 font-medium">
            Your weather, personalized around your daily routine, commute, and wellbeing.
          </p>

          {/* Authentication Actions */}
          <div className="w-full space-y-3.5 max-w-sm">
            {/* Google Authentication Button */}
            <button
              onClick={() => navigate('profile-setup')}
              className="w-full h-13.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-bold text-sm flex items-center justify-center gap-3 border border-slate-200/90 shadow-sm transition-all active:scale-[0.98] cursor-pointer"
            >
              {/* Google G Logo SVG */}
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            {/* Mobile Number Login Button */}
            <button
              onClick={() => setMode('mobile')}
              className="w-full h-13.5 rounded-2xl bg-sky-50 hover:bg-sky-100 text-[#1A4FA0] font-bold text-sm flex items-center justify-center gap-2 border border-sky-200/80 shadow-2xs transition-all active:scale-[0.98] cursor-pointer"
            >
              <span>Continue with Mobile Number</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-8 text-center">
            <p className="text-xs text-slate-500 font-medium">
              🔒 You stay in control of your preferences & privacy.
            </p>
          </div>
        </div>
      )}

      {/* ────────────────────────────────────────────────────────── */}
      {/* MODE 2: MOBILE NUMBER SCREEN                             */}
      {/* ────────────────────────────────────────────────────────── */}
      {mode === 'mobile' && (
        <div className="relative z-10 my-auto py-4">
          {/* Subtle Weather-Themed Icon Cluster */}
          <div className="flex items-center gap-2 mb-5">
            <div className="w-10 h-10 rounded-2xl bg-white shadow-sm border border-slate-200/80 flex items-center justify-center text-amber-500">
              <Sun className="w-5 h-5" />
            </div>
            <div className="w-10 h-10 rounded-2xl bg-white shadow-sm border border-slate-200/80 flex items-center justify-center text-sky-500">
              <Cloud className="w-5 h-5" />
            </div>
            <div className="w-10 h-10 rounded-2xl bg-white shadow-sm border border-slate-200/80 flex items-center justify-center text-emerald-600">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mb-1.5">
            Let’s get you set up
          </h2>
          <p className="text-sm text-slate-600 mb-6 font-medium">
            Enter your mobile number to continue. We will send a secure verification code.
          </p>

          {/* Form Card */}
          <form onSubmit={handleSendOtp} className="space-y-4">
            <div className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-sm space-y-3">
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">
                Mobile Number
              </label>

              <div className="flex items-center gap-2">
                {/* Country Code Selector */}
                <select
                  value={countryCode}
                  onChange={(e) => setCountryCode(e.target.value)}
                  className="h-13 px-3 rounded-2xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-800 focus:outline-none focus:border-[#1A4FA0] cursor-pointer"
                >
                  <option value="+91">🇮🇳 +91</option>
                  <option value="+1">🇺🇸 +1</option>
                  <option value="+44">🇬🇧 +44</option>
                  <option value="+971">🇦🇪 +971</option>
                </select>

                {/* Phone Input */}
                <input
                  type="tel"
                  maxLength={10}
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                  placeholder="98765 43210"
                  className="flex-1 h-13 px-4 rounded-2xl bg-slate-50 border border-slate-200 text-base font-bold text-slate-900 tracking-wider focus:outline-none focus:border-[#1A4FA0] focus:bg-white transition-all"
                  autoFocus
                  required
                />
              </div>

              <p className="text-[11px] text-slate-500 font-medium">
                Used strictly for nowcast alerts and account sync.
              </p>
            </div>

            {/* Send OTP Button (close to form, not at extreme bottom) */}
            <button
              type="submit"
              disabled={phoneNumber.length < 10}
              className="w-full h-13.5 rounded-2xl text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98] disabled:opacity-50 cursor-pointer"
              style={{
                background: 'linear-gradient(135deg, #1A4FA0 0%, #2563EB 100%)',
              }}
            >
              <span>Send OTP</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* ────────────────────────────────────────────────────────── */}
      {/* MODE 3: 6-DIGIT OTP VERIFICATION SCREEN                  */}
      {/* ────────────────────────────────────────────────────────── */}
      {mode === 'otp' && (
        <div className="relative z-10 my-auto py-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100/70 text-[#1A4FA0] text-xs font-bold mb-3">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Secure IMD Gateway</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mb-1.5">
            Enter verification code
          </h2>

          <p className="text-xs sm:text-sm text-slate-600 mb-6 font-medium">
            We sent a 6-digit code to{' '}
            <strong className="text-slate-900 font-bold">{countryCode} {phoneNumber}</strong>
          </p>

          {/* 6-Digit Segmented Box Component */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-sm mb-5">
            <div className="flex justify-between gap-2 sm:gap-2.5 mb-3">
              {otp.map((digit, idx) => (
                <input
                  key={idx}
                  ref={(el) => (otpInputsRef.current[idx] = el)}
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  value={digit}
                  onChange={(e) => handleOtpChange(idx, e.target.value)}
                  onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                  className={`w-11 h-13 text-center text-xl font-black rounded-xl border-2 transition-all ${
                    digit
                      ? 'border-[#1A4FA0] bg-blue-50/50 text-[#1A4FA0]'
                      : 'border-slate-200 bg-slate-50 text-slate-900'
                  } focus:outline-none focus:border-[#2563EB] focus:bg-white`}
                />
              ))}
            </div>

            {/* Resend OTP Row */}
            <div className="flex items-center justify-between text-xs pt-2">
              <span className="text-slate-500 font-medium">Didn't get the code?</span>
              {canResend ? (
                <button
                  type="button"
                  onClick={handleResend}
                  className="font-bold text-[#1A4FA0] hover:underline flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Resend OTP</span>
                </button>
              ) : (
                <span className="font-semibold text-slate-400">
                  Resend in 00:{resendTimer.toString().padStart(2, '0')}
                </span>
              )}
            </div>
          </div>

          {/* Verify Button (comfortably placed) */}
          <button
            onClick={handleVerifyOtp}
            disabled={otp.join('').length < 6 || isVerifying}
            className="w-full h-13.5 rounded-2xl text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98] disabled:opacity-50 cursor-pointer"
            style={{
              background: 'linear-gradient(135deg, #1A4FA0 0%, #2563EB 100%)',
            }}
          >
            {isVerifying ? (
              <span>Verifying...</span>
            ) : (
              <>
                <span>Verify & Continue</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      )}

      {/* Bottom Subtle Indicator */}
      <div className="relative z-10 flex justify-center">
        <div className="w-24 h-1 rounded-full bg-slate-300" />
      </div>
    </div>
  );
}
