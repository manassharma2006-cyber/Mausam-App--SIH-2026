import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  ArrowLeft,
  Calendar,
  Sun,
  Car,
  Utensils,
  Home as HomeIcon,
  Moon,
  AlertTriangle,
  CheckCircle2,
  Plus,
  Clock,
  Droplets,
} from 'lucide-react';

interface RoutineSlot {
  id: string;
  time: string;
  titleEn: string;
  titleHi: string;
  temp: number;
  rainProb: number;
  uv: number;
  status: 'safe' | 'caution' | 'alert';
  adviceEn: string;
  adviceHi: string;
  icon: typeof Sun;
}

export default function MyDay({ navigate }: { navigate: Navigate }) {
  const { weatherData, formatTemp, language } = useWeather();

  const [slots, setSlots] = useState<RoutineSlot[]>([
    {
      id: '1',
      time: '06:30 AM',
      titleEn: 'Morning Walk / Exercise',
      titleHi: 'सुबह की सैर व व्यायाम',
      temp: weatherData.currentTemp - 4,
      rainProb: 15,
      uv: 1,
      status: 'safe',
      adviceEn: 'Cool and pleasant atmosphere. Optimal for cardiovascular workout.',
      adviceHi: 'ठंडा व सुहावना मौसम। सुबह की सैर के लिए अत्यंत उपयुक्त समय।',
      icon: Sun,
    },
    {
      id: '2',
      time: '08:45 AM',
      titleEn: 'Morning Commute to Office',
      titleHi: 'कार्यालय प्रस्थान',
      temp: weatherData.currentTemp - 1,
      rainProb: 35,
      uv: 4,
      status: 'safe',
      adviceEn: 'Dry roads. Minor traffic delays reported on arterial corridors.',
      adviceHi: 'सड़कें सामान्य हैं। मुख्य मार्गों पर सुगम यातायात।',
      icon: Car,
    },
    {
      id: '3',
      time: '01:15 PM',
      titleEn: 'Afternoon Outdoor Lunch',
      titleHi: 'दोपहर भोजन व विश्राम',
      temp: weatherData.currentTemp + 3,
      rainProb: 20,
      uv: 8,
      status: 'caution',
      adviceEn: 'Peak UV index (8). Seek shaded walkways and stay hydrated.',
      adviceHi: 'पराबैंगनी किरणें तीव्र हैं। धूप से बचें व पर्याप्त पानी पिएं।',
      icon: Utensils,
    },
    {
      id: '4',
      time: '06:00 PM',
      titleEn: 'Evening Commute / Field Work',
      titleHi: 'शाम की वापसी व खेत निरीक्षण',
      temp: weatherData.currentTemp + 1,
      rainProb: 65,
      uv: 2,
      status: 'alert',
      adviceEn: 'Heavy rain probability (65%). Keep rain jacket or umbrella handy.',
      adviceHi: 'वर्षा की 65% संभावना। छाता अवश्य साथ रखें, जलभराव संभव।',
      icon: HomeIcon,
    },
    {
      id: '5',
      time: '09:30 PM',
      titleEn: 'Night Cooling & Sleep',
      titleHi: 'रात्रि विश्राम',
      temp: weatherData.currentTemp - 2,
      rainProb: 20,
      uv: 0,
      status: 'safe',
      adviceEn: 'Calm nocturnal breeze. Temperature settling around comfortable zone.',
      adviceHi: 'हल्की ठंडी हवा। रात्रि में मौसम शांत रहने का अनुमान।',
      icon: Moon,
    },
  ]);

  return (
    <div className="min-h-screen text-slate-900 pb-8" style={{ background: 'var(--m-bg)' }}>
      {/* Top Bar */}
      <div className="bg-[#0A2A65] text-white px-5 pt-3 pb-6 rounded-b-3xl shadow-md">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-1 text-xs font-bold text-blue-200 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </button>
          <span className="text-[11px] font-bold text-amber-300 font-emblem tracking-wider">
            IMD MY DAY ROUTINE
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/15">
            <Calendar className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-white">Daily Weather Schedule</h1>
            <p className="text-xs text-blue-200 font-devanagari">
              आपके दिनचर्या के अनुसार मौसम विश्लेषण एवं दिशा-निर्देश
            </p>
          </div>
        </div>
      </div>

      <div className="px-5 py-4 space-y-3">
        {/* Timeline Items */}
        {slots.map((item, idx) => {
          const Icon = item.icon;
          const statusBg =
            item.status === 'alert'
              ? 'bg-red-50 border-red-200'
              : item.status === 'caution'
              ? 'bg-amber-50 border-amber-200'
              : 'bg-white border-slate-200/80';

          const badgeColor =
            item.status === 'alert'
              ? 'bg-red-100 text-red-800'
              : item.status === 'caution'
              ? 'bg-amber-100 text-amber-800'
              : 'bg-emerald-100 text-emerald-800';

          return (
            <div
              key={item.id}
              className={`p-4 rounded-3xl border shadow-sm transition-all ${statusBg}`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-extrabold text-xs text-slate-900 block">
                      {language === 'hi' ? item.titleHi : item.titleEn}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      {item.time}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-base font-extrabold text-slate-900">
                    {formatTemp(item.temp)}
                  </span>
                  <div className="flex items-center gap-1 text-[10px] font-bold text-blue-700">
                    <Droplets className="w-3 h-3" />
                    <span>{item.rainProb}% rain</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200/60 flex items-start gap-2">
                {item.status === 'alert' ? (
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                )}
                <p className="text-[11px] text-slate-700 leading-tight">
                  {language === 'hi' ? item.adviceHi : item.adviceEn}
                </p>
              </div>
            </div>
          );
        })}

        {/* Add custom routine slot */}
        <button
          onClick={() => alert('Custom routine scheduler saved!')}
          className="w-full py-3.5 rounded-2xl border-2 border-dashed border-slate-300 text-slate-600 hover:border-blue-500 hover:text-blue-700 font-bold text-xs flex items-center justify-center gap-2 transition-all bg-white/60"
        >
          <Plus className="w-4 h-4" />
          <span>Add Custom Routine Time (समय स्लॉट जोड़ें)</span>
        </button>
      </div>
    </div>
  );
}
