import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import { normalizeInterestId } from '../data/personaData';
import {
  ArrowLeft,
  Bell,
  CloudRain,
  Activity,
  AlertTriangle,
  Plane,
  ShieldCheck,
  Check,
  Sparkles,
  Clock,
  Radio,
  Wind,
  Sun,
  Droplets,
  Car,
} from 'lucide-react';

interface NotifItem {
  id: string;
  category: 'for-you' | 'safety' | 'trips';
  interestType?: string;
  title: string;
  body: string;
  time: string;
  isRead: boolean;
  icon: typeof CloudRain;
  iconBg: string;
  iconColor: string;
  badge?: string;
  source?: string;
  isSevere?: boolean;
}

export default function NotifCenter({ navigate }: { navigate: Navigate }) {
  const { userProfile } = useWeather();
  const [activeTab, setActiveTab] = useState<'for-you' | 'safety' | 'trips'>('for-you');

  const activeInterests = (userProfile.interests && userProfile.interests.length > 0
    ? userProfile.interests
    : ['commute']
  ).map(normalizeInterestId);

  // Master notifications database categorized by interest
  const allNotifications: NotifItem[] = [
    // Commute
    {
      id: 'c1',
      category: 'for-you',
      interestType: 'commute',
      title: '☔ Baarish has joined your commute',
      body: 'Rain is expected near 8:30 AM along your route to Cyber City. Leave by 8:15 AM or carry an umbrella!',
      time: '12m ago',
      isRead: false,
      icon: CloudRain,
      iconBg: 'bg-blue-100',
      iconColor: 'text-blue-600',
      badge: 'Commute Alert',
    },
    {
      id: 'c2',
      category: 'for-you',
      interestType: 'commute',
      title: '🚗 DME Highway conditions clear',
      body: 'Delhi-Meerut Expressway reporting 7.0 km sightlines with no waterlogging on main carriageways.',
      time: '1h ago',
      isRead: true,
      icon: Car,
      iconBg: 'bg-sky-100',
      iconColor: 'text-sky-600',
      badge: 'Traffic Weather',
    },

    // Fitness
    {
      id: 'f1',
      category: 'for-you',
      interestType: 'fitness',
      title: '🏃 Prime running window unlocked',
      body: '6:00–6:50 AM looks optimal for your workout today. 23°C, clean air, low UV (1.0).',
      time: '2h ago',
      isRead: false,
      icon: Activity,
      iconBg: 'bg-emerald-100',
      iconColor: 'text-emerald-600',
      badge: 'Fitness AI',
    },
    {
      id: 'f2',
      category: 'for-you',
      interestType: 'fitness',
      title: '☀️ Midday Heat Caution',
      body: 'Thermal stress peaks at 1:00 PM (WBGT 28°C). Avoid outdoor interval training during midday.',
      time: '3h ago',
      isRead: true,
      icon: Sun,
      iconBg: 'bg-amber-100',
      iconColor: 'text-amber-600',
      badge: 'Heat Safety',
    },

    // Farming
    {
      id: 'fa1',
      category: 'for-you',
      interestType: 'farming',
      title: '🌾 GKMS Agromet: Hold Irrigation',
      body: 'Moderate rainfall (18–24mm) expected tomorrow afternoon. Postpone canal irrigation to conserve water.',
      time: '45m ago',
      isRead: false,
      icon: Droplets,
      iconBg: 'bg-emerald-100',
      iconColor: 'text-emerald-700',
      badge: 'GKMS Advisory',
    },
    {
      id: 'fa2',
      category: 'for-you',
      interestType: 'farming',
      title: '🍃 Safe Pesticide Spray Window',
      body: 'Wind speed remains below 8 km/h until 10:00 AM. Favorable for foliar spray without chemical drift.',
      time: '3h ago',
      isRead: true,
      icon: Wind,
      iconBg: 'bg-teal-100',
      iconColor: 'text-teal-700',
      badge: 'Field Window',
    },

    // Travel
    {
      id: 't1',
      category: 'for-you',
      interestType: 'travel',
      title: '✈️ Jaipur trip forecast confirmed',
      body: 'Sunny & pleasant conditions confirmed for 18–21 Sep. Clear skies with 32°C day and 24°C night.',
      time: '1h ago',
      isRead: false,
      icon: Plane,
      iconBg: 'bg-purple-100',
      iconColor: 'text-purple-600',
      badge: 'Trip Planner',
    },
    {
      id: 't2',
      category: 'for-you',
      interestType: 'travel',
      title: '🛣️ NH-48 Highway Route Clear',
      body: 'Delhi-Jaipur corridor weather radar shows dry asphalt, 10 km visibility and zero severe turbulence.',
      time: '4h ago',
      isRead: true,
      icon: Car,
      iconBg: 'bg-indigo-100',
      iconColor: 'text-indigo-600',
      badge: 'Highway Radar',
    },

    // Health
    {
      id: 'h1',
      category: 'for-you',
      interestType: 'health',
      title: '😷 Morning Air Inversion Notice',
      body: 'PM2.5 elevated (68 µg/m³) due to nocturnal boundary layer inversion. Cleanest outdoor air starts at 10:30 AM.',
      time: '20m ago',
      isRead: false,
      icon: Wind,
      iconBg: 'bg-emerald-100',
      iconColor: 'text-emerald-600',
      badge: 'Air Quality',
    },
    {
      id: 'h2',
      category: 'for-you',
      interestType: 'health',
      title: '☀️ Very High UV Index Predicted',
      body: 'UV Index reaches 7.2 between 12:15 PM and 2:30 PM. Sensitive skin should wear SPF 30+.',
      time: '2h ago',
      isRead: true,
      icon: Sun,
      iconBg: 'bg-amber-100',
      iconColor: 'text-amber-600',
      badge: 'UV Advisory',
    },

    // Family
    {
      id: 'fam1',
      category: 'for-you',
      interestType: 'family',
      title: "🎒 Tomorrow's School Bus Rain Alert",
      body: 'Morning school bus run (7:45–8:15 AM) has a 70% rain probability. Pack lightweight ponchos and bag sleeves.',
      time: '30m ago',
      isRead: false,
      icon: CloudRain,
      iconBg: 'bg-amber-100',
      iconColor: 'text-amber-600',
      badge: 'School Prep',
    },

    // Beach
    {
      id: 'b1',
      category: 'for-you',
      interestType: 'beach',
      title: '🏖️ INCOIS Shoreline Safety Status',
      body: 'Calm swell (1.1m) and gentle onshore breeze. Low tide at 9:15 AM provides wide safe sandbanks.',
      time: '1h ago',
      isRead: false,
      icon: Sun,
      iconBg: 'bg-cyan-100',
      iconColor: 'text-cyan-600',
      badge: 'Coastal Green Flag',
    },

    // Events
    {
      id: 'ev1',
      category: 'for-you',
      interestType: 'events',
      title: '🎉 Outdoor Gathering Weather Outlook',
      body: '94% dry probability for morning and afternoon events. Keep marquee ready for possible isolated drizzle post 7 PM.',
      time: '2h ago',
      isRead: false,
      icon: Sparkles,
      iconBg: 'bg-rose-100',
      iconColor: 'text-rose-600',
      badge: 'Event Confidence',
    },

    // Safety Tab (Universal IMD Bulletins)
    {
      id: 's1',
      category: 'safety',
      title: '⚠️ Severe Thunderstorm Warning',
      body: 'IMD Red Bulletin: Severe convective thunderstorm with squally winds gusting up to 55 km/h and intense lightning strikes expected across NCR and Western UP between 14:30 and 17:00 hrs IST. Avoid open spaces and temporary structures.',
      time: '25m ago',
      isRead: false,
      icon: AlertTriangle,
      iconBg: 'bg-rose-100',
      iconColor: 'text-rose-600',
      badge: 'IMD RED ALERT',
      source: 'Regional Meteorological Centre, New Delhi',
      isSevere: true,
    },
    {
      id: 's2',
      category: 'safety',
      title: '⚠️ High UV Radiation Advisory',
      body: 'UV Index predicted to reach 7.4 (Very High) between 12:15 and 14:00 hrs. Limit outdoor direct sun exposure.',
      time: '1h ago',
      isRead: true,
      icon: AlertTriangle,
      iconBg: 'bg-amber-100',
      iconColor: 'text-amber-600',
      badge: 'Health Advisory',
      source: 'IMD Air Quality & UV Telemetry',
      isSevere: false,
    },

    // Trips Tab
    {
      id: 'tr1',
      category: 'trips',
      title: '✈️ Jaipur trip weather update',
      body: 'Sunny & pleasant conditions confirmed for 18–21 Sep. Trough moved eastwards, dry road travel predicted.',
      time: '3h ago',
      isRead: true,
      icon: Plane,
      iconBg: 'bg-indigo-100',
      iconColor: 'text-indigo-600',
      badge: 'Trip Planner',
    },
    {
      id: 'tr2',
      category: 'trips',
      title: '🏔️ Manali / Himachal Highway Watch',
      body: 'Monsoon activity weakening over lower hills; NH-3 open with normal vehicular transit.',
      time: '6h ago',
      isRead: true,
      icon: Plane,
      iconBg: 'bg-indigo-100',
      iconColor: 'text-indigo-600',
      badge: 'Highway Watch',
    },
  ];

  const [notifications, setNotifications] = useState<NotifItem[]>(allNotifications);

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  // Filter "For You" strictly by active interests if single or multiple
  const filteredNotifs = notifications.filter((n) => {
    if (activeTab === 'safety') return n.category === 'safety';
    if (activeTab === 'trips') return n.category === 'trips';
    // For You tab:
    if (n.category !== 'for-you') return false;
    if (!n.interestType) return true;
    return activeInterests.includes(n.interestType as any);
  });

  return (
    <div className="min-h-screen text-slate-900 pb-24 bg-[#F4F7FB]">
      {/* ─── Top Header ─── */}
      <div className="px-5 pt-4 pb-3 bg-white border-b border-slate-200/90 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-xl bg-slate-50 border border-slate-200/80 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Home</span>
          </button>

          <button
            onClick={markAllAsRead}
            className="text-[11px] font-bold text-[#1A4FA0] hover:underline flex items-center gap-1"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Mark all read</span>
          </button>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight">
              Notification Center
            </h1>
            <p className="text-xs text-slate-500 font-medium">
              Real-time weather notices, routine alerts & safety sirens
            </p>
          </div>
        </div>

        {/* ─── Segmented Tabs: For You / Safety / Trips ─── */}
        <div className="p-1 rounded-2xl bg-slate-100 mt-4 flex gap-1">
          {(
            [
              { id: 'for-you', label: 'For You' },
              { id: 'safety', label: 'Safety' },
              { id: 'trips', label: 'Trips' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-white text-[#1A4FA0] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ─── Notification List Stream ─── */}
      <div className="px-5 py-4 space-y-3">
        {filteredNotifs.length > 0 ? (
          filteredNotifs.map((item) => {
            const Icon = item.icon;

            // Severe weather warning uses formal wording, bold hierarchy, and no playful text
            if (item.isSevere) {
              return (
                <div
                  key={item.id}
                  className="p-5 rounded-3xl bg-rose-50 border-2 border-rose-200 shadow-sm space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0">
                        <AlertTriangle className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black uppercase tracking-wider">
                          {item.badge}
                        </span>
                        <h3 className="text-sm font-black text-rose-950 mt-1">
                          {item.title}
                        </h3>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-rose-700">
                      {item.time}
                    </span>
                  </div>

                  <p className="text-xs text-rose-900 leading-relaxed font-semibold">
                    {item.body}
                  </p>

                  <div className="pt-2 border-t border-rose-200 flex items-center justify-between text-[10px] text-rose-700 font-bold">
                    <span>Source: {item.source}</span>
                    <span>Valid until 17:00 IST</span>
                  </div>
                </div>
              );
            }

            // Standard / Friendly Consumer Notification
            return (
              <div
                key={item.id}
                className={`p-4.5 rounded-3xl border transition-all ${
                  item.isRead
                    ? 'bg-white border-slate-200/80'
                    : 'bg-blue-50/60 border-blue-200 shadow-2xs'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${item.iconBg} ${item.iconColor}`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>

                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-slate-900">
                        {item.title}
                      </span>
                      <span className="text-[10px] font-bold text-slate-400">
                        {item.time}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 font-medium leading-relaxed">
                      {item.body}
                    </p>

                    {item.badge && (
                      <span className="inline-block px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-bold mt-1">
                        {item.badge}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-6 space-y-2">
            <Bell className="w-8 h-8 text-slate-300 mx-auto" />
            <h3 className="text-sm font-bold text-slate-700">No new alerts</h3>
            <p className="text-xs text-slate-400">
              You are all caught up in the {activeTab} stream!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
