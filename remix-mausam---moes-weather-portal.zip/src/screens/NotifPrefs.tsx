import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  CloudRain,
  Flame,
  Wind,
  Sun,
  Activity,
  Backpack,
  Plane,
  CloudFog,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  Moon,
} from 'lucide-react';

interface NotifCardItem {
  id: string;
  name: string;
  desc: string;
  icon: typeof CloudRain;
  color: string;
  isMandatory?: boolean;
}

const NOTIF_CARDS: NotifCardItem[] = [
  {
    id: 'rain-commute',
    name: 'Rain before commute',
    desc: 'Alert 25 mins prior if shower overlaps your morning or evening route.',
    icon: CloudRain,
    color: 'text-blue-600 bg-blue-100/70',
  },
  {
    id: 'heatwave',
    name: 'Heat & heatwave',
    desc: 'Real-time alerts when wet-bulb temperature or heat index crosses 40°C.',
    icon: Flame,
    color: 'text-amber-600 bg-amber-100/70',
  },
  {
    id: 'aqi',
    name: 'Poor air quality',
    desc: 'Instant notice if PM2.5 crosses into unhealthy / severe zones.',
    icon: Wind,
    color: 'text-teal-600 bg-teal-100/70',
  },
  {
    id: 'uv',
    name: 'High UV index',
    desc: 'Proactive reminder to apply sunscreen and seek midday shade.',
    icon: Sun,
    color: 'text-amber-500 bg-amber-100/70',
  },
  {
    id: 'workout',
    name: 'Best workout window',
    desc: 'Optimal outdoor thermal comfort hours based on your preference.',
    icon: Activity,
    color: 'text-emerald-600 bg-emerald-100/70',
  },
  {
    id: 'school',
    name: 'School commute alerts',
    desc: 'Special morning advisory for parents and school bus routes.',
    icon: Backpack,
    color: 'text-orange-600 bg-orange-100/70',
  },
  {
    id: 'trip',
    name: 'Upcoming trip weather',
    desc: '48h departure forecasts for your saved intercity destinations.',
    icon: Plane,
    color: 'text-indigo-600 bg-indigo-100/70',
  },
  {
    id: 'fog',
    name: 'Fog & low visibility',
    desc: 'Critical highway visibility alerts during winter morning commute.',
    icon: CloudFog,
    color: 'text-slate-600 bg-slate-200/70',
  },
  {
    id: 'severe',
    name: 'Severe weather warnings',
    desc: 'Official IMD red/orange alerts for cyclones, lightning, and floods.',
    icon: AlertTriangle,
    color: 'text-rose-600 bg-rose-100',
    isMandatory: true,
  },
];

export default function NotifPrefs({ navigate }: { navigate: Navigate }) {
  const { userProfile, updateUserProfile } = useWeather();

  const [selectedPrefs, setSelectedPrefs] = useState<Record<string, boolean>>({
    'rain-commute': true,
    heatwave: true,
    aqi: true,
    uv: false,
    workout: true,
    school: false,
    trip: true,
    fog: true,
    severe: true,
  });

  const [notifStyle, setNotifStyle] = useState<'Friendly' | 'Simple' | 'Formal'>('Friendly');
  const [quietStart, setQuietStart] = useState('22:00');
  const [quietEnd, setQuietEnd] = useState('07:00');

  const togglePref = (id: string, isMandatory?: boolean) => {
    if (isMandatory) return; // Keep severe weather enabled
    setSelectedPrefs((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleFinish = () => {
    updateUserProfile({
      notificationStyle: notifStyle,
      quietHoursStart: quietStart,
      quietHoursEnd: quietEnd,
    });
    navigate('home');
  };

  return (
    <div
      className="min-h-screen px-6 pt-5 pb-10 relative"
      style={{ background: 'linear-gradient(180deg, #F8FAFC 0%, #EFF6FF 100%)' }}
    >
      <div className="space-y-5">
        {/* Progress Bar Header */}
        <div>
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-2">
            <span className="text-[#1A4FA0]">Step 4 of 4 • Alerts</span>
            <span>Almost done!</span>
          </div>
          <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
            <div className="w-full h-full bg-[#1A4FA0] rounded-full" />
          </div>
        </div>

        {/* Title & Subtext */}
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            What should we watch for you?
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">
            Choose alerts that actually matter to your day.
          </p>
        </div>

        {/* ─── Large Interactive Preference Cards ─── */}
        <div className="space-y-2.5">
          {NOTIF_CARDS.map((card) => {
            const isChecked = card.isMandatory || !!selectedPrefs[card.id];
            const Icon = card.icon;

            return (
              <div
                key={card.id}
                onClick={() => togglePref(card.id, card.isMandatory)}
                className={`p-4 rounded-3xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  isChecked
                    ? 'bg-blue-50/70 border-blue-200/90 shadow-2xs'
                    : 'bg-white border-slate-200/80 hover:bg-slate-50'
                }`}
              >
                {/* Left: Icon & Description */}
                <div className="flex items-start gap-3 flex-1">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${card.color}`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>

                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-slate-900">
                        {card.name}
                      </span>
                      {card.isMandatory && (
                        <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 text-[10px] font-black uppercase tracking-wider">
                          Official
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed">
                      {card.desc}
                    </p>
                  </div>
                </div>

                {/* Right: Modern Switch */}
                <div className="shrink-0 pl-1">
                  <div
                    className={`w-12 h-7 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                      isChecked ? 'bg-[#1A4FA0]' : 'bg-slate-200'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform duration-200 ease-in-out ${
                        isChecked ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* ─── Notification Style Segmented Control ─── */}
        <div className="bg-white p-4.5 rounded-3xl border border-slate-200/90 shadow-2xs space-y-2.5">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
            Notification Style
          </label>

          <div className="p-1 rounded-2xl bg-slate-100 flex gap-1">
            {(['Friendly', 'Simple', 'Formal'] as const).map((style) => (
              <button
                key={style}
                type="button"
                onClick={() => setNotifStyle(style)}
                className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
                  notifStyle === style
                    ? 'bg-white text-[#1A4FA0] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {style}
              </button>
            ))}
          </div>

          <p className="text-[11px] text-slate-500 font-medium">
            {notifStyle === 'Friendly' &&
              'e.g. "☔ Baarish has joined your commute. Umbrella le jaana!"'}
            {notifStyle === 'Simple' &&
              'e.g. "Rain expected at 8:30 AM. Carry umbrella."'}
            {notifStyle === 'Formal' &&
              'e.g. "IMD Advisory: Moderate convective precipitation expected at 08:30 hrs."'}
          </p>
        </div>

        {/* ─── Quiet Hours Time Selectors ─── */}
        <div className="bg-white p-4.5 rounded-3xl border border-slate-200/90 shadow-2xs space-y-2.5">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Moon className="w-4 h-4 text-indigo-500" />
            <span>Quiet Hours (No non-emergency alerts)</span>
          </label>

          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="block text-[11px] font-bold text-slate-500 mb-1">
                From
              </span>
              <input
                type="time"
                value={quietStart}
                onChange={(e) => setQuietStart(e.target.value)}
                className="w-full h-9 px-2 rounded-xl bg-white border border-slate-200 text-xs font-black text-slate-900 focus:outline-none focus:border-[#1A4FA0]"
              />
            </div>

            <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="block text-[11px] font-bold text-slate-500 mb-1">
                Until
              </span>
              <input
                type="time"
                value={quietEnd}
                onChange={(e) => setQuietEnd(e.target.value)}
                className="w-full h-9 px-2 rounded-xl bg-white border border-slate-200 text-xs font-black text-slate-900 focus:outline-none focus:border-[#1A4FA0]"
              />
            </div>
          </div>
        </div>

        {/* ─── CTA: Take Me to My Mausam (directly after preferences with adequate padding) ─── */}
        <div className="pt-2 pb-4">
          <button
            onClick={handleFinish}
            className="w-full h-14 rounded-2xl text-white font-bold text-base flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] cursor-pointer"
            style={{
              background: 'linear-gradient(135deg, #1A4FA0 0%, #2563EB 100%)',
              boxShadow: '0 8px 24px -4px rgba(26, 79, 160, 0.35)',
            }}
          >
            <span>Take Me to My Mausam</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
