import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  User,
  Heart,
  Clock,
  MapPin,
  Languages,
  Bell,
  Moon,
  Volume2,
  Eye,
  Sparkles,
  Shield,
  Key,
  ChevronRight,
  RotateCcw,
  Sliders,
  Check,
} from 'lucide-react';

export default function ProfileSettings({ navigate }: { navigate: Navigate }) {
  const { userProfile, updateUserProfile, isOffline, setIsOffline } = useWeather();

  const [textSize, setTextSize] = useState<'Default' | 'Large'>('Default');
  const [highContrast, setHighContrast] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [voiceResponses, setVoiceResponses] = useState(true);

  return (
    <div className="min-h-screen text-slate-900 pb-24 bg-[#F4F7FB]">
      {/* ─── Top Header & User Card ─── */}
      <div className="px-5 pt-4 pb-3">
        <h1 className="text-2xl font-black text-slate-900 tracking-tight mb-3">
          Profile & Settings
        </h1>

        {/* User Profile Card */}
        <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#1A4FA0] to-[#2563EB] text-white font-black text-xl flex items-center justify-center shadow-md">
              {userProfile.name ? userProfile.name[0] : 'M'}
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900">
                {userProfile.name || 'Manvi Sharma'}
              </h2>
              <p className="text-xs text-slate-500 font-medium flex items-center gap-1 mt-0.5">
                <MapPin className="w-3 h-3 text-[#1A4FA0]" />
                <span>{userProfile.city || 'Vasundhara, Ghaziabad'}</span>
              </p>
              <span className="inline-block text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full mt-1.5 border border-emerald-200/60">
                Mausam Verified Member
              </span>
            </div>
          </div>

          <button
            onClick={() => navigate('profile-setup')}
            className="p-2 rounded-xl bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200 text-xs font-bold"
          >
            Edit
          </button>
        </div>
      </div>

      <div className="px-5 space-y-5">
        {/* ─── GROUP 1: Personalization ─── */}
        <div className="space-y-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
            Personalization
          </span>

          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs divide-y divide-slate-100 overflow-hidden">
            {/* My Interests */}
            <div
              onClick={() => navigate('interests')}
              className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center">
                  <Heart className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">My Interests</h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Fitness, commute & air quality preferences
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>

            {/* My Routine */}
            <div
              onClick={() => navigate('routine')}
              className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">My Routine</h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Home, work destination & commute departure times
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>

            {/* Saved Locations */}
            <div
              onClick={() => navigate('saved')}
              className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Saved Locations</h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Ghaziabad, Noida, Gurugram & Jaipur
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>
          </div>
        </div>

        {/* ─── GROUP 2: Preferences ─── */}
        <div className="space-y-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
            Preferences
          </span>

          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs divide-y divide-slate-100 overflow-hidden">
            {/* Language */}
            <div
              onClick={() => navigate('profile-setup')}
              className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
                  <Languages className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Language</h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    {userProfile.language || 'English / हिन्दी'}
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>

            {/* Notifications */}
            <div
              onClick={() => navigate('notif-prefs')}
              className="p-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Notifications</h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Rain alerts, commute sirens & severe weather
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>

            {/* Quiet Hours */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center">
                  <Moon className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Quiet Hours</h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    {userProfile.quietHoursStart || '22:00'} – {userProfile.quietHoursEnd || '07:00'}
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold text-[#1A4FA0]">Active</span>
            </div>

            {/* Notification Tone */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center">
                  <Volume2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Notification Tone</h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    {userProfile.notificationStyle || 'Friendly'} tone
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold text-slate-700">Friendly</span>
            </div>
          </div>
        </div>

        {/* ─── GROUP 3: Accessibility ─── */}
        <div className="space-y-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
            Accessibility
          </span>

          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs divide-y divide-slate-100 overflow-hidden">
            {/* Text Size */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-slate-50 text-slate-600 flex items-center justify-center">
                  <Eye className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Text Size</h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Standard high legibility
                  </p>
                </div>
              </div>
              <div className="flex gap-1">
                {(['Default', 'Large'] as const).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setTextSize(s)}
                    className={`px-2.5 py-1 rounded-xl text-xs font-bold border transition-all ${
                      textSize === s
                        ? 'bg-[#1A4FA0] text-white border-[#1A4FA0]'
                        : 'bg-slate-50 text-slate-600 border-slate-200'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* High Contrast */}
            <div className="p-4 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">
                High contrast text
              </span>
              <button
                type="button"
                onClick={() => setHighContrast(!highContrast)}
                className={`w-11 h-6 rounded-full p-0.5 transition-colors ${
                  highContrast ? 'bg-[#1A4FA0]' : 'bg-slate-200'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-xs transform transition-transform ${
                    highContrast ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Reduce Motion */}
            <div className="p-4 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">
                Reduce motion
              </span>
              <button
                type="button"
                onClick={() => setReduceMotion(!reduceMotion)}
                className={`w-11 h-6 rounded-full p-0.5 transition-colors ${
                  reduceMotion ? 'bg-[#1A4FA0]' : 'bg-slate-200'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-xs transform transition-transform ${
                    reduceMotion ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Voice Responses */}
            <div className="p-4 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">
                Voice audio responses
              </span>
              <button
                type="button"
                onClick={() => setVoiceResponses(!voiceResponses)}
                className={`w-11 h-6 rounded-full p-0.5 transition-colors ${
                  voiceResponses ? 'bg-[#1A4FA0]' : 'bg-slate-200'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-xs transform transition-transform ${
                    voiceResponses ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* ─── GROUP 4: Privacy & Data ─── */}
        <div className="space-y-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
            Privacy & Permissions
          </span>

          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs p-4 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">
                  Data & Personalization
                </h4>
                <p className="text-[11px] text-slate-500 font-medium">
                  Encrypted on-device profile, zero third-party tracking.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
              <span className="font-bold text-slate-700">Offline Cache Storage</span>
              <button
                type="button"
                onClick={() => setIsOffline(!isOffline)}
                className="text-[11px] font-bold text-[#1A4FA0] hover:underline"
              >
                {isOffline ? 'Switch Online' : 'Simulate Offline Mode'}
              </button>
            </div>
          </div>
        </div>

        {/* ─── Restart Onboarding Button (Re-experience flow) ─── */}
        <div className="pt-2">
          <button
            onClick={() => navigate('splash')}
            className="w-full h-13 rounded-2xl bg-white hover:bg-slate-50 text-[#1A4FA0] font-bold text-xs flex items-center justify-center gap-2 border border-slate-200/90 shadow-2xs transition-all active:scale-[0.98] cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Replay Onboarding & Product Tour</span>
          </button>
        </div>
      </div>
    </div>
  );
}
