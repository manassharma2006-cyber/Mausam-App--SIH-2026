import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import { User, Calendar, Languages, MapPin, LocateFixed, ArrowRight, Check, Search } from 'lucide-react';
import { curatedIndianStations } from '../data/indianLocations';

export default function ProfileSetup({ navigate }: { navigate: Navigate }) {
  const { userProfile, updateUserProfile, switchLocation } = useWeather();
  const [name, setName] = useState(userProfile.name || 'Manvi Sharma');
  const [ageGroup, setAgeGroup] = useState('25–34');
  const [language, setLanguage] = useState('English');
  const [locationMode, setLocationMode] = useState<'detect' | 'search'>('detect');
  const [searchQuery, setSearchQuery] = useState('Vasundhara, Ghaziabad');
  const [selectedStation, setSelectedStation] = useState('Ghaziabad');
  const [isDetecting, setIsDetecting] = useState(false);

  const ageOptions = ['Under 18', '18–24', '25–34', '35–44', '45–60', '60+'];
  const languageOptions = [
    { code: 'English', label: 'English', native: 'English' },
    { code: 'हिन्दी', label: 'Hindi', native: 'हिन्दी' },
    { code: 'Hinglish', label: 'Hinglish', native: 'Hinglish' },
    { code: 'Punjabi', label: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
    { code: 'Bengali', label: 'Bengali', native: 'বাংলা' },
    { code: 'Marathi', label: 'Marathi', native: 'मराठी' },
    { code: 'Tamil', label: 'Tamil', native: 'தமிழ்' },
    { code: 'Telugu', label: 'Telugu', native: 'తెలుగు' },
  ];

  const handleDetectLocation = () => {
    setIsDetecting(true);
    setTimeout(() => {
      setIsDetecting(false);
      setSelectedStation('Ghaziabad');
      setSearchQuery('Vasundhara, Ghaziabad (GPS Detected)');
    }, 700);
  };

  const handleContinue = async () => {
    updateUserProfile({
      name,
      city: selectedStation,
      language: language as any,
    });
    const found = curatedIndianStations.find(
      (s) => s.info.nameEn.toLowerCase().includes(selectedStation.toLowerCase())
    );
    if (found) {
      await switchLocation(found.info);
    }
    navigate('interests');
  };

  return (
    <div
      className="min-h-screen flex flex-col justify-between px-6 pt-5 pb-8 relative"
      style={{ background: 'linear-gradient(180deg, #F8FAFC 0%, #EFF6FF 100%)' }}
    >
      <div className="space-y-6">
        {/* Progress Bar Header */}
        <div>
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-2">
            <span className="text-[#1A4FA0]">Step 1 of 4</span>
            <span>25% completed</span>
          </div>
          <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
            <div className="w-1/4 h-full bg-[#1A4FA0] rounded-full transition-all" />
          </div>
        </div>

        {/* Title & Subtext */}
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            A little about you
          </h1>
          <p className="text-sm text-slate-600 font-medium mt-1">
            This helps us personalize weather guidance, air quality alerts, and daily routine forecasts.
          </p>
        </div>

        {/* ─── Form Card ─── */}
        <div className="space-y-4">
          {/* Name Input */}
          <div className="bg-white p-4.5 rounded-3xl border border-slate-200/90 shadow-2xs">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-[#1A4FA0]" />
              <span>Full Name</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Manvi Sharma"
              className="w-full h-12 px-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] focus:bg-white transition-all"
            />
          </div>

          {/* Age Group Dropdown */}
          <div className="bg-white p-4.5 rounded-3xl border border-slate-200/90 shadow-2xs">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#1A4FA0]" />
              <span>Age Group</span>
            </label>
            <select
              value={ageGroup}
              onChange={(e) => setAgeGroup(e.target.value)}
              className="w-full h-12 px-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] cursor-pointer"
            >
              {ageOptions.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
          </div>

          {/* Preferred Language Dropdown */}
          <div className="bg-white p-4.5 rounded-3xl border border-slate-200/90 shadow-2xs">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Languages className="w-3.5 h-3.5 text-[#1A4FA0]" />
              <span>Preferred Language</span>
            </label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full h-12 px-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] cursor-pointer"
            >
              {languageOptions.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.native} ({lang.label})
                </option>
              ))}
            </select>
          </div>

          {/* Current Location Selector */}
          <div className="bg-white p-4.5 rounded-3xl border border-slate-200/90 shadow-2xs">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#1A4FA0]" />
              <span>Current Location</span>
            </label>

            {/* Mode selection buttons */}
            <div className="grid grid-cols-2 gap-2 mb-3">
              <button
                type="button"
                onClick={() => {
                  setLocationMode('detect');
                  handleDetectLocation();
                }}
                className={`py-2.5 px-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
                  locationMode === 'detect'
                    ? 'bg-blue-50 border-[#1A4FA0] text-[#1A4FA0]'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <LocateFixed className="w-3.5 h-3.5" />
                <span>{isDetecting ? 'Locating...' : 'Detect GPS'}</span>
              </button>

              <button
                type="button"
                onClick={() => setLocationMode('search')}
                className={`py-2.5 px-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
                  locationMode === 'search'
                    ? 'bg-blue-50 border-[#1A4FA0] text-[#1A4FA0]'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <Search className="w-3.5 h-3.5" />
                <span>Search Manual</span>
              </button>
            </div>

            {/* Location display or search field */}
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setSelectedStation(e.target.value.split(',')[0].trim());
                }}
                placeholder="Search city or pin code"
                className="w-full h-12 pl-3.5 pr-8 rounded-2xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] focus:bg-white transition-all"
              />
              <Check className="w-4 h-4 text-emerald-600 absolute right-3 top-4" />
            </div>
            <p className="text-[11px] text-slate-500 mt-1.5">
              Live radar observatory: <strong className="text-slate-700">IMD Hindon & Safdarjung</strong>
            </p>
          </div>
        </div>
      </div>

      {/* ─── Actions (near end of content, spacious) ─── */}
      <div className="pt-6 space-y-2.5">
        <button
          onClick={handleContinue}
          className="w-full h-13.5 rounded-2xl text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98] cursor-pointer"
          style={{
            background: 'linear-gradient(135deg, #1A4FA0 0%, #2563EB 100%)',
          }}
        >
          <span>Continue</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <button
          onClick={() => navigate('interests')}
          className="w-full py-2.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition-colors"
        >
          Skip for now
        </button>
      </div>
    </div>
  );
}
