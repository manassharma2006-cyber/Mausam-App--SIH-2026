import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  Home,
  Briefcase,
  Clock,
  Sun,
  Moon,
  Activity,
  ArrowRight,
  LocateFixed,
  MapPin,
  Check,
} from 'lucide-react';

export default function RoutineSetup({ navigate }: { navigate: Navigate }) {
  const { userProfile, updateUserProfile } = useWeather();

  const [homeLocation, setHomeLocation] = useState('Vasundhara, Ghaziabad');
  const [workLocation, setWorkLocation] = useState('Cyber City, Gurugram');
  const [morningTime, setMorningTime] = useState('08:15');
  const [eveningTime, setEveningTime] = useState('18:30');
  const [workoutSlot, setWorkoutSlot] = useState<string>('Early Morning');
  const [isDetectingHome, setIsDetectingHome] = useState(false);

  const workoutOptions = [
    { label: 'Early Morning', time: '05:30 – 07:00 AM', emoji: '🌅' },
    { label: 'Morning', time: '07:00 – 09:00 AM', emoji: '☀️' },
    { label: 'Evening', time: '05:30 – 07:30 PM', emoji: '🌇' },
    { label: 'Night', time: '08:00 – 10:00 PM', emoji: '🌙' },
  ];

  const handleDetectHome = () => {
    setIsDetectingHome(true);
    setTimeout(() => {
      setIsDetectingHome(false);
      setHomeLocation('Sector 14, Vasundhara, Ghaziabad (GPS)');
    }, 600);
  };

  const handleSave = () => {
    updateUserProfile({
      homeAddress: homeLocation,
      workAddress: workLocation,
      morningAlert: morningTime,
      eveningAlert: eveningTime,
      workoutPreference: workoutSlot,
    });
    navigate('notif-prefs');
  };

  return (
    <div
      className="min-h-screen flex flex-col justify-between px-6 pt-5 pb-8 relative"
      style={{ background: 'linear-gradient(180deg, #F8FAFC 0%, #EFF6FF 100%)' }}
    >
      <div className="space-y-5">
        {/* Progress Bar Header */}
        <div>
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-2">
            <span className="text-[#1A4FA0]">Step 3 of 4 • Routine Setup</span>
            <span>75% completed</span>
          </div>
          <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
            <div className="w-3/4 h-full bg-[#1A4FA0] rounded-full transition-all duration-300" />
          </div>
        </div>

        {/* Title & Subtext */}
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Let’s understand your day
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">
            Add as much as you like. You can edit this anytime in Settings.
          </p>
        </div>

        {/* ─── Visually Separated Cards ─── */}
        <div className="space-y-3.5">
          {/* 1. Home Location Card */}
          <div className="bg-white p-4.5 rounded-3xl border border-slate-200/90 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Home className="w-4 h-4 text-[#1A4FA0]" />
                <span>Home Location</span>
              </label>
              <button
                type="button"
                onClick={handleDetectHome}
                className="text-[11px] font-bold text-[#1A4FA0] hover:underline flex items-center gap-1"
              >
                <LocateFixed className="w-3 h-3" />
                <span>{isDetectingHome ? 'Detecting...' : 'Use Current'}</span>
              </button>
            </div>
            <div className="relative">
              <input
                type="text"
                value={homeLocation}
                onChange={(e) => setHomeLocation(e.target.value)}
                placeholder="Enter home neighborhood or city"
                className="w-full h-12 px-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* 2. Work / School Location Card */}
          <div className="bg-white p-4.5 rounded-3xl border border-slate-200/90 shadow-2xs space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Briefcase className="w-4 h-4 text-emerald-600" />
              <span>Work / School Destination</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={workLocation}
                onChange={(e) => setWorkLocation(e.target.value)}
                placeholder="Enter office, campus or workplace"
                className="w-full h-12 px-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* 3. Commute Times (Morning & Evening) */}
          <div className="bg-white p-4.5 rounded-3xl border border-slate-200/90 shadow-2xs space-y-3">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-500" />
              <span>Commute Departure Times</span>
            </label>

            <div className="grid grid-cols-2 gap-2.5">
              {/* Morning Commute Time Picker */}
              <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="block text-[11px] font-bold text-slate-500 mb-1 flex items-center gap-1">
                  <Sun className="w-3 h-3 text-amber-500" /> Morning Out
                </span>
                <input
                  type="time"
                  value={morningTime}
                  onChange={(e) => setMorningTime(e.target.value)}
                  className="w-full h-10 px-2 rounded-xl bg-white border border-slate-200 text-sm font-black text-slate-900 focus:outline-none focus:border-[#1A4FA0] cursor-pointer"
                />
              </div>

              {/* Evening Commute Time Picker */}
              <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="block text-[11px] font-bold text-slate-500 mb-1 flex items-center gap-1">
                  <Moon className="w-3 h-3 text-indigo-500" /> Evening Back
                </span>
                <input
                  type="time"
                  value={eveningTime}
                  onChange={(e) => setEveningTime(e.target.value)}
                  className="w-full h-10 px-2 rounded-xl bg-white border border-slate-200 text-sm font-black text-slate-900 focus:outline-none focus:border-[#1A4FA0] cursor-pointer"
                />
              </div>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">
              We will alert you 20 minutes prior if rain, waterlogging, or severe heat is expected.
            </p>
          </div>

          {/* 4. Preferred Workout Time (Interactive Chips) */}
          <div className="bg-white p-4.5 rounded-3xl border border-slate-200/90 shadow-2xs space-y-2.5">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-rose-500" />
              <span>Preferred Workout / Outdoor Time</span>
            </label>

            <div className="grid grid-cols-2 gap-2">
              {workoutOptions.map((opt) => (
                <button
                  key={opt.label}
                  type="button"
                  onClick={() => setWorkoutSlot(opt.label)}
                  className={`p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                    workoutSlot === opt.label
                      ? 'bg-blue-50 border-[#1A4FA0] shadow-xs'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                      <span>{opt.emoji}</span>
                      <span>{opt.label}</span>
                    </span>
                    {workoutSlot === opt.label && (
                      <Check className="w-3.5 h-3.5 text-[#1A4FA0]" />
                    )}
                  </div>
                  <span className="text-[10px] font-medium text-slate-500 block mt-0.5">
                    {opt.time}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ─── Action Buttons ─── */}
      <div className="pt-6 space-y-2.5">
        <button
          onClick={handleSave}
          className="w-full h-13.5 rounded-2xl text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98] cursor-pointer"
          style={{
            background: 'linear-gradient(135deg, #1A4FA0 0%, #2563EB 100%)',
          }}
        >
          <span>Save My Routine</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <button
          onClick={() => navigate('notif-prefs')}
          className="w-full py-2.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition-colors"
        >
          Skip for now
        </button>
      </div>
    </div>
  );
}
