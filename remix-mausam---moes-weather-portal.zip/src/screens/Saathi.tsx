import React, { useState, useRef, useEffect } from 'react';
import { useWeather } from '../context/WeatherContext';
import { Navigate } from '../types';
import WeatherReasonSheet from '../components/WeatherReasonSheet';
import {
  ALL_PERSONA_CONFIGS,
  getSaathiSuggestionsForInterests,
  normalizeInterestId,
} from '../data/personaData';
import {
  Mic,
  Send,
  Sparkles,
  Info,
  Compass,
  Volume2,
  VolumeX,
  Languages,
  Check,
  RotateCcw,
  Loader2,
} from 'lucide-react';

export type ChatLanguage = 'hinglish' | 'english' | 'hindi';

interface StructuredCard {
  headline: string;
  verdict: string;
  temp: string;
  uv: string;
  rainChance: string;
  whyContext: string;
  factors: string[];
  suggestedAction?: string;
}

interface SaathiMessage {
  id: string;
  sender: 'user' | 'saathi';
  text: string;
  detectedLanguage?: ChatLanguage;
  structuredCard?: StructuredCard;
  isAudioPlaying?: boolean;
}

// Client-side quick language detector
function clientDetectLanguage(text: string, currentPref: ChatLanguage): ChatLanguage {
  if (/[\u0900-\u097F]/.test(text)) {
    return 'hindi';
  }
  const hinglishKeywords = [
    'baarish', 'barish', 'kya', 'hogi', 'hoga', 'hawa', 'aaj', 'kal', 'parso',
    'shaam', 'sham', 'subah', 'dopahar', 'chhaata', 'chata', 'paani', 'pani',
    'khet', 'kheti', 'kisan', 'fasal', 'sinchai', 'bachhe', 'bacche', 'dhoop',
    'garmi', 'thand', 'sardi', 'kaise', 'kaisa', 'kaisi', 'batao', 'pehne',
    'pehnun', 'jaana', 'jana', 'hai', 'hain', 'nahi', 'nahin', 'karo', 'karein',
    'rahega', 'rahegi', 'chale', 'chalen', 'mausam', 'tapman', 'taapmaan',
    'kitna', 'kitni', 'kab', 'kyun', 'chalega', 'chalegi', 'sakta', 'sakti',
    'niklu', 'nikalna', 'namaste'
  ];
  const words = text.toLowerCase().split(/[\s,?.!'"()\-+/]+/);
  if (words.some((w) => hinglishKeywords.includes(w))) {
    return 'hinglish';
  }
  return currentPref;
}

export default function Saathi({
  navigate,
  interests = [],
}: {
  navigate: Navigate;
  interests?: string[];
}) {
  const { userProfile, weatherData } = useWeather();

  const [selectedLang, setSelectedLang] = useState<ChatLanguage>('hinglish');
  const [inputQuery, setInputQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [speechFeedback, setSpeechFeedback] = useState<string | null>(null);
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);

  const [isWhyOpen, setIsWhyOpen] = useState(false);
  const [activeWhyContext, setActiveWhyContext] = useState<StructuredCard | null>(null);

  const recognitionRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const effectiveInterests =
    userProfile.interests && userProfile.interests.length > 0
      ? userProfile.interests
      : interests.length > 0
      ? interests
      : ['commute'];

  const primaryInterestId = normalizeInterestId(effectiveInterests[0] || 'commute');
  const personaConfig = ALL_PERSONA_CONFIGS[primaryInterestId] || ALL_PERSONA_CONFIGS.commute;

  // Initial greeting generator based on language and persona
  const getInitialMessage = (lang: ChatLanguage): SaathiMessage => {
    const name = userProfile.name?.split(' ')[0] || (lang === 'hindi' ? 'मित्र' : 'Dost');
    const label = personaConfig.label;

    if (lang === 'hindi') {
      return {
        id: 'welcome-hi',
        sender: 'saathi',
        text: `नमस्ते ${name}! मैं आपका व्यक्तिगत मौसम साथी हूँ। आज आपके ${label} शेड्यूल अथवा मौसम संबंधी योजना में मैं क्या सहायता कर सकता हूँ?`,
        detectedLanguage: 'hindi',
        structuredCard: {
          headline: `आज का ${label} परामर्श`,
          verdict: personaConfig.heroInsight.title.replace(/^[^\w\s\u0900-\u097F]+/, '').trim() || 'दैनिक मौसम पूर्वानुमान एवं चेतावनी',
          temp: '28°C',
          uv: 'UV 3',
          rainChance: '45%',
          whyContext: 'मौसम विभाग के रडार एवं उपग्रह चित्रों के अनुसार वायुमंडलीय परिस्थितियां सामान्य हैं।',
          factors: [
            'स्थानीय वायुमंडलीय दबाव एवं आर्द्रता सामान्य स्तर पर',
            'दोपहर में मध्यम धूप तथा सायंकाल शीतल हवा की संभावना',
            'सड़कों एवं खुले क्षेत्रों में दृश्यता अनुकूल'
          ],
          suggestedAction: 'दैनिक मौसम एवं वायु गुणवत्ता पर नजर रखें।',
        },
      };
    }

    if (lang === 'english') {
      return {
        id: 'welcome-en',
        sender: 'saathi',
        text: `Namaste ${name}! I am your personal meteorological assistant. How can I help with your ${label} schedule or weather planning today?`,
        detectedLanguage: 'english',
        structuredCard: {
          headline: `Today’s ${label} Advisory`,
          verdict: personaConfig.heroInsight.title.replace(/^[^\w\s]+/, '').trim(),
          temp: '28°C',
          uv: 'UV 3',
          rainChance: '45%',
          whyContext: personaConfig.heroInsight.whyContext,
          factors: personaConfig.heroInsight.whyFactors,
          suggestedAction: personaConfig.heroInsight.advisoryItems[0]?.title || 'Check daily telemetry updates.',
        },
      };
    }

    // Hinglish (Default)
    return {
      id: 'welcome-hinglish',
      sender: 'saathi',
      text: `Namaste ${name}! Main hoon aapka Mausam Saathi. Aaj aapke ${label} schedule ya weather planning mein kya help kar sakta hoon?`,
      detectedLanguage: 'hinglish',
      structuredCard: {
        headline: `Today’s ${label} Advisory`,
        verdict: personaConfig.heroInsight.title.replace(/^[^\w\s]+/, '').trim(),
        temp: '28°C',
        uv: 'UV 3',
        rainChance: '45%',
        whyContext: 'IMD Doppler radar telemetry par NCR atmosphere stable hai aur moderate convective clouds hain.',
        factors: [
          'Subah halki passing showers ke baad dopahar mein weather khulega',
          'AQI aur visibility outdoor commute ke liye bilkul comfortable hai',
          'Aap mujhse baarish, workout ya highway routes ke baare mein pooch sakte hain'
        ],
        suggestedAction: personaConfig.heroInsight.advisoryItems[0]?.title || 'Daily radar forecast check karein.',
      },
    };
  };

  const [messages, setMessages] = useState<SaathiMessage[]>([getInitialMessage(selectedLang)]);

  // Re-generate welcome message when language changes if no conversation yet
  const handleLanguageChange = (newLang: ChatLanguage) => {
    setSelectedLang(newLang);
    // If only 1 welcome message exists, update it to the new language
    if (messages.length <= 1) {
      setMessages([getInitialMessage(newLang)]);
    }
  };

  // Get dynamic prompt chips in active language
  const suggestedChips = getSaathiSuggestionsForInterests(effectiveInterests, selectedLang);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  // Clean up speech synthesis on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Text-To-Speech (Audio Voice Readout)
  const toggleSpeak = (msg: SaathiMessage) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (currentlySpeakingId === msg.id) {
      window.speechSynthesis.cancel();
      setCurrentlySpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    setCurrentlySpeakingId(msg.id);

    const speechText = `${msg.text}. ${msg.structuredCard ? msg.structuredCard.verdict : ''}`;
    const utterance = new SpeechSynthesisUtterance(speechText);

    // Pick appropriate voice/language code
    const lang = msg.detectedLanguage || selectedLang;
    if (lang === 'hindi') {
      utterance.lang = 'hi-IN';
    } else {
      utterance.lang = 'en-IN';
    }
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onend = () => setCurrentlySpeakingId(null);
    utterance.onerror = () => setCurrentlySpeakingId(null);

    window.speechSynthesis.speak(utterance);
  };

  // Send query to backend /api/chat with resilient fallback
  const handleSend = async (queryText?: string) => {
    const textToSend = (queryText || inputQuery).trim();
    if (!textToSend || isThinking) return;

    // Detect if user typed in a specific language
    const detectedUserLang = clientDetectLanguage(textToSend, selectedLang);

    // Add user chat bubble
    const userMsg: SaathiMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: textToSend,
      detectedLanguage: detectedUserLang,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');

    // Trip planner trigger
    const qLower = textToSend.toLowerCase();
    if (
      qLower.includes('trip') ||
      qLower.includes('jaipur') ||
      qLower.includes('यात्रा योजना') ||
      qLower.includes('ghoomne')
    ) {
      setIsThinking(true);
      setTimeout(() => {
        setIsThinking(false);
        const tripMsg: SaathiMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'saathi',
          text:
            detectedUserLang === 'hindi'
              ? 'जयपुर के लिए एआई इंटरसिटी ट्रिप प्लानर खोला जा रहा है, जिसमें दिन-प्रतिदिन के मौसम और पैकिंग संबंधी सुझाव शामिल हैं!'
              : detectedUserLang === 'hinglish'
              ? 'Jaipur ke liye AI Intercity Trip Planner open ho raha hai, jisme day-by-day weather aur packing tips milenge!'
              : 'Opening the AI Intercity Trip Planner for Jaipur with day-by-day meteorological routing and packing tips!',
          detectedLanguage: detectedUserLang,
        };
        setMessages((prev) => [...prev, tripMsg]);
        setTimeout(() => navigate('trip-planner'), 1000);
      }, 600);
      return;
    }

    setIsThinking(true);

    try {
      // Call backend /api/chat
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: textToSend,
          language: detectedUserLang,
          persona: primaryInterestId,
          location: weatherData?.city || 'Vasundhara, Ghaziabad',
          weatherContext: {
            temperature: weatherData?.temperature || '29°C',
            condition: weatherData?.condition || 'Partly Cloudy',
            humidity: weatherData?.humidity || '82%',
            aqi: weatherData?.aqi || '128',
            wind: weatherData?.wind || '11 km/h',
          },
          history: messages.slice(-4).map((m) => ({
            sender: m.sender,
            text: m.text,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data = await response.json();
      if (data && data.text) {
        const saathiMsg: SaathiMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'saathi',
          text: data.text,
          detectedLanguage: data.detectedLanguage || detectedUserLang,
          structuredCard: data.structuredCard,
        };
        setMessages((prev) => [...prev, saathiMsg]);
      } else {
        throw new Error('Invalid response structure');
      }
    } catch (err) {
      console.warn('Network call failed, using client-side meteorological fallback:', err);
      // Client-side fallback so chatbot NEVER breaks
      const fallbackMsg = generateClientFallback(
        textToSend,
        detectedUserLang,
        weatherData?.city || 'Vasundhara, Ghaziabad'
      );
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsThinking(false);
    }
  };

  // Client-side quick fallback generator
  const generateClientFallback = (
    query: string,
    lang: ChatLanguage,
    location: string
  ): SaathiMessage => {
    const q = query.toLowerCase();

    if (
      q.includes('rain') ||
      q.includes('baarish') ||
      q.includes('barish') ||
      q.includes('umbrella') ||
      q.includes('chhaata') ||
      q.includes('chata') ||
      q.includes('वर्षा') ||
      q.includes('बारिश') ||
      q.includes('छाता')
    ) {
      if (lang === 'hindi') {
        return {
          id: Date.now().toString(),
          sender: 'saathi',
          text: 'हाँ, आज सुबह 8:30 से 9:30 बजे के बीच गरज के साथ 78% वर्षा का पूर्वानुमान है। कृपया छाता साथ रखें।',
          detectedLanguage: 'hindi',
          structuredCard: {
            headline: '☔ वर्षा एवं मौसम चेतावनी',
            verdict: 'हाँ — सुबह 8:30 बजे वर्षा की संभावना। छाता साथ रखें।',
            temp: '28°C',
            uv: 'UV 3 (मध्यम)',
            rainChance: '78%',
            whyContext: 'मौसम विभाग के डॉपलर रडार पर पश्चिमी उत्तर प्रदेश और एनसीआर के ऊपर बादलों का सघन दबाव देखा गया है।',
            factors: [
              'सुबह 8:15 से 9:30 बजे के बीच 15 मिमी तक वर्षा हो सकती है',
              'निचले इलाकों और मुख्य सड़कों पर जलभराव का अंदेशा',
              'दोपहर 11:30 बजे के बाद मौसम खुलने की उम्मीद'
            ],
            suggestedAction: 'छाता साथ रखें और समय से 15 मिनट पूर्व प्रस्थान करें।'
          }
        };
      }
      if (lang === 'english') {
        return {
          id: Date.now().toString(),
          sender: 'saathi',
          text: 'Yes, passing showers (78% probability) are expected near 8:30 AM today. Carrying an umbrella is advised.',
          detectedLanguage: 'english',
          structuredCard: {
            headline: '☔ Precipitation Advisory',
            verdict: 'Yes — Rain expected around 8:30 AM. Carry an umbrella.',
            temp: '28°C',
            uv: 'UV 3',
            rainChance: '78%',
            whyContext: 'Convective rain band is approaching over arterial NCR expressways.',
            factors: [
              'Morning rush hour downpour may cause street spray',
              'Expressway traffic speeds may decrease',
              'Clearing up with sunshine after 11:30 AM'
            ],
            suggestedAction: 'Keep umbrella handy and allow extra transit time.'
          }
        };
      }
      return {
        id: Date.now().toString(),
        sender: 'saathi',
        text: 'Haan, aaj subah 8:30 se 9:30 AM ke dauran 78% baarish ke chances hain. Chhaata zaroor saath rakhein!',
        detectedLanguage: 'hinglish',
        structuredCard: {
          headline: '☔ Baarish & Precipitation Alert',
          verdict: 'Haan — Subah 8:30 AM par baarish pakki hai. Chhaata leke niklein.',
          temp: '28°C',
          uv: 'UV 3',
          rainChance: '78%',
          whyContext: 'IMD Doppler radar par Western NCR ke upar rain clouds enter kar rahe hain.',
          factors: [
            'Morning rush hour mein tez shower ki warning',
            'Expressway aur underpasses par traffic slow ho sakta hai',
            'Dopahar 11:30 AM ke baad dhoop niklegi'
          ],
          suggestedAction: 'Chhaata saath rakhein aur 15 min pehle niklein.'
        }
      };
    }

    // Default overview fallback
    if (lang === 'hindi') {
      return {
        id: Date.now().toString(),
        sender: 'saathi',
        text: `आज ${location} में तापमान 29°C और आर्द्रता 82% है। सुबह हल्की वर्षा और दोपहर में उमस भरी धूप रहेगी।`,
        detectedLanguage: 'hindi',
        structuredCard: {
          headline: '🌤️ मौसम सारांश',
          verdict: `${location}: आंशिक बादल, 29°C। सुबह बौछारों का अनुमान।`,
          temp: '29°C',
          uv: 'UV 4',
          rainChance: '45%',
          whyContext: 'मौसम विभाग के उपग्रह चित्रों में मानसूनी बादल सक्रिय हैं।',
          factors: [
            'सुबह छिटपुट बौछारों के बाद दोपहर में धूप',
            'वायु गुणवत्ता सूचकांक (AQI) 128 सामान्य श्रेणी',
            'शाम को ठंडी हवा चलेगी'
          ],
          suggestedAction: 'आप मुझसे बारिश, कृषि अथवा यात्रा संबंधी प्रश्न पूछ सकते हैं।'
        }
      };
    }
    if (lang === 'english') {
      return {
        id: Date.now().toString(),
        sender: 'saathi',
        text: `Conditions in ${location} are partly cloudy at 29°C with 82% humidity. Isolated showers expected this morning.`,
        detectedLanguage: 'english',
        structuredCard: {
          headline: '🌤️ Meteorological Overview',
          verdict: `${location}: Partly cloudy, 29°C. Morning showers likely.`,
          temp: '29°C',
          uv: 'UV 4',
          rainChance: '45%',
          whyContext: 'Satellite and ground telemetry show steady monsoonal airflow.',
          factors: [
            'Passing showers tapering off by midday',
            'Air Quality Index at 128 (Moderate)',
            'Comfortable breeze expected after 6 PM'
          ],
          suggestedAction: 'Ask about commute, workout, or agricultural tips anytime.'
        }
      };
    }
    return {
      id: Date.now().toString(),
      sender: 'saathi',
      text: `Aaj ${location} mein mausam partly cloudy aur humid hai (29°C, 82% humidity). Subah passing showers possible hain.`,
      detectedLanguage: 'hinglish',
      structuredCard: {
        headline: '🌤️ Mausam Overview',
        verdict: `${location}: Partly cloudy, 29°C. Subah passing showers ke chances.`,
        temp: '29°C',
        uv: 'UV 4',
        rainChance: '45%',
        whyContext: 'Doppler radar sweeps steady atmospheric moisture indicate kar rahe hain.',
        factors: [
          'Subah halki baarish ke baad dopahar mein dhoop khilegi',
          'AQI 128 (Moderate) stable range mein hai',
          'Shaam ko cool breeze chalegi'
        ],
        suggestedAction: 'Aap mujhse baarish, workout, kheti ya commute ke baare mein pooch sakte hain!'
      }
    };
  };

  // Real Web Speech API voice input with simulated fallback
  const handleVoiceToggle = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      setSpeechFeedback(null);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      // Fallback if browser doesn't expose speech recognition
      setIsListening(true);
      setSpeechFeedback(
        selectedLang === 'hindi'
          ? 'आवाज सुनी जा रही है...'
          : selectedLang === 'hinglish'
          ? 'Sun rahe hain...'
          : 'Listening...'
      );
      setTimeout(() => {
        setIsListening(false);
        setSpeechFeedback(null);
        const sampleQuery =
          selectedLang === 'hindi'
            ? 'क्या आज बारिश होगी?'
            : selectedLang === 'hinglish'
            ? 'Kya aaj baarish hogi?'
            : 'Will it rain today?';
        handleSend(sampleQuery);
      }, 2000);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;
      recognition.continuous = false;
      recognition.interimResults = true;

      // Select speech language
      if (selectedLang === 'hindi') {
        recognition.lang = 'hi-IN';
      } else {
        recognition.lang = 'en-IN';
      }

      recognition.onstart = () => {
        setIsListening(true);
        setSpeechFeedback(
          selectedLang === 'hindi'
            ? 'कृपया बोलिए...'
            : selectedLang === 'hinglish'
            ? 'Boliye, sun rahe hain...'
            : 'Speak now...'
        );
      };

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((r: any) => r[0]?.transcript)
          .join('');
        if (transcript) {
          setInputQuery(transcript);
        }
      };

      recognition.onerror = (e: any) => {
        console.warn('Speech recognition notice:', e.error);
        setIsListening(false);
        setSpeechFeedback(null);
      };

      recognition.onend = () => {
        setIsListening(false);
        setSpeechFeedback(null);
        if (inputQuery.trim()) {
          handleSend(inputQuery);
        }
      };

      recognition.start();
    } catch (e) {
      console.warn('Could not start speech recognition:', e);
      setIsListening(false);
      setSpeechFeedback(null);
    }
  };

  const openWhyModal = (card: StructuredCard) => {
    setActiveWhyContext(card);
    setIsWhyOpen(true);
  };

  const resetChat = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setCurrentlySpeakingId(null);
    setMessages([getInitialMessage(selectedLang)]);
  };

  return (
    <div className="min-h-screen text-slate-900 pb-24 bg-[#F4F7FB] flex flex-col justify-between">
      {/* ─── Top Header with Atmospheric Identity & Language Selector ─── */}
      <div className="px-5 pt-3 pb-3 bg-white border-b border-slate-200/80 shadow-2xs sticky top-0 z-10">
        <div className="flex items-center justify-between gap-2">
          {/* Brand & Persona Label */}
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center">
              <div className="w-10 h-10 rounded-2xl p-0.5 bg-gradient-to-tr from-sky-400 via-indigo-500 to-amber-300 shadow-md shadow-indigo-500/20 flex items-center justify-center animate-pulse">
                <div className="w-full h-full rounded-[14px] bg-[#0A2A65] flex items-center justify-center text-white">
                  <Sparkles className="w-5 h-5 text-amber-300" />
                </div>
              </div>
              <div className="absolute -inset-1 rounded-2xl bg-indigo-400/20 blur-md -z-10" />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
                  Mausam Saathi
                </h1>
                <span className="px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 text-[10px] font-black uppercase tracking-wider border border-indigo-200/60">
                  AI
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                {selectedLang === 'hindi'
                  ? 'मौसम एवं कार्य योजना सहायक'
                  : selectedLang === 'hinglish'
                  ? 'Weather & planning assistant'
                  : 'Official IMD & MoES AI Assistant'}
              </p>
            </div>
          </div>

          {/* Quick Actions: Reset & Trip Planner */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={resetChat}
              className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-500 hover:text-slate-800 border border-slate-200 text-xs font-bold transition-all cursor-pointer"
              title="Reset conversation"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={() => navigate('trip-planner')}
              className="p-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#1A4FA0] border border-blue-200 text-xs font-bold flex items-center gap-1 cursor-pointer transition-all"
              title="Open Trip Planner"
            >
              <Compass className="w-4 h-4" />
              <span className="hidden sm:inline">Trip</span>
            </button>
          </div>
        </div>

        {/* ─── 3-Language Selector Bar [ English | Hinglish | हिंदी ] ─── */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-xs text-slate-600 font-bold">
            <Languages className="w-3.5 h-3.5 text-[#1A4FA0]" />
            <span className="text-[11px] uppercase tracking-wider text-slate-500">Language:</span>
          </div>

          <div className="inline-flex p-1 rounded-2xl bg-slate-100 border border-slate-200/80 gap-1">
            <button
              onClick={() => handleLanguageChange('english')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedLang === 'english'
                  ? 'bg-white text-[#1A4FA0] shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              English
            </button>
            <button
              onClick={() => handleLanguageChange('hinglish')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedLang === 'hinglish'
                  ? 'bg-[#1A4FA0] text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Hinglish
            </button>
            <button
              onClick={() => handleLanguageChange('hindi')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedLang === 'hindi'
                  ? 'bg-white text-[#1A4FA0] shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              हिंदी
            </button>
          </div>
        </div>
      </div>

      {/* ─── Chat / Structured Content Stream ─── */}
      <div className="flex-1 px-5 py-4 space-y-4 overflow-y-auto">
        {/* Suggested Chips Carousel */}
        <div className="space-y-1.5">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            {selectedLang === 'hindi'
              ? 'सुझाए गए प्रश्न'
              : selectedLang === 'hinglish'
              ? 'Suggested Prompts (Tap to ask)'
              : 'Suggested Prompts'}
          </span>
          <div className="flex gap-2 overflow-x-auto hide-scroll pb-1">
            {suggestedChips.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(chip)}
                className="px-3.5 py-2 rounded-2xl bg-white hover:bg-blue-50/80 text-slate-700 text-xs font-bold border border-slate-200/90 shadow-2xs shrink-0 transition-all active:scale-[0.98] cursor-pointer"
              >
                {chip}
              </button>
            ))}
          </div>
        </div>

        {/* Message Thread */}
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.sender === 'user' ? 'items-end' : 'items-start'
            }`}
          >
            {/* User Chat Bubble */}
            {msg.sender === 'user' ? (
              <div className="max-w-[85%] px-4 py-3 rounded-3xl rounded-tr-xs bg-[#1A4FA0] text-white text-xs sm:text-sm font-bold shadow-xs">
                {msg.text}
              </div>
            ) : (
              /* Saathi Structured AI Bubble */
              <div className="w-full space-y-2.5">
                {/* Conversational Text & Audio Speak Button */}
                <div className="flex items-start justify-between gap-2 px-1">
                  <p className="text-xs sm:text-sm text-slate-700 font-semibold leading-relaxed">
                    {msg.text}
                  </p>
                  <button
                    onClick={() => toggleSpeak(msg)}
                    className={`p-1.5 rounded-xl border shrink-0 transition-all cursor-pointer ${
                      currentlySpeakingId === msg.id
                        ? 'bg-amber-100 text-amber-900 border-amber-300 animate-pulse'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-200'
                    }`}
                    title={currentlySpeakingId === msg.id ? 'Stop audio' : 'Listen to voice'}
                  >
                    {currentlySpeakingId === msg.id ? (
                      <VolumeX className="w-3.5 h-3.5" />
                    ) : (
                      <Volume2 className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Structured Card Response */}
                {msg.structuredCard && (
                  <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-sm space-y-3.5">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                      <span className="text-xs font-black text-[#1A4FA0] flex items-center gap-1.5 uppercase tracking-wider">
                        <Sparkles className="w-3.5 h-3.5" />
                        {msg.structuredCard.headline}
                      </span>
                      <span className="text-[10px] font-bold text-slate-500 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-200">
                        IMD Radar Telemetry
                      </span>
                    </div>

                    {/* Bold Clear Verdict */}
                    <div className="text-sm sm:text-base font-black text-slate-900 leading-snug">
                      {msg.structuredCard.verdict}
                    </div>

                    {/* 3 Metric Pills */}
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="p-2 rounded-2xl bg-slate-50 border border-slate-200">
                        <span className="text-[10px] text-slate-500 font-bold block">
                          TEMP
                        </span>
                        <span className="text-xs font-black text-slate-900">
                          {msg.structuredCard.temp}
                        </span>
                      </div>
                      <div className="p-2 rounded-2xl bg-slate-50 border border-slate-200">
                        <span className="text-[10px] text-slate-500 font-bold block">
                          UV
                        </span>
                        <span className="text-xs font-black text-slate-900">
                          {msg.structuredCard.uv}
                        </span>
                      </div>
                      <div className="p-2 rounded-2xl bg-slate-50 border border-slate-200">
                        <span className="text-[10px] text-slate-500 font-bold block">
                          RAIN
                        </span>
                        <span className="text-xs font-black text-blue-600">
                          {msg.structuredCard.rainChance}
                        </span>
                      </div>
                    </div>

                    {/* Interactive "Why?" Button & Actionable Tip */}
                    <div className="pt-1 flex items-center justify-between gap-2">
                      <button
                        onClick={() => openWhyModal(msg.structuredCard!)}
                        className="py-2 px-3.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#1A4FA0] text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Info className="w-3.5 h-3.5" />
                        <span>
                          {selectedLang === 'hindi'
                            ? 'कारण देखें (Why?)'
                            : selectedLang === 'hinglish'
                            ? 'Kyun? (Reason)'
                            : 'Why?'}
                        </span>
                      </button>

                      {msg.structuredCard.suggestedAction && (
                        <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-xl border border-emerald-200/60 font-bold text-right truncate">
                          {msg.structuredCard.suggestedAction}
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}

        {/* ─── Thinking / Analyzing Indicator ─── */}
        {isThinking && (
          <div className="flex items-center gap-2 p-3 rounded-2xl bg-white border border-slate-200/80 shadow-2xs max-w-[280px]">
            <Loader2 className="w-4 h-4 text-[#1A4FA0] animate-spin" />
            <span className="text-xs font-bold text-slate-600">
              {selectedLang === 'hindi'
                ? 'मौसम साथी विश्लेषण कर रहा है...'
                : selectedLang === 'hinglish'
                ? 'Mausam Saathi radar check kar raha hai...'
                : 'Mausam Saathi is analyzing telemetry...'}
            </span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* ─── Listening Waveform Modal / Overlay ─── */}
      {isListening && (
        <div className="p-4 mx-5 mb-2 rounded-3xl bg-slate-900 text-white shadow-xl border border-slate-800 flex items-center justify-between animate-in fade-in duration-200">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-rose-600 flex items-center justify-center animate-pulse">
              <Mic className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-xs font-bold block text-rose-300">
                {speechFeedback ||
                  (selectedLang === 'hindi'
                    ? 'हिंदी में सुन रहे हैं...'
                    : selectedLang === 'hinglish'
                    ? 'Hinglish mein sun rahe hain...'
                    : 'Listening in English...')}
              </span>
              {/* Animated sound wave bars */}
              <div className="flex items-center gap-1 mt-1">
                {[4, 12, 8, 16, 10, 14, 6].map((h, i) => (
                  <div
                    key={i}
                    className="w-1 bg-sky-400 rounded-full animate-bounce"
                    style={{
                      height: `${h}px`,
                      animationDelay: `${i * 0.15}s`,
                    }}
                  />
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              if (recognitionRef.current) {
                recognitionRef.current.stop();
              }
              setIsListening(false);
              setSpeechFeedback(null);
            }}
            className="text-xs font-bold text-slate-400 hover:text-white px-2 py-1 cursor-pointer"
          >
            Cancel
          </button>
        </div>
      )}

      {/* ─── Bottom Chat & Voice Input Control Bar ─── */}
      <div className="px-5 pt-2 pb-2 bg-white border-t border-slate-200/90 shadow-lg">
        <div className="flex items-center gap-2">
          {/* Voice Microphone Button */}
          <button
            onClick={handleVoiceToggle}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all cursor-pointer shrink-0 ${
              isListening
                ? 'bg-rose-600 text-white shadow-md animate-pulse'
                : 'bg-blue-50 text-[#1A4FA0] hover:bg-blue-100'
            }`}
            title={`Speak in ${selectedLang}`}
          >
            <Mic className="w-5 h-5" />
          </button>

          {/* Text Input Field */}
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={
                selectedLang === 'hindi'
                  ? 'मौसम, वर्षा, खेती या यात्रा के बारे में पूछें...'
                  : selectedLang === 'hinglish'
                  ? 'Mausam, baarish, route ya schedule ke baare mein poochein...'
                  : 'Ask about rain, routes, humidity or your day...'
              }
              className="w-full h-12 pl-4 pr-11 rounded-2xl bg-slate-50 border border-slate-200 text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] focus:bg-white transition-all"
            />
            <button
              onClick={() => handleSend()}
              disabled={!inputQuery.trim() || isThinking}
              className="absolute right-1.5 top-1.5 w-9 h-9 rounded-xl bg-[#1A4FA0] text-white flex items-center justify-center disabled:opacity-40 transition-all cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* ─── Interactive "Why?" Reason Bottom Sheet ─── */}
      <WeatherReasonSheet
        isOpen={isWhyOpen}
        onClose={() => setIsWhyOpen(false)}
        title={
          selectedLang === 'hindi'
            ? 'मौसम संबंधी वैज्ञानिक कारण'
            : selectedLang === 'hinglish'
            ? 'Is Salah Ke Peeche Scientific Reason'
            : 'Why are we suggesting this?'
        }
        context={activeWhyContext?.whyContext || 'Weather forecast conditions optimize after 6 PM.'}
        data={{
          rainProbability: activeWhyContext?.rainChance || '8%',
          visibility: 'Good (>8 km)',
          humidity: '74%',
          temperature: activeWhyContext?.temp || '28°C',
          source: 'IMD Doppler Weather Radar & Safdarjung Telemetry',
          lastUpdated: 'Just now',
          factors: activeWhyContext?.factors || [
            'Convective instability monitored below storm alert levels',
            'Boundary layer thermal cooling keeps diurnal index safe',
          ],
        }}
      />
    </div>
  );
}
