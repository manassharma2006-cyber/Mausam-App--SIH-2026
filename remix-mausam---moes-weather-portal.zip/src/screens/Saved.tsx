import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import { majorIndianCities } from '../data/indianLocations';
import type { LocationInfo } from '../types';
import {
  Bookmark,
  MapPin,
  Search,
  Plus,
  Trash2,
  Check,
  CloudRain,
  ChevronRight,
  Sun,
  Compass,
  ArrowRight,
  Calendar,
  Layers,
  Sparkles,
  WifiOff,
} from 'lucide-react';

export default function Saved({ navigate }: { navigate: Navigate }) {
  const {
    savedLocations,
    toggleSaveLocation,
    switchLocation,
    weatherData,
    formatTemp,
  } = useWeather();

  const [activeTab, setActiveTab] = useState<'locations' | 'trips'>('locations');
  const [isSearching, setIsSearching] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const currentStation = weatherData.location?.stationId;

  const filtered = majorIndianCities.filter(
    (c) =>
      c.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.stateEn.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen text-slate-900 pb-24 bg-[#F4F7FB]">
      {/* ─── Top Header ─── */}
      <div className="px-5 pt-4 pb-3 bg-white border-b border-slate-200/90 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Saved Collection
            </span>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">
              Saved & Offline
            </h1>
          </div>

          <button
            onClick={() => setIsSearching(!isSearching)}
            className="p-2.5 rounded-2xl bg-blue-50 hover:bg-blue-100 text-[#1A4FA0] border border-blue-200/60 transition-all cursor-pointer"
            title="Add Location"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Segmented Tabs: Locations / Trips */}
        <div className="p-1 rounded-2xl bg-slate-100 flex gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('locations')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'locations'
                ? 'bg-white text-[#1A4FA0] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Saved Locations ({savedLocations.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('trips')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'trips'
                ? 'bg-white text-[#1A4FA0] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Trip Plans (1)
          </button>
        </div>

        {isSearching && (
          <div className="mt-3 relative animate-in fade-in">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Indian city or IMD station..."
              className="w-full pl-9 pr-3.5 py-2.5 text-xs font-bold rounded-2xl text-slate-900 bg-slate-50 border border-slate-200 focus:outline-none focus:bg-white focus:border-[#1A4FA0]"
              autoFocus
            />
          </div>
        )}
      </div>

      <div className="px-5 py-4 space-y-4">
        {/* ─── Search Results Drawer if searching ─── */}
        {isSearching && (
          <div className="bg-white p-3.5 rounded-3xl border border-slate-200 shadow-md max-h-56 overflow-y-auto space-y-1.5 hide-scroll">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2">
              Available IMD Stations
            </div>
            {filtered.slice(0, 8).map((c) => {
              const isSaved = savedLocations.some((s) => s.stationId === c.stationId);
              return (
                <div
                  key={c.stationId}
                  className="flex items-center justify-between p-2.5 rounded-2xl hover:bg-slate-50 border border-slate-100"
                >
                  <div>
                    <span className="text-xs font-bold text-slate-800 block">
                      {c.nameEn}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {c.stateEn} • AWS #{c.stationId}
                    </span>
                  </div>
                  <button
                    onClick={() => toggleSaveLocation(c)}
                    className={`p-2 rounded-xl text-xs font-bold transition-all ${
                      isSaved
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'bg-[#1A4FA0] text-white'
                    }`}
                  >
                    {isSaved ? 'Saved ✓' : '+ Add'}
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {/* ─── TAB 1: SAVED LOCATIONS ─── */}
        {activeTab === 'locations' && (
          <div className="space-y-3">
            {savedLocations.map((loc) => {
              const isCurrent = loc.stationId === currentStation;
              return (
                <div
                  key={loc.stationId}
                  onClick={() => {
                    switchLocation(loc);
                    navigate('home');
                  }}
                  className={`p-4.5 rounded-3xl border transition-all cursor-pointer ${
                    isCurrent
                      ? 'bg-white border-[#1A4FA0] shadow-sm ring-1 ring-[#1A4FA0]/30'
                      : 'bg-white border-slate-200/90 shadow-2xs hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                          isCurrent
                            ? 'bg-blue-50 text-[#1A4FA0]'
                            : 'bg-slate-50 text-slate-600'
                        }`}
                      >
                        <MapPin className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-black text-slate-900">
                            {loc.nameEn}
                          </h3>
                          {isCurrent && (
                            <span className="px-2 py-0.5 rounded-full bg-blue-100 text-[#0A2A65] text-[10px] font-black uppercase">
                              Active
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 font-medium">
                          {loc.stateEn} • {loc.elevation}m ASL
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-lg font-black text-slate-900">
                        {isCurrent ? formatTemp(weatherData.current.tempC) : '31°'}
                      </div>
                      <span className="text-[11px] font-semibold text-slate-500">
                        {isCurrent ? weatherData.current.conditionEn : 'Partly Cloudy'}
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
                      <WifiOff className="w-3 h-3 text-slate-400" />
                      Cached offline: 8:12 AM
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSaveLocation(loc);
                      }}
                      className="text-rose-500 hover:text-rose-700 p-1 text-[11px] font-bold"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ─── TAB 2: TRIP PLANS ─── */}
        {activeTab === 'trips' && (
          <div className="space-y-3">
            <div
              onClick={() => navigate('trip-planner')}
              className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs hover:shadow-xs transition-all cursor-pointer space-y-3"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold">
                    <Compass className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-black uppercase">
                      Leisure Itinerary
                    </span>
                    <h3 className="text-base font-black text-slate-900 mt-1">
                      Jaipur, Rajasthan
                    </h3>
                    <p className="text-xs text-slate-500 font-medium flex items-center gap-1 mt-0.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>18–21 Sep (4 Days)</span>
                    </p>
                  </div>
                </div>

                <ChevronRight className="w-5 h-5 text-slate-400" />
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-700 flex items-center justify-between">
                <span>Weather outlook: Mostly sunny, 32°/24°C</span>
                <span className="font-bold text-emerald-700">Safe Window</span>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                <span>Available fully offline</span>
                <span className="font-bold text-[#1A4FA0] flex items-center gap-1">
                  <span>View Day Plan</span>
                  <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>

            <button
              onClick={() => navigate('trip-planner')}
              className="w-full py-3.5 rounded-2xl bg-white hover:bg-slate-50 text-[#1A4FA0] font-bold text-xs border border-dashed border-blue-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Plan another city trip</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
