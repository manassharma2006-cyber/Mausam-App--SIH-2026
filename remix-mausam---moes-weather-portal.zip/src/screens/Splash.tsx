import React from 'react';
import type { Navigate } from '../App';
import MausamBrandMark from '../components/MausamBrandMark';
import { ArrowRight, Sparkles, Cloud, Sun, Wind, Droplets, ShieldCheck } from 'lucide-react';

export default function Splash({ navigate }: { navigate: Navigate }) {
  return (
    <div
      className="min-h-screen flex flex-col justify-between px-6 pt-6 pb-8 relative overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, #F0F7FF 0%, #E2EFFE 45%, #F8FAFC 100%)',
      }}
    >
      {/* Soft Ambient Weather Atmosphere in Background */}
      <div className="absolute -top-16 -right-16 w-72 h-72 rounded-full bg-sky-200/50 blur-3xl pointer-events-none" />
      <div className="absolute top-1/4 -left-20 w-60 h-60 rounded-full bg-amber-100/60 blur-3xl pointer-events-none" />
      <div className="absolute bottom-32 right-0 w-48 h-48 rounded-full bg-blue-100/60 blur-2xl pointer-events-none" />

      {/* Top Tag */}
      <div className="relative z-10 flex justify-center pt-2">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/80 backdrop-blur-md border border-sky-100 shadow-xs text-xs font-semibold text-[#1A4FA0]">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Official IMD Meteorological Data</span>
        </div>
      </div>

      {/* ─── Hero Illustrated Weather Area (55–65% of screen) ─── */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center my-auto py-6">
        {/* Floating Illustrated Scene */}
        <div className="relative mb-7 flex items-center justify-center">
          {/* Outer floating weather icons */}
          <div className="absolute -top-3 -left-6 p-2 rounded-2xl bg-white/90 shadow-md border border-white text-amber-500 animate-bounce duration-1000">
            <Sun className="w-5 h-5" />
          </div>
          <div className="absolute -bottom-2 -right-5 p-2 rounded-2xl bg-white/90 shadow-md border border-white text-sky-500 animate-pulse">
            <Cloud className="w-5 h-5" />
          </div>
          <div className="absolute top-1/2 -right-8 p-1.5 rounded-xl bg-white/80 shadow-xs border border-white text-blue-500">
            <Droplets className="w-4 h-4" />
          </div>
          <div className="absolute bottom-2 -left-7 p-1.5 rounded-xl bg-white/80 shadow-xs border border-white text-teal-600">
            <Wind className="w-4 h-4" />
          </div>

          {/* Large distinctive Mausam brand mark */}
          <MausamBrandMark size="lg" />
        </div>

        {/* Brand Typography & Copywriting */}
        <div className="text-center max-w-xs space-y-2">
          <div className="flex items-center justify-center gap-2">
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
              Mausam
            </h1>
            <span className="text-sm font-bold text-amber-500 font-devanagari px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200">
              मौसम
            </span>
          </div>

          <p className="text-lg font-bold text-slate-800 leading-snug">
            Weather that understands your life.
          </p>

          <p className="text-xs text-slate-600 leading-relaxed pt-1">
            Personal weather guidance powered by trusted meteorological data, tailored around your daily routine.
          </p>
        </div>

        {/* Highlight Feature Badges */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-5">
          <span className="px-3 py-1 rounded-full bg-white/80 border border-slate-200/80 text-[11px] font-semibold text-slate-700 shadow-2xs">
            🏃 Running Windows
          </span>
          <span className="px-3 py-1 rounded-full bg-white/80 border border-slate-200/80 text-[11px] font-semibold text-slate-700 shadow-2xs">
            🚗 Commute Rain
          </span>
          <span className="px-3 py-1 rounded-full bg-white/80 border border-slate-200/80 text-[11px] font-semibold text-slate-700 shadow-2xs">
            🤖 Saathi AI
          </span>
        </div>
      </div>

      {/* ─── Actions Section (Comfortably above bottom safe area) ─── */}
      <div className="relative z-10 w-full space-y-3 pb-2">
        {/* Primary CTA */}
        <button
          onClick={() => navigate('login')}
          className="w-full h-14 rounded-2xl text-white font-bold text-base flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] hover:shadow-xl cursor-pointer"
          style={{
            background: 'linear-gradient(135deg, #1A4FA0 0%, #2563EB 100%)',
            boxShadow: '0 8px 24px -4px rgba(26, 79, 160, 0.35)',
          }}
        >
          <span>Get Started</span>
          <ArrowRight className="w-5 h-5" />
        </button>

        {/* Secondary CTA */}
        <button
          onClick={() => navigate('home')}
          className="w-full h-13 rounded-2xl bg-white/90 hover:bg-white text-slate-700 font-bold text-sm border border-slate-200/90 shadow-2xs transition-all active:scale-[0.98] cursor-pointer"
        >
          Continue as Guest
        </button>

        {/* Small Bottom Line */}
        <div className="text-center pt-1">
          <p className="text-[11px] font-medium text-slate-600">
            Official weather intelligence. Made personal.
          </p>
        </div>
      </div>
    </div>
  );
}
