import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  Compass,
  ArrowLeft,
  Calendar,
  MapPin,
  Sparkles,
  CloudRain,
  Sun,
  Flame,
  Luggage,
  Bookmark,
  Bell,
  CheckCircle2,
  Share2,
  ChevronRight,
  WifiOff,
} from 'lucide-react';

interface DayPlan {
  day: string;
  date: string;
  icon: string;
  weather: string;
  tempRange: string;
  outingWindow: string;
  rainRisk: string;
  heatIndex: string;
  packingTip: string;
}

export default function TripPlanner({ navigate }: { navigate: Navigate }) {
  const [destination, setDestination] = useState('Jaipur');
  const [startDate, setStartDate] = useState('2026-09-18');
  const [endDate, setEndDate] = useState('2026-09-21');
  const [tripType, setTripType] = useState('Leisure');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isSaved, setIsSaved] = useState(false);
  const [isAlertSet, setIsAlertSet] = useState(false);

  const tripTypes = ['Leisure', 'Adventure', 'Family', 'Business'];
  const popularDestinations = [
    'Jaipur',
    'Shimla',
    'Goa',
    'Manali',
    'Udaipur',
    'Varanasi',
    'Nainital',
  ];

  const dayCards: DayPlan[] = [
    {
      day: 'Day 1',
      date: 'Fri, 18 Sep',
      icon: '🌤️',
      weather: 'Mostly Sunny & Warm',
      tempRange: '32° / 24°C',
      outingWindow: '08:30 – 11:30 AM & 05:00 – 07:30 PM',
      rainRisk: '10% Low Risk',
      heatIndex: 'Moderate (Drink water)',
      packingTip: 'Light cotton shirts, UV sunglasses & comfortable walking footwear.',
    },
    {
      day: 'Day 2',
      date: 'Sat, 19 Sep',
      icon: '☀️',
      weather: 'Bright Clear Sky',
      tempRange: '34° / 25°C',
      outingWindow: '07:30 – 10:30 AM & 05:30 – 08:00 PM',
      rainRisk: '5% Clear',
      heatIndex: 'High midday (Seek indoor palaces 1–4 PM)',
      packingTip: 'Sunscreen lotion SPF 50+, wide-brim hat & electrolyte packet.',
    },
    {
      day: 'Day 3',
      date: 'Sun, 20 Sep',
      icon: '🌦️',
      weather: 'Passing Afternoon Shower',
      tempRange: '30° / 23°C',
      outingWindow: '09:00 AM – 1:00 PM',
      rainRisk: '45% Afternoon Shower',
      heatIndex: 'Pleasant & Cool',
      packingTip: 'Compact folding umbrella & quick-dry shoes for outdoor fort visits.',
    },
    {
      day: 'Day 4',
      date: 'Mon, 21 Sep',
      icon: '⛅',
      weather: 'Pleasant Overcast',
      tempRange: '31° / 23°C',
      outingWindow: 'All day outdoor friendly',
      rainRisk: '15% Low Risk',
      heatIndex: 'Comfortable',
      packingTip: 'Comfortable road trip outfit & light evening wrap.',
    },
  ];

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleSaveTrip = () => {
    setIsSaved(true);
    triggerToast('Trip to Jaipur saved for offline access in Saved tab!');
  };

  const handleSetAlerts = () => {
    setIsAlertSet(true);
    triggerToast('Severe weather & departure alerts activated for Jaipur trip!');
  };

  return (
    <div className="min-h-screen text-slate-900 pb-24 bg-[#F4F7FB]">
      {/* ─── Top Header ─── */}
      <div className="px-5 pt-4 pb-3 bg-white border-b border-slate-200/90 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => navigate('saathi')}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-xl bg-slate-50 border border-slate-200/80 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Saathi</span>
          </button>

          <span className="px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200/80 text-[11px] font-black text-indigo-800 uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-indigo-600" />
            <span>AI Trip Planner</span>
          </span>
        </div>

        <div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">
            Intercity Weather Planner
          </h1>
          <p className="text-xs text-slate-500 font-medium">
            Personalized day-by-day weather itineraries and packing tips
          </p>
        </div>
      </div>

      <div className="px-5 py-4 space-y-4">
        {/* ─── Trip Setup Form Card ─── */}
        <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-3.5">
          {/* Destination Selector */}
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#1A4FA0]" />
              <span>Destination City</span>
            </label>
            <select
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className="w-full h-12 px-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] cursor-pointer"
            >
              {popularDestinations.map((city) => (
                <option key={city} value={city}>
                  {city}, India
                </option>
              ))}
            </select>
          </div>

          {/* Travel Dates Calendar Picker */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">
                Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full h-11 px-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] cursor-pointer"
              />
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">
                End Date
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full h-11 px-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#1A4FA0] cursor-pointer"
              />
            </div>
          </div>

          {/* Trip Type Chips */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 block">
              Trip Style
            </label>
            <div className="flex gap-2">
              {tripTypes.map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setTripType(type)}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    tripType === type
                      ? 'bg-[#1A4FA0] text-white border-[#1A4FA0] shadow-2xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* ─── Destination Overview Banner ─── */}
        <div className="p-4 rounded-3xl bg-gradient-to-r from-blue-900 to-indigo-900 text-white shadow-md flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-blue-200 uppercase tracking-wider">
              {tripType} Itinerary
            </span>
            <h2 className="text-lg font-black tracking-tight">
              {destination} · 18–21 Sep
            </h2>
            <p className="text-xs text-blue-200 font-medium">
              4 Days • 270 km from Delhi NCR • Safe Travel Window
            </p>
          </div>

          <span className="px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-md text-[10px] font-bold border border-white/20">
            Available Offline
          </span>
        </div>

        {/* ─── Day-by-Day Cards Stream ─── */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
              Day-by-Day Meteorological Plan
            </h3>
            <span className="text-[11px] font-bold text-slate-500">
              4 Days Forecast
            </span>
          </div>

          {dayCards.map((card, idx) => (
            <div
              key={idx}
              className="p-4.5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-3"
            >
              {/* Card Header: Day, Weather, Temp */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="text-2xl">{card.icon}</span>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-slate-900">
                        {card.day}
                      </span>
                      <span className="text-xs text-slate-500 font-bold">
                        ({card.date})
                      </span>
                    </div>
                    <span className="text-xs font-bold text-slate-700">
                      {card.weather}
                    </span>
                  </div>
                </div>

                <span className="text-xs font-black text-slate-900 px-2.5 py-1 rounded-xl bg-slate-50 border border-slate-200">
                  {card.tempRange}
                </span>
              </div>

              {/* Recommended Outing Time */}
              <div className="p-3 rounded-2xl bg-blue-50/70 border border-blue-100/90 text-xs">
                <span className="text-[10px] font-bold text-[#1A4FA0] uppercase tracking-wider block mb-0.5">
                  Recommended Outing Time:
                </span>
                <span className="font-bold text-slate-900">{card.outingWindow}</span>
              </div>

              {/* Rain Risk & Heat Index Badges */}
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 font-bold block text-[10px]">
                    Rain Risk
                  </span>
                  <span className="font-black text-slate-900 flex items-center gap-1">
                    <CloudRain className="w-3 h-3 text-blue-600" />
                    {card.rainRisk}
                  </span>
                </div>

                <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 font-bold block text-[10px]">
                    Heat Comfort
                  </span>
                  <span className="font-black text-slate-900 flex items-center gap-1">
                    <Sun className="w-3 h-3 text-amber-500" />
                    {card.heatIndex.split('(')[0]}
                  </span>
                </div>
              </div>

              {/* Smart Packing Tip */}
              <div className="flex items-start gap-2 pt-1 text-xs text-slate-600 font-medium">
                <Luggage className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Packing Tip:</strong> {card.packingTip}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* ─── Actions: Save Trip & Set Alerts ─── */}
        <div className="pt-2 space-y-2.5">
          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={handleSaveTrip}
              className={`py-3 px-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                isSaved
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-2xs'
                  : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50 shadow-2xs'
              }`}
            >
              <Bookmark className="w-4 h-4 text-emerald-600" />
              <span>{isSaved ? 'Trip Saved ✓' : 'Save Trip'}</span>
            </button>

            <button
              onClick={handleSetAlerts}
              className={`py-3 px-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                isAlertSet
                  ? 'bg-blue-50 text-blue-800 border-blue-300 shadow-2xs'
                  : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50 shadow-2xs'
              }`}
            >
              <Bell className="w-4 h-4 text-[#1A4FA0]" />
              <span>{isAlertSet ? 'Alerts Active ✓' : 'Set Alerts'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* ─── Toast Feedback Notification ─── */}
      {toastMessage && (
        <div className="fixed bottom-20 left-6 right-6 z-50 p-3.5 rounded-2xl bg-slate-900 text-white text-xs font-bold shadow-2xl border border-slate-800 flex items-center gap-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
