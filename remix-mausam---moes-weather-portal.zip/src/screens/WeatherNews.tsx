import React, { useState } from 'react';
import type { Navigate } from '../App';
import { useWeather } from '../context/WeatherContext';
import {
  ArrowLeft,
  Newspaper,
  Calendar,
  CloudRain,
  ExternalLink,
  ShieldCheck,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

interface NewsArticle {
  id: string;
  category: string;
  titleEn: string;
  titleHi: string;
  date: string;
  readTime: string;
  summaryEn: string;
  summaryHi: string;
  source: string;
}

export default function WeatherNews({ navigate }: { navigate: Navigate }) {
  const { language } = useWeather();
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);

  const articles: NewsArticle[] = [
    {
      id: '1',
      category: 'Monsoon Bulletin',
      titleEn: 'Southwest Monsoon advances across northern plains with widespread precipitation',
      titleHi: 'उत्तर भारत के मैदानी इलाकों में आगे बढ़ा दक्षिण-पश्चिम मानसून, कई राज्यों में व्यापक वर्षा',
      date: 'Today, 08:30 AM IST',
      readTime: '3 min read',
      summaryEn: 'The Northern Limit of Monsoon (NLM) continues to trigger active convection over northwest and central India. Rainfall departures are expected to remain positive over the next 5 days.',
      summaryHi: 'मानसून की उत्तरी सीमा उत्तर-पश्चिम एवं मध्य भारत में सक्रिय है। आगामी 5 दिनों के दौरान सामान्य से अधिक वर्षा की संभावना व्यक्त की गई है।',
      source: 'National Weather Forecasting Centre, New Delhi',
    },
    {
      id: '2',
      category: 'Agro Outlook',
      titleEn: 'IMD releases seasonal rainfall outlook for Rabi sowing season',
      titleHi: 'आईएमडी ने रबी फसलों की बुवाई हेतु मौसमी वर्षा दृष्टिकोण जारी किया',
      date: 'Yesterday, 05:00 PM IST',
      readTime: '4 min read',
      summaryEn: 'Soil moisture reserves across Punjab, Haryana, and Western Uttar Pradesh show favorable initial conditions for wheat and mustard germination.',
      summaryHi: 'पंजाब, हरियाणा और पश्चिमी उत्तर प्रदेश में मृदा नमी भंडार गेहूं व सरसों के अंकुरण के लिए अत्यंत अनुकूल स्थिति में हैं।',
      source: 'Agrimet Division, Pune',
    },
    {
      id: '3',
      category: 'Marine & Cyclone',
      titleEn: 'Bay of Bengal cyclonic circulation monitored by INSAT-3DR and Doppler Radars',
      titleHi: 'बंगाल की खाड़ी में बने चक्रवाती परिसंचरण पर इनसैट-3डीआर उपग्रह की निगरानी',
      date: 'Sep 09, 2026',
      readTime: '2 min read',
      summaryEn: 'Fishermen along the Odisha and Andhra Pradesh coastlines are cautioned against venturing into deep sea waters beyond 40 nautical miles.',
      summaryHi: 'ओडिशा व आंध्र प्रदेश तटवर्ती मछुआरों को 40 नॉटिकल मील से दूर गहरे समुद्र में न जाने का परामर्श जारी किया गया है।',
      source: 'Cyclone Warning Division, IMD',
    },
  ];

  return (
    <div className="min-h-screen text-slate-900 pb-8" style={{ background: 'var(--m-bg)' }}>
      {/* Deep Navy News Header */}
      <div
        className="text-white px-5 pt-3 pb-6 rounded-b-3xl shadow-lg relative overflow-hidden"
        style={{
          background: 'linear-gradient(175deg, #0F2952 0%, #173B6F 50%, #1A4FA0 100%)',
        }}
      >
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-1 text-xs font-bold text-blue-200 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </button>
          <span className="text-[11px] font-bold text-amber-300 font-emblem tracking-wider">
            IMD PRESS WIRE
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
            <Newspaper className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-white">Official Weather News</h1>
            <p className="text-xs text-blue-200 font-devanagari">
              मौसम समाचार, प्रेस विज्ञप्तियां एवं वैज्ञानिक बुलेटिन
            </p>
          </div>
        </div>
      </div>

      <div className="px-5 py-4 space-y-3">
        {/* Article Cards */}
        {articles.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedArticle(item)}
            className="p-4 rounded-3xl bg-white border border-slate-200/80 shadow-sm cursor-pointer hover:border-blue-300 transition-all space-y-2"
          >
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-blue-100 text-blue-800 uppercase tracking-wider">
                {item.category}
              </span>
              <span className="text-[10px] text-slate-400 font-medium">{item.date}</span>
            </div>

            <h3 className="font-extrabold text-xs text-slate-900 leading-snug">
              {language === 'hi' ? item.titleHi : item.titleEn}
            </h3>

            <p className="text-[11px] text-slate-600 leading-relaxed line-clamp-2">
              {language === 'hi' ? item.summaryHi : item.summaryEn}
            </p>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-500 font-medium">
              <span>{item.source}</span>
              <span className="text-blue-700 font-bold flex items-center gap-0.5">
                Read Full →
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Article Detail Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 max-h-[80vh] overflow-y-auto hide-scroll">
            <div className="flex items-center justify-between mb-3">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-blue-100 text-blue-800">
                {selectedArticle.category}
              </span>
              <button
                onClick={() => setSelectedArticle(null)}
                className="text-xs font-bold text-slate-500 hover:text-slate-800"
              >
                Close ✕
              </button>
            </div>

            <h2 className="text-base font-extrabold text-slate-900 leading-snug mb-2">
              {language === 'hi' ? selectedArticle.titleHi : selectedArticle.titleEn}
            </h2>

            <div className="text-[10px] text-slate-400 font-mono mb-4">
              Published: {selectedArticle.date} • {selectedArticle.source}
            </div>

            <div className="text-xs text-slate-700 leading-relaxed space-y-3 mb-6">
              <p>{language === 'hi' ? selectedArticle.summaryHi : selectedArticle.summaryEn}</p>
              <p>
                Radar observations from New Delhi (Palam), Amritsar, Patiala, and Chandigarh corroborating atmospheric moisture convergence over the Sutlej-Ganges plains. Surface winds registered at 15 to 25 km/h with localized gusts reaching 40 km/h during squall passages.
              </p>
            </div>

            <button
              onClick={() => setSelectedArticle(null)}
              className="w-full py-3 rounded-xl bg-[#1A4FA0] text-white text-xs font-bold shadow-md"
            >
              Done Reading
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
