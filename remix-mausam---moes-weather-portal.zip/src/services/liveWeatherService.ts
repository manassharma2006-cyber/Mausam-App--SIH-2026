import type { PersonaWeatherData, PersonaType, AppLanguage } from '../types';

export interface LiveWeatherResponse {
  success: boolean;
  data: PersonaWeatherData;
  source: string;
  coordinates: {
    latitude: number;
    longitude: number;
  };
}

export async function fetchLiveWeatherByQuery(
  query: string,
  persona: PersonaType = 'farmer',
  _language: AppLanguage = 'en'
): Promise<PersonaWeatherData> {
  const url = `/api/weather?query=${encodeURIComponent(query)}&persona=${persona}`;
  const res = await fetch(url);
  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || `Weather request failed with status ${res.status}`);
  }
  const result: LiveWeatherResponse = await res.json();
  return result.data;
}

export async function fetchLiveWeatherByCoords(
  lat: number,
  lng: number,
  locationName: string = 'Current Location',
  stateName: string = 'India',
  persona: PersonaType = 'farmer',
  _language: AppLanguage = 'en'
): Promise<PersonaWeatherData> {
  const url = `/api/weather?lat=${lat}&lng=${lng}&locationName=${encodeURIComponent(
    locationName
  )}&stateName=${encodeURIComponent(stateName)}&persona=${persona}`;
  const res = await fetch(url);
  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || `Weather request failed with status ${res.status}`);
  }
  const result: LiveWeatherResponse = await res.json();
  return result.data;
}

export async function checkBackendHealth(): Promise<{
  hasGoogleMapsKey: boolean;
  hasGeminiKey: boolean;
  activeWeatherEngine: string;
}> {
  try {
    const res = await fetch('/api/health');
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('Health check error:', err);
  }
  return {
    hasGoogleMapsKey: false,
    hasGeminiKey: false,
    activeWeatherEngine: 'Live High-Precision Global Telemetry (ECMWF/WMO)',
  };
}
