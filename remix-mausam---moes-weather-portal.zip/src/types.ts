export type PersonaType = 'farmer' | 'commuter' | 'traveler';
export type AppLanguage = 'en' | 'hi';

export type Navigate = (screen: string) => void;

export interface LocationInfo {
  nameEn: string;
  nameHi: string;
  stateEn: string;
  stateHi: string;
  coordinates: string;
  elevation: string;
  stationId: string;
  districtEn?: string;
  districtHi?: string;
  pinCode?: string;
  stationType?: string;
  telemetryStatus?: string;
  climateZone?: string;
  agroZone?: string;
  coastalZone?: string;
  terrain?: string;
  recommendedPersona?: PersonaType;
}

export interface HourlyForecast {
  time: string;
  temp: number;
  feelsLike: number;
  rainProb: number;
  conditionEn: string;
  conditionHi: string;
  icon: string;
  windSpeed: number; // km/h
  humidity: number;
}

export interface DayForecast {
  dayEn: string;
  dayHi: string;
  date: string;
  tempMax: number;
  tempMin: number;
  rainProb: number;
  rainfallMm: number;
  conditionEn: string;
  conditionHi: string;
  icon: string;
}

export interface PastDayTemp {
  dayEn: string;
  dayHi: string;
  date: string;
  tempMax: number;
  tempMin: number;
  normalMax: number;
  normalMin: number;
  departure: number; // e.g. +2.4
  rainfallMm: number;
}

export interface HumidityAlert {
  id: string;
  timestamp: string;
  previousHumidity: number;
  currentHumidity: number;
  changePercent: number;
  dewPoint: number;
  severity: 'warning' | 'critical' | 'advisory';
  titleEn: string;
  titleHi: string;
  descEn: string;
  descHi: string;
  farmerImpactEn: string;
  farmerImpactHi: string;
  commuterImpactEn: string;
  commuterImpactHi: string;
  travelerImpactEn: string;
  travelerImpactHi: string;
}

export interface SoilMoistureData {
  depth10cm: { value: number; statusEn: string; statusHi: string; color: string };
  depth30cm: { value: number; statusEn: string; statusHi: string; color: string };
  depth60cm: { value: number; statusEn: string; statusHi: string; color: string };
  fieldCapacityPercent: number;
  evapotranspiration: number; // mm/day
}

export interface AgrometAdvisory {
  cropEn: string;
  cropHi: string;
  stageEn: string;
  stageHi: string;
  sowingAdviceEn: string;
  sowingAdviceHi: string;
  irrigationAdviceEn: string;
  irrigationAdviceHi: string;
  sprayAdviceEn: string;
  sprayAdviceHi: string;
}

export interface TrafficRainImpact {
  corridorEn: string;
  corridorHi: string;
  riskLevel: 'High' | 'Medium' | 'Low';
  riskLevelHi: 'उच्च' | 'मध्यम' | 'निम्न';
  waterloggingDepthCm: number;
  delayEstimateEn: string;
  delayEstimateHi: string;
  statusNoteEn: string;
  statusNoteHi: string;
}

export interface MarineData {
  waveHeightM: number;
  swellPeriodSec: number;
  windSpeedKnots: number;
  windGustsKnots: number;
  seaStateEn: string;
  seaStateHi: string;
  tideNextEn: string;
  tideNextHi: string;
  incoisBulletinEn: string;
  incoisBulletinHi: string;
  safeDistanceNauticalMiles: number;
}

export interface PersonaWeatherData {
  location: LocationInfo;
  currentTemp: number;
  feelsLike: number;
  conditionEn: string;
  conditionHi: string;
  conditionCode: string;
  humidity: number;
  dewPoint: number;
  pressureHpa: number;
  visibilityKm: number;
  windSpeedKmh: number;
  windDir: string;
  uvIndex: number;
  aqi: {
    value: number;
    categoryEn: string;
    categoryHi: string;
    pm25: number;
    pm10: number;
    no2: number;
    healthAdvisoryEn: string;
    healthAdvisoryHi: string;
  };
  nowcasting: HourlyForecast[];
  sevenDayForecast: DayForecast[];
  pastSevenDaysTemp: PastDayTemp[];
  humidityTrend: { time: string; humidity: number }[];
  activeHumidityAlert: HumidityAlert;
  contextualAlert?: {
    level: 'Orange' | 'Red' | 'Yellow';
    levelHi: 'ऑरेंज' | 'रेड' | 'येलो';
    titleEn: string;
    titleHi: string;
    timeframeEn: string;
    timeframeHi: string;
    detailsEn: string;
    detailsHi: string;
  };
  aiAdvisory: {
    badgeEn: string;
    badgeHi: string;
    headlineEn: string;
    headlineHi: string;
    contentEn: string;
    contentHi: string;
    actionItemsEn: string[];
    actionItemsHi: string[];
    timestamp: string;
  };
  // Persona specific
  soilMoisture?: SoilMoistureData;
  agrometAdvisories?: AgrometAdvisory[];
  trafficImpacts?: TrafficRainImpact[];
  marineData?: MarineData;
  // Real-time Provider Metadata
  isLive?: boolean;
  providerName?: string;
  lastUpdatedIso?: string;
}
