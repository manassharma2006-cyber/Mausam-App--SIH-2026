/**
 * Utility to ensure all numbers remain standard English/Latin digits (0-9)
 * even when the application language is set to Hindi (हिंदी).
 */
export const normalizeDigits = (val: string | number | null | undefined): string => {
  if (val === null || val === undefined) return '';
  const devanagariNumerals: Record<string, string> = {
    '०': '0',
    '१': '1',
    '२': '2',
    '३': '3',
    '४': '4',
    '५': '5',
    '६': '6',
    '७': '7',
    '८': '8',
    '९': '9',
  };
  return String(val).replace(/[०-९]/g, (digit) => devanagariNumerals[digit] ?? digit);
};
